'use strict';

angular
    .module('4sh.utils')
    .directive('sectorChooser', function (Session) {
        return {
            restrict: 'E',
            replace: false,
            scope: {
                bien: "="
            },
            templateUrl: 'modules/utils/sector-chooser.html',
            link: function (scope) {
                angular.extend(scope, {
                    sectors: {},
                    selectedSector: null,
                    canUpdateSectors: function () {
                        return scope.bien.canUpdateSector !== false;
                    },
                    updateModel: function (val) {
                        scope.bien.selectedSector = {
                            Key: parseInt(val),
                            Value: scope.sectors[val]
                        }
                    }
                });
                scope.$on('$destroy', scope.$watch('bien', function (bien) {
                    console.log(scope.bien)
                    if (bien) {
                        //console.log('setScope',bien.selectedSector.Key)
                        scope.selectedSector = "" + (bien.selectedSector ? bien.selectedSector.Key : null);
                        scope.sectors = bien.sectors || Session.current().sectors
                    }
                }));
            }
        };
    });
