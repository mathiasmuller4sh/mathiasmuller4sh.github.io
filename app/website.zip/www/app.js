'use strict';
var requires = [
    'ionic', 'ngIOS9UIWebViewPatch', 'ngAnimate', 'ui.mask', 'restangular',
    'angulartics', 'angulartics.google.analytics',
    'module.login', 'menu.index', 'module.home', 'module.search', 'module.contact',
    'module.map', 'module.immeuble', 'module.photo', 'module.bien', '4sh.utils'];

angular
    .module('C21mobile', requires)
    .config(function ($logProvider) {
        $logProvider.debugEnabled(false);
    })
    .run(function ($http, $rootScope, $timeout, ContactService) {
        var unregisterListener = $rootScope.$on('user.login', function(event) {
            unregisterListener();
            //test once then pool for follow action
            var promiseC = ContactService.testFollowContactActions(true), promiseT;
            var armTimer = function () {
                promiseC = null;
                promiseT = $timeout(check, 8000);
            };
            var check = function () {
                if(!promiseC) {
                    promiseC = ContactService.testFollowContactActions(false);
                    promiseC ? promiseC.finally(armTimer):armTimer();
                } else {
                    armTimer();
                }
            };

            check();
            $rootScope.$on('$destroy', function() {
                $timeout.cancel(promiseT);
            })
        });
    })
    .run(function ($http, $ionicPlatform, ConfigDictionary, Session) {
        var verifyRevision = function() {
            if(window.location.protocol === 'http:') {
                //bypass check since serve by http web server
                return;
            }
            $http.get(ConfigDictionary.appVersionService, {params:{ts:new Date().getTime()}}).then(function(res){
                var version = ConfigDictionary.appVersion;
                if(ionic.Platform.isAndroid()){
                    version = res.data.android;
                } else if (ionic.Platform.isIOS()){
                    version = res.data.ios;
                } else if (ionic.Platform.isWindowsPhone()){
                    version = res.data.wp;
                }
                //cf https://www.npmjs.com/package/semver#ranges
                if(!semver.satisfies(ConfigDictionary.appVersion, version)){
                    navigator.notification.alert("Vous allez être redirigé vers le site de mise à jour de l'application \n" +
                    "Version courante : " +  ConfigDictionary.appVersion + "\n" +
                    "Version disponible : " + version,  function () {
                        window.open(res.data.appStoreUrl,"_system", "location=yes");
                        console.log("updated");
                    }, "Veuillez mettre à jour votre application", "Aller")
                } else {
                    console.log("Version Ok courante :"+ConfigDictionary.appVersion+" Version disponible : " + version);
                }
            });
        };
        $ionicPlatform.ready(function() {
            $ionicPlatform.on("resume", function(event) {
                console.log('app resume event', event);
                verifyRevision();
                Session.autologin();
            });
            verifyRevision();
        });
    })
    .run(function($rootScope, ConfigDictionary) {
        $rootScope.ConfigDictionary = ConfigDictionary;
        $rootScope.$on("$locationChangeStart",function(event, next, current){
            //Do your things
            var header = angular.element(document.getElementsByTagName("ion-nav-bar"))[0];
            if(header) {
                header.style["opacity"] = "1";
            }
        });
    })
;


