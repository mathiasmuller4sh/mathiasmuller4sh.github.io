Since we don’t use [Rails Assets](http://rails-assets.org) gems in its [source](https://github.com/rails-assets/rails-assets/) (and this filter was created for that project), `angular-semver-sort.js` is *manually* packaged into an asset gem.

This directory contains the scaffolding of this gem, `angular-semver-sort-rails`.
