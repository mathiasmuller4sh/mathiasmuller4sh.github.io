module AngularSemverSortRails
  if defined?(Rails)
    class Engine < ::Rails::Engine; end
  end
end
