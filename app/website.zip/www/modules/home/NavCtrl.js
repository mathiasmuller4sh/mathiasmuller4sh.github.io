'use strict';
angular
    .module('module.home').controller('NavCtrl', function ($rootScope, $scope, $state, $timeout, $window, $ionicModal, $ionicHistory, $ionicNavBarDelegate, Session, HomeService, $ionicSideMenuDelegate) {
        $scope.toggleLeft = function () {
            $ionicSideMenuDelegate.toggleLeft();
        };
        $scope.contextContacts = {};
        angular.extend($scope, {
            Session:Session,
            welcomeString:((new Date().getHours()>18)?'Bonsoir':'Bonjour'),
            menus: [HomeService.home].concat(HomeService.allMenus()),
            isCurrentLocation: function(menu) {
                return $state.includes(menu.state) || $state.includes(menu.state.substring(0, menu.state.length-1));
            },
            backInHistory: function () {
                console.log('backInHistory:', $ionicHistory.viewHistory());
                $window.history.back();

                //if($state.includes('nav.map.**')) {
                //    console.log('backInHistory');
                //    if($ionicHistory.currentView() && $ionicHistory.currentView().index != 0 ) {
                //        console.log('backinionic index:'+$ionicHistory.currentView().index);
                //        $ionicHistory.goBack();
                //    } else {
                //        $window.history.back();
                //    }
                //    if(true) {
                //        console.log('$window', $window.location);
                //    }
                //} else if($ionicHistory.viewHistory().backView){
                //    if($ionicHistory.viewHistory().backView.stateId != $ionicHistory.viewHistory().currentView.stateId) {
                //        console.log('backinionic');
                //        $ionicHistory.goBack();
                //    } else {
                //        $window.history.back();
                //    }
                //} else {
                //    $window.history.back();
                //}
            },
            showAbout: function () {
                $scope.device = window.device || ionic.Platform.device();
                $ionicModal.fromTemplateUrl('modules/home/about.html', function (modal) {
                    $scope.modal = modal;
                    modal.show()
                }, {
                    scope: $scope,
                    animation: 'slide-in-up'
                });
                $scope.closeModal = function () {
                    $scope.modal.hide();
                };
            },
            closeSideMenu: function () {
                if ($scope.sideMenuController) {
                    $scope.sideMenuController.close();
                }
            }
        });
        $scope.$watch('$historyId', function(newV) {
            if(newV && $scope.hasOwnProperty('$historyId')) {
                console.log('remove history')
                delete $scope.$historyId;
            }
        });
        $rootScope.$on('$locationChangeSuccess', function (evt) {
            $scope.closeSideMenu();
        });
        Session
            .autologin()
            .then(angular.noop,function(ko) {
                $state.go('login');
            });
    });
