'use strict';
angular
    .module('module.home')
    .factory('HomeService', function (Restangular) {
        var datas = [
            { label: 'around.me', state: 'nav.map', clazz: 'icon-c21-around-me' },
            { label: 'contacts', state: 'nav.contacts', clazz: 'icon-c21-contacts' },
            { label: 'property', state: 'nav.biens', clazz: 'icon-c21-properties' }
        ];
        return {
            home: {label: 'home', state: 'home.index', clazz: 'ion-ios-circle-filled' },
            allMenus: function () {
                return datas;
            },
            allConsoles: function () {
                return Restangular.all('consoles').getList();
            }
        };
    })
;
