'use strict';
angular.module('module.home', [])
    .controller('HomeCtrl', function ($rootScope, $scope, $state, $location, $timeout, $interval, $filter, $ionicPopup, Session, SearchService, HomeService, MapService) {

        var getHomeContentHeight =  function () {
            var homeContainer = document.getElementById('home-container');
            if (homeContainer && homeContainer.offsetHeight) {
                return  homeContainer.offsetHeight;
            } else if (homeContainer && homeContainer.style.pixelHeight) {
                return homeContainer.style.pixelHeight;
            }
            return undefined;
        };

        angular.extend($scope, {
            consoles: [],
            clickedConsole: null,
            isSplitBottom: false,
            timers: [],
            timersPulse: [],
            homeVisible : true,
            pulse: false,
            pulseWave: false,
            homeContentHeight: (getHomeContentHeight() || 300),
            getHomeContentHeight: function() {
                $scope.homeContentHeight = getHomeContentHeight();
//                console.log('getHomeContentHeight:'+$scope.homeContentHeight);
            },
            stopAnimation: function () {
                $scope.stopConsoleRadar();
//                $scope.stopPulse();
                $scope.closeAllConsole();
            },
            setHomeVisible: function (value) {
                $scope.homeVisible= value;
            },
            launchAnimation: function () {
                $scope.stopAnimation();
                $scope.animateConsoleRadar();
                $scope.timers.push($interval($scope.animateConsoleRadar, 16000));

                $scope.animatePulse();
                $scope.timersPulse.push($interval($scope.animatePulse, 4000));
            },
            closeAllConsole: function () {
                $scope.consoles.forEach(function (c) {
                    delete c.active;
                });
            },
            selectConsole: function (console) {
                if($scope.clickedConsole && $scope.clickedConsole == console) {
                    $scope.navigateTo($scope.clickedConsole.labelKey)
                } else {
                    //stop animation
                    $scope.isSplitBottom = true;
                    $scope.clickedConsole = null;
                    $scope.stopAnimation();
                    console.active = true;
                    $timeout(function () {
                        $scope.clickedConsole = console;
                    }, 195);
                    //restart animation later
    //                $timeout($scope.launchAnimation, 5000);
                }
            },
            toggleConsoleState: function (console) {
                console.active = angular.isDefined(console.active) ? !console.active : true;
                if (console.active == true) {
                    $scope.selectedConsole = console;
                }
            },
            toggleConsoleStateFn: function (console) {
                return function () {
                    $scope.toggleConsoleState(console)
                };
            },
            stopConsoleRadar: function () {
                $scope.timers.forEach(function (promise) {
                    $timeout.cancel(promise);
                    $interval.cancel(promise);
                });
                $scope.timers = [];
            },
            animateConsoleRadar: function () {
                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[0]), 200));

                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[0]), 4400));
                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[1]), 4400));

                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[1]), 8800));
                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[2]), 8800));

                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[2]), 13000));
                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[3]), 13000));

                $scope.timers.push($timeout($scope.toggleConsoleStateFn($scope.consoles[3]), 16000));
            },
            stopPulse: function () {
                $scope.pulse = false;
                $scope.pulseWave = false;
                $scope.timersPulse.forEach(function (promise) {
                    $interval.cancel(promise);
                });
            },
            animatePulse: function () {
                $scope.pulse = !$scope.pulse;
                $scope.pulseWave = !$scope.pulseWave;

                $scope.timersPulse.push($timeout(function () {
                    $scope.pulse = !$scope.pulse;
                }, 250));

                $scope.timersPulse.push($timeout(function () {
                    $scope.pulseWave = !$scope.pulseWave;
                }, 3000));
            },
            showConsoleDetail: function(clickedConsole) {
                $ionicPopup.alert({
                    title: $filter('i18n')(clickedConsole.labelKey),
                    okType: 'button-popup button-dark',
                    template: clickedConsole.helpText || "Pas de d'information disponbile pour cette console"
                });
            },
            getIconCaClass: function(ca) {
                var caToCheck = parseFloat(ca);

                if (caToCheck > 150) {
                    return 'icon-c21-ca-1';
                } else if(caToCheck > 100) {
                    return 'icon-c21-ca-2'
                } else if(caToCheck > 50) {
                    return 'icon-c21-ca-3'
                } else {
                    return 'icon-c21-ca-4'
                }
            },
            loadConsoles: function(){
                HomeService
                    .allConsoles()
                    .then(function (consoles) {
                        //console.log('loaded consoles from server: '+consoles.length);
                        $scope.consoles = consoles;
                        //start animation
                        $timeout($scope.launchAnimation, 100);
                    }, function(err) {
                        console.log('Unable to get console from server: '+err);
                    });
            },
            navigateTo: function(consoleName){
                if(consoleName === 'acquereurs_sanscontact'){
                    $rootScope.contactFiltres = {console: consoleName};
                    $state.go('nav.contacts');
                } else {
                    $rootScope.bienFiltres = {console: consoleName};
                    $state.go('nav.biens');
                }
            }
        });

        //search link
        var removeLn = $rootScope.$on("search.do",  function (evts, searchTxt) {
            $location.search('search', searchTxt);
        });
        var removeLn1 = $rootScope.$on("search.visibility",  function (evts, visible) {
            $scope.home.searchEnabled = visible;
        });
        var removeLn2 = $rootScope.$on("search.result.click", function (evts, geojsonFeature) {
            $scope.homeVisible = true;
            if (geojsonFeature.properties) {
                if (SearchService.isContact(geojsonFeature)) {
                    $state.go('nav.contact.detail', {id: geojsonFeature.properties._id});
                } else {
                    if (MapService.featureIsAdresse(geojsonFeature) && geojsonFeature.properties.numero) {
                        $state.go('nav.map.immeuble', {id: geojsonFeature.properties._id}, {location: true})
                    } else {
                        $state.go('nav.map', {
                            longitude: geojsonFeature.geometry.coordinates[0],
                            latitude: geojsonFeature.geometry.coordinates[1]
                            //title: 'Résultat'
                        })
                    }
                }
            }
        });
        $scope.$on("$destroy", removeLn);
        $scope.$on("$destroy", removeLn1);
        $scope.$on("$destroy", removeLn2);

        if(Session.current()) {
            $scope.loadConsoles();
        } else {
            $rootScope.$on('user.login', $scope.loadConsoles);
        }


        //height init
        $timeout(function () {
            $scope.getHomeContentHeight();
        }, 500);
        window.onresize = $scope.getHomeContentHeight;

        //clear list filter when back to home
        if(angular.isDefined($rootScope.contactFiltres)) {
            $rootScope.contactFiltres.console = undefined;
        }
        if(angular.isDefined($rootScope.bienFiltres)) {
            $rootScope.bienFiltres.console = undefined;
        }

        //handle back on search
        if (angular.isDefined($state.params.search)) {
            $scope.datas ? $scope.datas.searchText = $state.params.search: $scope.datas={searchText:$state.params.search};
        }


        if ( angular.isDefined($rootScope.searchText)) {
            $scope.datas ? $scope.datas.searchText = $rootScope.searchText: $scope.datas={searchText:$rootScope.searchText};
        }
    });
