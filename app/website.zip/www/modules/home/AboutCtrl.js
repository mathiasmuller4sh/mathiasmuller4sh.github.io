'use strict';
angular
    .module('module.home')
    .controller('AboutCtrl', function ($scope, Session) {
        angular.extend($scope, {
            Session: Session,
            showDevice: ionic.Platform.device(),
            currentPlatform: ionic.Platform.platform(),
            currentPlatformVersion: ionic.Platform.version(),
            grade: ionic.Platform.grade,
            isFullScreen: ionic.Platform.isFullScreen,
            userAgent:navigator.userAgent
        });
    });
