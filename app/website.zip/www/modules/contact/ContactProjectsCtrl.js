'use strict';
angular
    .module('module.contact')
    .controller('ContactProjectsCtrl', function ($scope, $timeout, $state, $stateParams, $ionicModal, $ionicPopup, Restangular, ConfigDictionary) {
        angular.extend($scope, {
            serverUrl: ConfigDictionary.serverUrl,
            datas: {
                showDelete: false,
                terms: [
                    {id: 'month', label: 'Dans le mois'},
                    {id: '6month', label: 'A 6 mois'},
                    {id: '12month', label: 'Dans l\'année'}
                ],
                itemButtons: [
                    {
                        text: 'Supp.',
                        type: 'button-assertive icon',
                        onTap: function (item) {
                            $scope.deleteProject(item);
                        }
                    }
                ]
            },
            showDetail: function (project, index) {
                if (project.property) {
                    $state.go('nav.contact.project', { index: index });
                }
            },
            saveProject: function () {
                if(!$scope.project.title) {
                    //TODO change when fixed
                    //bug in ionic 27 when used in modal
//                    $ionicPopup.alert({
//                        title: 'Projet incomplet.',
//                        content: 'Merci de saisir au moins un titre'
//                    });
                    window.alert('Merci de saisir au moins un titre');
                    return;
                }
                //todo move into service
                Restangular
                    .one('contacts', $stateParams.id)
                    .all('projects')
                    .post($scope.project)
                    .then(function (savedValue) {
                        $scope.project = null;
                        $scope.contact.projects.push(savedValue);
                        $scope.projects.push(savedValue);
                        $scope.closeModal();
                    });
            },
            deleteProject: function (project) {
                Restangular
                    .one('contacts', $stateParams.id)
                    .one('projects', project._id)
                    .remove().then(function() {
                        $scope.projects.splice($scope.projects.indexOf(project), 1);
                    });
            },
            addProject: function () {
                $scope.project = {capturedDate: new Date()};
                $ionicModal.fromTemplateUrl('templates/project-add.html', function (modal) {
                    $scope.modal = modal;
                    $scope.modal.show();
                }, {
                    scope: $scope,
                    animation: 'slide-in-up'
                });
            },
            closeModal: function () {
                $scope.modal.hide();
            },
            projects: function () {
                var promise = Restangular.one('contacts', $stateParams.id).getList('projects');
                promise.then(function (projects) {
                    $scope.contact.projects = projects;
                });
                return promise.$object;
            }()
        });

        $scope.$on('$destroy', function () {
            if ($scope.modal) {
                $scope.modal.remove();
            }
        });
    });
