'use strict';
angular
    .module('module.contact')
    .controller('PopupCtrl', function ($scope, ContactService, Toast) {

        var suivis = [
            {label: 'Afficher d\'autres types de contact'}
        ].concat(ContactService.suiviOptions);

        function cleanup() {
            $scope.ongoingsave = false;
            angular.element(document.querySelector('.popup')).removeClass("add-new-infos");
        }

        function addCss() {
            angular.element(document.querySelector('.popup')).addClass("add-new-infos");
        }

        angular.extend($scope, {
            ongoingsave: false,
            suiviTmp: suivis[0],
            suivis: suivis,
            quickTel: undefined,
            quickEmail: undefined,
            newQuickTel: function () {
                $scope.quickTel = ContactService.newEmptyPhone($scope.contact.telephones);
                addCss();
            },
            newQuickEmail: function () {
                $scope.quickEmail = ContactService.newEmptyMail($scope.contact.emails);
                addCss();
            },
            cancelQuickTel: function () {
                $scope.quickTel = undefined;
                cleanup();
            },
            cancelQuickEmail: function () {
                $scope.quickEmail = undefined;
                cleanup();
            },
            updateSelectedSuivi: function (newVal) {
                $scope.suivi.label = newVal.label;
                $scope.suivi.type = newVal.label;
                $scope.suiviTmp = $scope.suivis[0]
            },
            addQuickTel: function () {
                $scope.contact.telephones.push($scope.quickTel);
                $scope.ongoingsave = true;
                ContactService
                    .save($scope.contact)
                    .then($scope.cancelQuickTel)
                    .then(function() {
                        Toast.show('Téléphone ajouté.');
                    })
                    .finally(cleanup);
            },
            addQuickEmail: function () {
                $scope.contact.emails.push($scope.quickEmail);
                $scope.ongoingsave = true;
                ContactService
                    .save($scope.contact)
                    .then($scope.cancelQuickEmail)
                    .then(function() {
                        Toast.show('Email ajouté.');
                    })
                    .finally(cleanup);
            }
        });
        $scope.ongoingsave = false;
        if ($scope.suivi && !$scope.suivi.label) {
            $scope.updateSelectedSuivi(ContactService.suiviOptions[0]);
        }
    });
