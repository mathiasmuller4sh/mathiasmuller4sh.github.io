'use strict';
angular
    .module('module.contact')
    .controller('ContactBienLinkCtrl', function ($scope, $filter, ContactService, BienService) {

        //need to inherit contact, biens, newBien in datas:{} from parent scope

        var classes = [{clazz:'', label:'Afficher d\'autres types de bien'}].concat(BienService.getBienClazz(false));

        angular.extend($scope, {
            ContactService: ContactService,
            BienService: BienService,
            currentBock: 'new',
            tmpSelection: classes[0],
            classes: classes,
            etages: BienService.getEtagesChoices($scope.datas.newBien),

            getPage: function(withImmeuble) {
                var page = $scope.datas.newBien._class.substring('.Bien'.length).toLowerCase();
                return 'modules/bien/popup/edit-detail-'+ page +'.html';
            },
            updateSelected: function (sel) {
                if(sel.clazz != '') {
                    $scope.datas.newBien._class = sel.clazz;
                }
                $scope.tmpSelection = classes[0];
            },
            newBienClicked: function (bien) {
                $scope.currentBock='new';
                $scope.datas.currentBien = $scope.datas.newBien;
            },
            chooseBienClicked: function (bien) {
                $scope.currentBock='exist';
                $scope.currentBien = $scope.datas.biens[0];
            },
            hasBiens: function () {
                return angular.isDefined($scope.datas.biens) && $scope.datas.biens.length > 0;
            },
            saveDisabled: function () {
                return !($scope.datas.newBien._class || $scope.datas.relation.type);
            },
            contactTypes : ContactService.getContactType()

        });

        if (angular.isUndefined($scope.datas.newBien)) {
            $scope.datas.newBien = {};
        }
        if($scope.datas.biens && $scope.datas.biens.length == 1 && $scope.datas.biens[0]._class === ".BienImmeuble"){
            $scope.datas.biens = $scope.datas.biens[0].appartements;
        }
/*
        if (angular.isUndefined($scope.datas.newBien._class)) {
            $scope.datas.currentBien._class = ".BienMaison";
        }*/

//        if($scope.hasBiens()) {
//            $scope.currentBock='exist';
//        }

        if (angular.isUndefined($scope.datas.currentBien)) {
            if ($scope.hasBiens()) {
                $scope.datas.currentBien = $scope.datas.biens[0];
            } else {
                $scope.datas.currentBien = $scope.datas.newBien;
            }
        }
    });
