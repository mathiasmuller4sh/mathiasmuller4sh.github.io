'use strict';
angular
    .module('module.contact')
    .controller('ContactListCtrl', function ($scope, $rootScope, $ionicScrollDelegate, $urlRouter, $state, $location, $filter, $timeout, $ionicPopup, $ionicLoading, LoadingConfig, ContactService, BienService, AdresseService, LocalStorageService) {
        if (angular.isUndefined($rootScope.contactFiltres)) {
            $rootScope.contactFiltres = {};
        }

        var emptyFilter = {
            searchText: $state.params.searchText || '',
            occupationStatus: $state.params.occupation || '',
            projet: $state.params.projet || '',
            dernierContact: $state.params.dernierContact || 0,
            debut : 0,
            nextDebut: 0,
            bienRef : $state.params.bienRef | null,
            nombre : 50,
            console : $state.params.console | null
        };

        angular.extend($scope, {
            ContactService: ContactService,
            $state: $state,
            letters: [],
            contacts: [],
            contactsWithLetter: [],
            message: {},
            selectedPhone: {},
            noMoreItemsAvailable : false,
            bienRef: null,
            count :0,

            filtres: angular.extend(emptyFilter, $rootScope.contactFiltres),
            datas: {},
            lastLetter: {},
            showLoading: function () {
                $ionicLoading.show(LoadingConfig);
            },
            showPopup: function (popupToShow, contact) {
                if(contact.telephones && contact.telephones.length == 1 && popupToShow == 'call' ) {
                    ContactService.callInitiated(contact, contact.telephones[0].value, true);
                } else {
                    ContactService.showPopup(popupToShow, $scope, contact);
                }
            },
            loadMore : function(start) {
                $scope.loading = true;
                if(angular.isUndefined(start) && $scope.contacts.length > 0) {
                    //call from html
                    $scope.filtres.debut = $scope.filtres.nextDebut;
                } else {
                    $scope.filtres.debut = 0;
                }
                //console.log("loadMore", $scope.filtres.debut)
                if ($scope.filtres.debut === 0) {
                    $scope.showLoading();
                    $scope.contacts.splice(0, $scope.contacts.length);
                }
                ContactService.all($scope.filtres)
                    .then(function (res) {
                        res.contacts.forEach(function (person) {
                            ContactService.optimizeContactToList(person);
                            angular.isDefined(person.nom) && person.nom !== ""?$scope.contacts.push(person):angular.noop();
                        });
                        $scope.noMoreItemsAvailable = (res.contacts.length == 0);
                        $timeout(function() {$scope.$broadcast('scroll.infiniteScrollComplete');},100);
                        $scope.filtres.nextDebut = $scope.filtres.debut + $scope.filtres.nombre;
                        $scope.count = res.count;
                        $scope.loading = false;
                    })
                    .finally($ionicLoading.hide);

            },
            getTitle: function () {
                if (angular.isDefined($scope.adresseRef) && !_.isEmpty($scope.adresseRef)) {
                    return AdresseService.getFormatedAdresse($scope.adresseRef);
                } else {
                    return $scope.count ;
                }
            },

            callInitiated: function (contact, phone) {
                ContactService.callInitiated(contact, phone);
            },

            sortByStatusItems: [{"filter": "", "label": "Statut d'occupation"}].concat(ContactService.getContactType()),
            myProjectOptions: [{"filter": "", "label": "Projets"}].concat(ContactService.getProjectTypes()),
            lastContactValues: [{
                "filter": 0,
                "label": "Dernier contact"
            }].concat(ContactService.getLastContactValues()),

            displayLetter: function (letter) {
                $rootScope.locals.currentLetter.selected = false;
                letter.selected = true;
                $rootScope.locals.currentLetter = letter;
                console.log("$scope.locals.currentLetter", $rootScope.locals.currentLetter)
            },
            //Letters are shorter, everything else is 52 pixels
            getItemHeight: function (item) {
                return item && item.isLetter ? 30 : 80;
            },

            filterContactByInput: function (contact) {
                return !$scope.filtres.searchText ||
                    (contact.nom && contact.nom.toLowerCase().indexOf($scope.filtres.searchText.toLowerCase()) === 0) ||
                    (contact.prenom && contact.prenom.toLowerCase().indexOf($scope.filtres.searchText.toLowerCase()) ===0) ||
                    $scope.filterContactPhones(contact) ||
                    $scope.filterContactAddresses(contact)||
                    $scope.filterContactEmails(contact);
            },
            filterContactPhones: function (contact) {
                var res = false;
                var all = contact.telephones || [];
                all.forEach(function (phone) {
                    if (phone && phone.value && phone.value.indexOf($scope.filtres.searchText.toLowerCase()) > -1) {
                        res = true;
                    }
                });
                return res;
            },
            filterContactAddresses: function (contact) {
                var res = false;
                (contact.adresseReferences || []).forEach(function (address) {
                    if (address && address.adresseString && address.adresseString.toLowerCase().indexOf($scope.filtres.searchText.toLowerCase()) > -1) {
                        res = true;
                    }
                });
                return res;
            },
            filterContactEmails: function (contact) {
                var res = false;
                (contact.emails || []).forEach(function (email) {
                    if (email && email.value && email.value.toLowerCase().indexOf($scope.filtres.searchText.toLowerCase()) > -1) {
                        res = true;
                    }
                });
                return res;
            },
            addLetter: function (code) {
                var letter = String.fromCharCode(code);
                var letterObj = {
                    isLetter: true,
                    letter: letter,
                    selected: false
                };
                var exist = _.findIndex($scope.letters, function (l) {
                    return l.letter == letter;
                });
                if (exist === -1) {
                    $scope.contactsWithLetter.push(letterObj);
                    $scope.letters.push(letterObj);
                }
            },
            loadContacts: function () {
                /*$scope.bienRef = $state.params.bienRef;
                if (angular.isDefined($state.params.bienRef)) {
                    var promise = BienService.get($scope.bienRef);
                    $scope.bien = promise.$object;
                    promise.then(function (bien) {
                        AdresseService.getAdresseForImmeuble(bien.immeubleRef).then(function (adresse) {
                            $scope.adresseRef = adresse;
                            $scope.contextContacts.adresse = adresse;
                        })
                    });
                } else {
                    $scope.bien = null;
                    $scope.adresseRef = null;
                    $scope.contextContacts = {};
                }
                var done = function () {
                    $scope.getContacts();
                    $ionicLoading.hide();
                };
                $scope.contactsWithLetter = [];*/
//                var promise = ContactService.all($scope.filtres);
//                $scope.contactsRes = $scope.contacts.concat(promise.$object);
//                promise.finally($ionicLoading.hide);
            },
            hasFilter: function () {
                return ContactService.hasFilterSet($scope.filtres);
            },
            filterContactByStatutOccupation: function (item) {
                if (!$scope.filtres.occupationStatus || $scope.filtres.occupationStatus === '' || item.isLetter) {
                    return true
                } else {
                    return $scope.filtres.occupationStatus === '' || item.dernierStatut.toLowerCase() === $scope.filtres.occupationStatus.toLowerCase();
                }
            },
            filterContactByLastProject: function (item) {
                return $scope.filtres.projet === "" || (item.dernierProjet === $scope.filtres.projet.toLocaleLowerCase());
            },
            filterContactByDateDernierContact: function (item) {
                if (!$scope.filtres.dernierContact || $scope.filtres.dernierContact === 0) {
                    return true
                }
                if (angular.isUndefined(item.dateDernierContact)) {
                    //nevers contacted add it to last filter
                    var all = ContactService.getLastContactValues();
                    return $scope.filtres.dernierContact == _.last(all).filter;
                } else {
                    var monthsInterval = $scope.filtres.dernierContact;
                    if (monthsInterval === 1) {
                        var dateToTest = new Date();
                        dateToTest.setMonth(dateToTest.getMonth() - $scope.filtres.dernierContact);
                        return new Date(item.dateDernierContact) > dateToTest;
                    }
                    else if (monthsInterval === 3) {
                        var dateMin = new Date();
                        dateMin.setMonth(dateMin.getMonth() - $scope.filtres.dernierContact);
                        var dateMax = new Date();
                        dateMax.setMonth(dateMax.getMonth() - 1);
                        return new Date(item.dateDernierContact) > dateMin && new Date(item.dateDernierContact) < dateMax;
                    } else if (monthsInterval === 6) {
                        var dateToTest = new Date();
                        dateToTest.setMonth(dateToTest.getMonth() - $scope.filtres.dernierContact);
                        return new Date(item.dateDernierContact) < dateToTest;
                    } else {
                        return true;
                    }
                }
            },
            getContacts: function () {
                $scope.letters = [];
                $scope.newContactsWithLetter = [];
                var letterHasMatch = {};
                //Filter contacts by $scope.search.
                //Additionally, filter letters so that they only show if there
                //is one or more matching contact
                if ($scope.contacts && $scope.contacts.length > 0) {
                    $scope.contactsWithLetter = [];
                    if ($scope.hasFilter()) {
                        $scope.newContactsWithLetter = $scope.contacts
                            .filter(function (item) {
                                return $scope.filterContactByInput(item) &&
                                    $scope.filterContactByStatutOccupation(item) &&
                                    $scope.filterContactByLastProject(item) &&
                                    $scope.filterContactByDateDernierContact(item);
                            });
                    } else {
                        $scope.newContactsWithLetter = $scope.contacts;
                    }
                }

                var currentCharCode = 'A'.charCodeAt(0) - 1;
                $scope.newContactsWithLetter.forEach(function (person) {
                    ContactService.optimizeContactToList(person);
                    if (angular.isDefined(person.nom)) {
                        //Get the first letter of the last name, and if the last name changes
                        //put the letter in the array
                        var personCharCode = person.nom.toUpperCase().charCodeAt(0);
                        //We may jump two letters, be sure to put both in
                        //(eg if we jump from Adam Bradley to Bob Doe, add both C and D)
                        if (currentCharCode - personCharCode != 0) {
                            $scope.addLetter(personCharCode);
                        }
                        currentCharCode = personCharCode;
                        $scope.contactsWithLetter.push(person);
                    }
                });
            },
            resetLetter: function () {
                //console.log('resetLetter', $scope.$id)
                //$scope.$apply(function() {
                //    $scope.lastLetter.selected = false;
                //
                //})
                //$scope.datas.lastLetter = {};
            },
            //We have to figure out which scrollValue to go to for the letter
            //Luckily, we already supply the height of every item to collection-repeat,
            //so we will just use that!
            goToLetter: function (letter) {

                var scrollValue = 0;
                var contacts = $scope.contactsWithLetter;
                $scope.showLetterClicked(letter);

                //Find the height of every item until we hit the given letter
                for (var i = 0, ii = contacts.length; i < ii; i++) {
                    if (contacts[i].isLetter && contacts[i] === letter) {
                        break;
                    }
                    scrollValue += $scope.getItemHeight(contacts[i]);
                }
                $ionicScrollDelegate.scrollTo(0, scrollValue, true);
                $timeout(function () {
                    $scope.lastLetter.selected = false;
                    $scope.lastLetter = letter;
                    letter.selected = true;
                }, 200);
            },
            letterToShow: null,
            bubbleLetterVisible: false,
            showLetterClicked: function (letter) {
                $scope.letterToShow = letter;
                $scope.bubbleLetterVisible = !$scope.bubbleLetterVisible;
                $timeout(function () {
                    $scope.bubbleLetterVisible = !$scope.bubbleLetterVisible;
                }, 600);

            },
            scrollTop: function () {
                $ionicScrollDelegate.scrollTop();
            },
            clearSearchBox: function () {
                $scope.filtres.searchText = '';
            },
            clearSearch: function () {
                $scope.filtres = angular.extend({}, emptyFilter);
            },
            doRefresh: function () {
                $scope.showLoading();
                ContactService.cleanCache();
                $scope.clearSearch();
                $scope.loadMore(0);
            }
        });

        $scope.loadMore(0);

       /* $scope.$watch(function () {
                return $scope.filtres.searchText;
            }, function (newValue, oldValue) {
                if (newValue !== oldValue) {
                    $scope.filtres.debut = 0;
                    $scope.loadMore();
                }
            }
        );*/
//        $scope.$watch('$state.params.bienRef', function (newValue, oldValue) {
//            //let the browser breeze a bit
//            $timeout($scope.loadContacts, 50);
//        });
            $scope.$watch('filtres', _.debounce(function (newValue, oldValue) {
                //console.log('filtres change', newValue, oldValue);
                if(newValue.searchText !== oldValue.searchText ||
                    newValue.occupationStatus !== oldValue.occupationStatus ||
                    newValue.projet !== oldValue.projet ||
                    newValue.dernierContact !== oldValue.dernierContact) {
                        console.log("filters change loading..");
                        $rootScope.contactFiltres = angular.extend($rootScope.contactFiltres, newValue);
                        $scope.loadMore(0);
                }
            }, 500), true);
    });
