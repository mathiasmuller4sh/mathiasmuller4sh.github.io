'use strict';
angular.module('module.contact',[]);
