'use strict';
angular
    .module('module.contact')
    .controller('ContactMapCtrl', function ($scope, $state, ContactService, MapService) {
        angular.extend($scope, {
            leafletContact: MapService.getMapConfiguration(),


        });

        if ($scope.contact) {
            delete $scope.leafletContact.geojson;
            var geojsonFromAdresse = $scope.getGeojsonFromAdresse($scope.contact);
//            $scope.leafletContact.geojson = angular.extend({data: geojsonFromAdresse}, $scope.leafletContact.geojson);
            $scope.leafletContact.markers = $scope.getMarkersFromAdresse($scope.contact);
            if (geojsonFromAdresse.features.length > 0) {
                MapService.centerOnFeature($scope.leafletContact, geojsonFromAdresse.features[0], true);
            }
        }
    });
