'use strict';
angular
    .module('module.contact')
    .controller('QuickContactCtrl', function ($scope, $state, $stateParams, $ionicPopup, ContactService, ContactActionsService, AdresseService, BienService, $filter) {
        var i18n = $filter('i18n');
        angular.extend($scope, {
            goFicheBien: function () {
                BienService.display($scope.relation && $scope.relation.bien ?$scope.relation.bien._id: $scope.bien._id).then($scope.closeQuickActionModal);
            },
            goFicheNoteContact: function () {
                var id =  $scope.relation && $scope.relation.contactRef ?$scope.relation.contactRef: '';
                $state.go('nav.contact.hist',{id:id}).then($scope.closeQuickActionModal);
            },
            goFicheContact: function () {
                var id =  $scope.relation && $scope.relation.contactRef ?$scope.relation.contactRef: '';
                $state.go('nav.contact.detail',{id:id}).then($scope.closeQuickActionModal);
            },
            changeStatus: function (contact) {
                //immeuble set bien in relation temporary to allow modification
                ContactService
                    .linkBienAndContact(null, $scope.relation.bien || $scope.bien, $scope.relation.contact, null, null, $scope.relation, 'Modifier le statut d\'occupation');
            },
            closeQuickActionModal: function () {
                //$scope.quickModal.remove();
                //$scope.quickModal.hide();
                $scope.$emit('closeModal');
            },
            openConfirmRemovePopUp: function (relation) {
                if (relation._id) {
                    var name = relation.contact ? ContactService.formatContact(relation.contact) : relation.contactString;
                    var statusStr = (relation.type && relation.type != ContactService.status.indetermine) ? 'l\'actuel(le) ' + i18n(relation.type) : ' n\'habite plus ce bien';
                    $ionicPopup.confirm({
                        title: 'Merci de confirmer',
                        template: '<span><img class="type-picture" style="width:32px;" src="' + ContactService.getPictureForType(relation.type) + '"><span style="vertical-align: super; display:initial;top:0"> ' + name + ' n\'est plus ' + statusStr + '?</span></span>',
                        cancelText: 'Annuler',
                        cancelType: 'button-grey button-popup',
                        okText: 'Valider',
                        okType: 'button-energized button-popup'
                    }).then(function (choice) {
                        if (choice) {
                            $scope.removeRelation(relation);
                        }
                    });
                } else {
                    $scope.removeRelation(relation);
                }
            },
            removeRelation: function (relation) {
                ContactActionsService.removeRelation(relation).then($scope.closeQuickActionModal);
            },
            submitRelation: function (relation) {
                //ui set typeTemp to allow verification/rollback before setting to object
                var bien = $scope.bien;
                if (relation.principal) {
                    _.each(bien.relations, function (item) {
                        item.principal = item._id === relation._id;
                    });
                }
                var type = relation.type;
                if (type && type != "" && relation.contactRef) {
                    BienService
                        .save(bien)
                        .then(function (bien) {

                        });
                }
            }
        });
    });
