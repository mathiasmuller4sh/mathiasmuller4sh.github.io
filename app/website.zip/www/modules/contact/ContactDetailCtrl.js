'use strict';
angular
    .module('module.contact')
    .controller('ContactDetailCtrl', function ($rootScope, $scope, $window, $location, $state, $q, $filter, $timeout, $stateParams,
                                               $ionicPopup, $ionicLoading, SavingConfig, $cordovaKeyboard, $ionicHistory, $ionicPosition, $ionicScrollDelegate,$document,
                                               $ionicActionSheet, $ionicModal, Toast, MapService, ContactService, Restangular, AdresseService, LocalStorageService) {
        var mapTypeProjetToClass = {
            'acquereur': {
                '_class': '.ProjetAcquereur'
            },
            'estimation': {
                '_class': '.ProjetEstimation'
            },
            'vendeur': {
                '_class': '.ProjetVendeur'
            },
            'mandat': {
                '_class': '.ProjetMandat'
            },
            'locataire': {
                '_class': '.ProjetLocataire'
            },
            'bailleur': {
                '_class': '.ProjetBailleur'
            },
            'prospect': {
                '_class': '.ProjetProspect'
            }
        };
        var isEdit = function() {
            return  $state.is('nav.contact.edit');
        };
        var getDefaultProject = function (contact) {
            return contact && contact.projets && contact.projets.length > 0 ? contact.projets[0] : {};
        };
        //$timeout(function() {
        //    if (angular.isUndefined($scope.contact) || _.isEmpty($scope.contact)) {
        //        var id = $stateParams.id;
        //        console.log("no contact in detailctrl loading contact id=>",id);
        //        $scope.contact = ContactService.loadContact(id, $scope.contextContacts, isEdit());
        //    }
        //},100);

        $cordovaKeyboard.close();

        angular.extend($scope, {
            ContactService: ContactService,
            AdresseService: AdresseService,
            $state: $state,
            selectedProject: getDefaultProject($scope.contact),
            quickTel:null,
            quickEmail:null,
            datas:{
                editNote:false
            },
            scrollTo: function (elm) {
                $ionicScrollDelegate.scrollElementToTop(elm, 'contact-edit-content');
            },
            focusNextFieldOnEnter: function ($event) {
                var nonFocusable = ['hidden', 'button', 'radio', 'checkbox', 'submit'];
                if($event.keyCode === 13) { //enter key
                    var input = $event.target;
                    var form = input.form;
                    if(!form) {
                        console.warn("Method only works on input in forms");
                        return;
                    }
                    var elements = form.elements;
                    var index = -1;
                    for(var i = 0, l = elements.length; i<l; i++) {
                        var element = elements[i];
                        if(element === input) {
                            //found source
                            index = i;
                        } else if (index != -1 && element.tagName == 'INPUT' && nonFocusable.indexOf(element.type) == -1) {
                            element.focus();
                            return;
                        }
                    }
                    //start over
                    for(i = 0, l = elements.length; i<l; i++) {
                        element = elements[i];
                        if (element.tagName == 'INPUT' && nonFocusable.indexOf(element.type) == -1) {
                            element.focus();
                            break;
                        }
                    }
                }
            },
            selectProject: function (project) {
                $scope.selectedProject = project;
            },
            getTypeMandats: function () {
                return [
                    {
                        "value": "simple",
                        "label": "Simple"
                    },
                    {
                        "value": "confiance",
                        "label": "Confiance"
                    },
                    {
                        "value": "exclusif",
                        "label": "Exclusif"
                    }
                ];
            },
            showEditButton: function () {
                return $state.is('nav.contact.detail');
            },
            isEdit: isEdit,
            showProjectDetail: function () {
                return $scope.selectedProject != null && Object.keys($scope.selectedProject).length != 0
            },
            showProjectNotes: function () {
                return $scope.selectedProject && $scope.selectedProject.type === 'acquereur';
            },
            toogleNoteEditable: function () {
                if($scope.datas.editNote === false) {
                    $scope.datas.editNote = true;

                } else {
                    $scope.datas.editNote = false;
                    $scope.updateContactNotes();
                }
            },
            updateContactNotes: function () {
                ContactService.save($scope.contact).then(function(savedContact) {
                   Toast.show("Notes mises à jour ..")
                });
            },
            submit: function () {
                $ionicLoading.show(SavingConfig);
                $cordovaKeyboard.close();
                if(!$scope.contact._id){
                    ContactService.findByContact($scope.contact).then(function(res){
                        if(res.length == 0 ){
                            return $scope.save();
                        } else {
                            $ionicLoading.hide();
                            $scope.data = {
                                existingContacts : res,
                                selectedContact : res[0]
                            };
                            $ionicPopup.show({
                                title: 'Doublons détectés',
                                template:  'Il existe {{data.existingContacts.length}} contact(s) avec le même nom: <br/>' +
                                '<div class="list">'+
                                    '<ion-radio name="type" ng-repeat="item in data.existingContacts" ng-value="item"' +
                                        'ng-model="data.selectedContact">'+
                                        '{{ item.nom }} {{ item.prenom }} <div style="font-size:smaller"> {{item.adresseReferences[0].adresseString}} {{item.telephones[0].value}} {{item.mails[0].value}}</div>'+
                                    '</ion-radio>'+
                                '</div>',
                                scope: $scope,
                                cssClass: 'bigPopup',
                                buttons: [
                                    {
                                        text: 'Créer le contact',
                                        type: 'button-popup button-dark',
                                        onTap: $scope.save
                                    },
                                    {
                                        text: 'Mettre à jour le contact sélectionné',
                                        type: 'button-popup button-energized',
                                        onTap:  function () {
                                            if($scope.data.selectedContact) {
                                                $scope.contact = ContactService.mergeContactInfos($scope.contact, $scope.data.selectedContact);
                                                $scope.save();
                                            }
                                        }
                                    }
                                ]
                            });
                        }
                    });
                } else {
                    return $scope.save();
                }
            },
            forceMenuShow: function() {
                angular.element(document.getElementById('contact-nav-bar')).removeClass('hide');
            },
            save: function() {
                $ionicHistory.nextViewOptions({
                    disableBack: true
                });
                $ionicLoading.show(SavingConfig);
                return ContactService.save($scope.contact).then(function(savedContact) {
                    $ionicLoading.hide();
                    $scope.contact = savedContact;
                    var go = function() {
                        $state.go("nav.contact.detail",{id: $scope.contact._id}).then(function() {
                            $timeout($scope.forceMenuShow, 2000);
                        });
                        ContactService.showSaveToast();
                    };
                    if(angular.isDefined($scope.hasNewAdresse)) {
                        //propose de créer le lien entre contact et bien voir de créer le bien
                        ContactService.addAdresseOnAdresseLink($scope.contact, $scope.hasNewAdresse).finally(function() {
                            console.log('addAdresseOnAdresseLink');
                            go();
                        });
                    } else {
                        go();
                    }
                });
            },

            addPhone: function (forceFocus) {
                $scope.contact.telephones.push(ContactService.newEmptyPhone($scope.contact.telephones));
                $scope.focusNewtel = angular.isDefined(forceFocus) ?  forceFocus : true;
            },
            addEmail: function (forceFocus) {
                $scope.contact.emails.push(ContactService.newEmptyMail($scope.contact.emails));
                $scope.focusNewMail = angular.isDefined(forceFocus) ?  forceFocus : true;
            },
            addAdresse: function (forceFocus) {
                if (!$scope.contact.adresseReferences) {
                    $scope.contact.adresseReferences = [{}];
                } else {
                    $scope.contact.adresseReferences.push({});
                }
                $scope.focusNewAdresse = angular.isDefined(forceFocus) ?  forceFocus : true;
            },
            confirmRemove: function (titleKey, messageKey, callback) {
                $ionicPopup.confirm({
                    title: $filter('i18n')(titleKey),
                    template: '<div style="text-align: center">'+$filter('i18n')(messageKey)+'</div>',
                    cancelText: 'Annuler',
                    cancelType: '$button-popup',
                    okText: 'Valider',
                    okType: 'button-energized button-popup'
                }).then(function (res) {
                        if (res) {
                            callback();
                        }
                    }
                )
            },
            removePhone: function (index) {
                if (!$scope.contact.telephones[index].value) {
                    $scope.contact.telephones.splice(index, 1);
                } else {
                    $scope.confirmRemove('remove.confirmation.title', 'remove.confirmation.phone', function () {
                        $scope.contact.telephones.splice(index, 1);
                    });
                }
            },
            removeEmail: function (index) {
                if (!$scope.contact.emails[index].value) {
                    $scope.contact.emails.splice(index, 1);
                } else {
                    $scope.confirmRemove('remove.confirmation.title', 'remove.confirmation.email', function () {
                        $scope.contact.emails.splice(index, 1);
                    })
                }
            },
            removeAdresse: function (index) {
                if (!$scope.contact.adresseReferences[index].adresseString) {
                    $scope.contact.adresseReferences.splice(index, 1);
                } else {
                    $scope.confirmRemove('remove.confirmation.title', 'remove.confirmation.adresse', function () {
                        $scope.contact.adresseReferences.splice(index, 1);
                    })
                }
            },
            contactIsValid: function () {
                // no more verification
//                ($scope.contact.emails && $scope.contact.emails.length > 0)
//                    || ($scope.contact.telephones && $scope.contact.telephones.length > 0)
//                    || ($scope.contact.adresseReferences && $scope.contact.adresseReferences.length > 0 );
                return $scope.contact.nom && $scope.contact.nom.trim() !='';
            },
            getProjectType: function () {
                return ContactService.getProjectTypes();
            },
            getTypeBien: function () {
                return ["Appartement", "Maison"];
            },
            getProjetQualification: function () {
                return ["A", "B", "C"];
            },
            //debug safe to remove
            linkadresse: function () {
                ContactService.addAdresseOnAdresseLink($scope.contact, $scope.contact.adresseReferences[0].adresse);
            },
            clearAdresseIfNoMatch: function (adresseLink) {
                //clear proposal on adresse leave
                $scope.focusNewAdresse=false;
                $timeout(function() {
                    if(!adresseLink.adresseRef) {
                        adresseLink.adresseString = "";
                        $scope.proposalAdresses = [];
                    }
                }, 2500);
            },
            acceptAdresseProposal: function (adresse, target) {
                var adresseLink = $scope.proposalAdresses_targetField;
                adresseLink.adresse = adresse;
                adresseLink.adresseRef = adresse._id;
                adresseLink.adresseString = AdresseService.getFormatedAdresse(adresse);
                $scope.proposalAdresses = [];
                $scope.proposalAdresses_targetField = null;
                $scope.hasNewAdresse = adresse;
            },
            adresseCompletion: _.debounce(function (adresseLink) {
                $scope.$apply(function () {
                    if (adresseLink && adresseLink.adresseString.length > 3) {
                        $scope.proposalAdresses = ["Recherche de l'adresse ..."];
                        //save targetField to be able to attach later
                        $scope.proposalAdresses_targetField = adresseLink;
                        var params = {
                            q: adresseLink.adresseString,
                            lat: MapService.getLastLocation().lat,
                            lng: MapService.getLastLocation().lng,
                            distance: 5000
                        };
                        AdresseService
                            .find(params)
                            .then(function (result) {
                            if (!result || result.length == 0) {
                                $scope.proposalAdresses = ["Pas de correspondance trouvée ..."];
                            } else {
                                $scope.proposalAdresses = result;
                            }
                        });
                    } else {
                        $scope.proposalAdresses = [];
                    }
                });
            }, 500),
            loadHistories : function(options) {
                if(angular.isUndefined(options)) {
                    //no option first load
                    $scope.histories = [];
                }
                console.log('loadHistories')
                options = options || {limiteMois:6};
                Restangular.one('contacts', $scope.contact._id)
                    .getList('history', options)
                    .then(function(result) {
                        $scope.histories = result;
                        $timeout(function() {$ionicScrollDelegate.resize()}, 80);
                    });
            }
        });
        $scope.$on('$destroy',$rootScope.$on('followTelActions', function(event, hist) {
            console.log('followTelActions', hist)
            if(hist && $scope.contact && hist.id == $scope.contact._id) {
                $scope.loadHistories();
            }
        }));
        $scope.$on('$destroy',$rootScope.$on("history.added", function(event, hist) {
            $scope.loadHistories();
        }));

        //select project on load
        $scope.$watch('contact._id', function () {
           $scope.selectProject(getDefaultProject($scope.contact));
            if($scope.contact._id){
                console.log("contact loaded", $scope.contact)
                $scope.loadHistories();
                if(isEdit()){
                    if($scope.contact.emails.length === 0){
                        $scope.addEmail(false);
                    }
                    if($scope.contact.telephones.length === 0){
                        $scope.addPhone(false);
                    }
                    if(!$scope.contact.adresseReferences || $scope.contact.adresseReferences.length === 0){
                        $scope.addAdresse(false);
                    }
                }
            }
        });

        $timeout($scope.forceMenuShow, 2000);
    });
