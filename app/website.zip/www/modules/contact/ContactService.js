'use strict';
angular
    .module('module.contact')
    .factory('ContactService', function (Restangular, $state, $rootScope, $analytics, $q, $filter, $timeout, $ionicModal, $ionicLoading, $ionicActionSheet, $ionicPopup, $cordovaKeyboard,
                                         BienService, AdresseService, Toast, LocalStorageService, SavingConfig) {
        var NAME_PREFIX = "__CN__";
        var i18n = $filter('i18n');

        //private to inforce service usage
        var pictureByType = {
            proprietaire: {
                value: "img/owner-icon.png"
            },
            bailleur: {
                value: "img/lessor-icon.png"
            },
            indetermine: {
                value: "img/undefined-icon.png"
            },
            locataire: {
                value: "img/tenant-icon.png"
            }
        };
        var service = {
            status: {
                indetermine: 'indetermine',
                proprietaire: 'proprietaire',
                bailleur: 'bailleur',
                locataire: 'locataire'
            },
            contactTypes: [
                {"filter": "proprietaire", "label": "Propriétaire"},
                {"filter": "locataire", "label": "Locataire"},
                {"filter": "bailleur", "label": "Bailleur"},
                {"filter": "indetermine", "label": "Indetermine"}
            ],
            suiviOptions: [
                {"label": "Contact physique"},
                {"label": "Contact téléphonique"},
                {"label": "Contact email"},
                {"label": "Contact sms"}
            ],
            getKindPhone: [
                {
                    "value": "mobile",
                    "label": "Mobile"
                },
                {
                    "value": "fax",
                    "label": "Fax"
                },
                {
                    "value": "professionel",
                    "label": "Professionel"
                },
                {
                    "value": "domicile",
                    "label": "Domicile"
                },
                {
                    "value": "autre",
                    "label": "Autres"
                }
            ],
            _cache: null,
            hasFilterSet: function(filtres) {
                return angular.isDefined(filtres) && filtres.occupationStatus !== '' || filtres.dernierContact !== 0 || filtres.searchText !== '' ||  filtres.projet !== '' ;
            },
            all: function (filtre) {
                console.log("ContactService.all start..");
                return  Restangular.all('contacts').customGET('search', filtre);
//not cache set for the moment
//                var addTocache = function (resp) {
//                    Array.prototype.splice.apply(service._cache.$object.contacts, [-1, 0].concat(resp.contacts));
//                    console.log("append to cache", service._cache.$object)
//                };
//                if (service.hasFilterSet(filtre)) {
//                    //not caching sub list
//                    return  Restangular.all('contacts').customGET('search', filtre);
//                } else  {
//                    if (!service._cache) {
//                        service._cache = Restangular.all('contacts').customGET('search', filtre);
//                    } else if(filtre.debut && filtre.nombre && filtre.debut+filtre.nombre > service._cache.$object.length)  {
//                        Restangular.all('contacts').customGET('search', filtre).then(addTocache);
//                    }
//                }
//                return service._cache;
            },
            allStreamed: function (array, done, oneEvt, scope) {

                var counter = 0;
                var self = this;
                var started = false;

                oboe('api/contacts')
                    .node('{_id nom}', function (entity) {
                        if (!_.isObject(entity)) {
                            return;
                        }
                        array.push(oneEvt(entity));
                        counter += 1;
                        if (counter > 20) {
                            scope.$apply();
                            counter = 0;
                        }
                    })
                    .done(done)
                    .fail(function (thrown, statusCode, body, jsonBody) {
                        done();
                        if (thrown.statusCode > 500) {
                            array.push([{nom: 'Une erreur est survenue'}]);
                        } else if (thrown.statusCode > 400) {
                            $state.go('login')
                        }
                    });
                return this;
            },

            findByQuery: function (query, options) {
                options = options || {};
                return Restangular.all('contacts').getList(angular.extend({"query": query}, options));
            },

            findByContact: function (contact) {
                return Restangular.all('contacts/checkIfExists').getList({"nom" : contact.nom, "prenom" : contact.prenom})
            },

            cleanCache: function () {
                service._cache = null;
            },
            get: function (id, callback) {
                var promise = Restangular.one('contacts', id).get();
                if (callback) {
                    promise.then(callback);
                }
                return promise.$object;
            },
            getBiensForContact: function (id) {
                return Restangular.one('contacts', id).getList('biens', {limit: 5});
            },
            getMobiles: function (contact) {
                return $filter('filter')(contact.telephones, function (tel) {
                    var number = service.cleanPhone(tel.value);
                    return number && (number.indexOf("06") == 0 || number.indexOf("07") == 0 || number.indexOf('+33(0)6') == 0 || number.indexOf('+33(0)7') == 0);
                })
            },
            loadContact: function (id, options, forEdit) {
                var contact;
                if (angular.isDefined(id)) {
                    if (id !== 'new') {
                        contact = service.get(id, function(contact) {
                            //Restangular.one('contacts', id).getList('history', {limiteMois:6}).then(function(histories) {
                            //    contact.histories = histories;
                            //});
                            if (options && options.callback) {
                                options.callback(contact);
                            }
                        });
                    } else {
                        contact = service.newContact(options);
                        if (forEdit === true) {
                            contact = service.copyForEdit(contact);
                        }
                        if (options && options.callback) {
                            options.callback(contact);
                        }
                    }
                    return contact;
                } else {
                    console.error("no contact id in parameters");
                    return undefined;
                }
            },
            newEmptyPhone: function (tels) {
                return {isDefault: (tels?tels.length==0:false), type: 'mobile', isNew:true};
            },
            newEmptyMail: function (emails) {
                return {isDefault: (emails?emails.length==0:false), isNew: true};
            },
            newContact: function (options) {
                //add empty field will be remove on save
                var newContact = {"emails": [service.newEmptyMail([])], "telephones": [service.newEmptyPhone([])], "adresseReferences": []};
                if (angular.isDefined(options.adresse)) {
                    newContact.adresseReferences.push(AdresseService.newAdresseLink(options.adresse));
                    delete options.adresse;
                } else {
                    newContact.adresseReferences.push({});
                }
                return angular.extend(newContact, options);
            },
            copyForEdit: function (contact) {
                return Restangular.copy(contact);
            },
            formatContact: function (contact) {
                return (contact.nom ? contact.nom.toUpperCase() : '' ) + (contact.prenom ?  ' ' + contact.prenom : '');
            },
            showSaveToast: function () {
                //<i class="icon-infos ion-checkmark-round"></i>
                Toast.show('Mise à jour effectuée');
            },
            cleanUpForSave: function (contact) {
                if (contact) {
                    if(contact.nom) {
                        contact.nom = contact.nom.toUpperCase();
                    }
                    if(contact.prenom) {
                        contact.prenom = contact.prenom.replace(/([^\W_]+[^\s-]*) */g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
                    }
                    angular.forEach(contact.emails, function(mail, index) {
                        if(!mail || !mail.value|| mail.value.trim() ==='') {
                            contact.emails.splice(index, 1);
                        }
                    });
                    angular.forEach(contact.telephones, function(tel, index) {
                        if(!tel || !tel.value || tel.value.trim() === '') {
                            contact.telephones.splice(index, 1);
                        }
                    });
                    angular.forEach(contact.adresseReferences, function(ad, index) {
                        if(!ad || !ad.adresseRef || ad.adresseRef.trim() === '') {
                            contact.adresseReferences.splice(index, 1);
                        }
                    });
                }
                return contact;
            },
            save: function (contact) {
                //cleanup empty fields
                service.cleanUpForSave(contact);
                BienService.cleanupRelation(contact.bien);

                if (angular.isDefined(contact._id)) {
                    var putPromise = Restangular.one('contacts', contact._id).customPUT(contact);
                    putPromise.then(function (c) {
                        if (service._cache && service._cache.$object) {
                            var oldOne = _.first($filter('filter')(service._cache.$object, {'_id': c._id}));
                            //update in place old cache value
                            if (angular.isDefined(oldOne)) {
                                angular.extend(oldOne, c);
                            } else {
                                service._cache.$object.push(c);
//                                self.cleanCache();
                            }
                        }
                    });
                    return putPromise;
                } else {
                    var postPromise = Restangular.all('contacts').post(contact);
                    postPromise.then(function (res) {
                        if (service._cache) {
                            service._cache.$object.push(res);
                        }
                        return res;
                    });
                    return postPromise;
                }
            },
            registerCall: function (contact, phone) {
                contact.actionsToFollows = contact.actionsToFollows || [];
                contact.actionsToFollows.push({
                    type: 'call',
                    date: new Date(),
                    datas: phone
                });
                return contact;
            },
            registerAgenda: function (contact) {
                return service.registerHistory(contact,  {
                    "type": "prise rdv",
                    "action": "Prise de rendez-vous",
                    "date": new Date()
                });
            },
            registerSms: function (contact, phone, message) {
                return service.registerHistory(contact,  {
                    "type": "Sms",
                    "action": "Envoi d'un sms au : " + phone,
                    "commentaire": message,
                    "date": new Date()
                });
            },
            registerHistory: function (contact, suivi) {
                var today = suivi.date ? new Date(suivi.date):new Date();
                contact.dateDernierContact = today;
                var history = angular.extend({
                    "date": today.getDate() + "/" + (today.getMonth() + 1) + "/" + today.getFullYear(),
                    "dateEvenementLocal": today.toLocaleString().replace(/\//g,'-'), //centurynet format to keep local time YYYY-MM-DD HH-mm-ss
                    "dateEvenement": today
                }, suivi); //type, action, commentaire
                contact.histories ? contact.histories.splice(0,0,history): contact.histories = [history];
                return Restangular
                    .one('contacts', contact._id)
                    .all('history')
                    .post(history)
                    .then(function (c) {
                        angular.extend(contact, c);
                        $rootScope.$emit("history.added", history);
                        return history;
                    });
            },
            supportTextMessage: function (phone) {
                return phone && phone.value && (phone.value.indexOf('06') == 0 || phone.value.indexOf('07') == 0);
            },
            sendSMS: function (contact, num, text) {
                var self = this;
                var success = function () {
                    self.registerSms(contact, num, text);
                    service.closePopup();
                    Toast.show('Sms envoyé.');
                };
                var error = function (e) {
                    $ionicPopup.alert({
                        title: 'Envoi annulé ou impossible',
                        okType: 'button-popup button-assertive',
                        template: e
                    });
                };
                if (typeof sms == 'undefined') {
                    $timeout(function () {
                        error('Cette plateforme ne supporte pas l\'envoi de sms')
                    }, 100);
                } else {
                    self.registerSms(contact, num, text);
                    //always send using native to keep trace of sms
                    //sms.send(num, text, ionic.Platform.isIOS() ? '' : "INTENT", success, error);
                    sms.send(num, text, '', success, error);
                }
            },
            testFollowContactActionsPromise:null,
            testFollowContactActions: function (navigate) {
                var emit = function(hist) {
                    $rootScope.$emit('followTelActions', hist);
                }
                var callbackOK = function () {
                    LocalStorageService.removeValue('savedNavigationAfterCall');
                    service.testFollowContactActionsPromise = null;
                };
                var navigationAfterCall = LocalStorageService.getValue('savedNavigationAfterCall');
                if(navigationAfterCall && angular.isUndefined(service.testFollowContactActionsPromise)) {
                    if(navigationAfterCall.phone !== false) {
                        if(navigate == true) {
                            service.testFollowContactActionsPromise =  $state.go(navigationAfterCall.state, navigationAfterCall).then(function() {
                                return service.followTelActions(navigationAfterCall).then(emit).finally(callbackOK);
                            });
                        } else {
                            service.testFollowContactActionsPromise =   service.followTelActions(navigationAfterCall).then(emit).finally(callbackOK);
                        }
                    } else {
                        LocalStorageService.removeValue('savedNavigationAfterCall')
                    }
                }
                return service.testFollowContactActionsPromise;
            },
            followTelActions: function (infos) {
                var promise = $q.defer();
                if (infos) {
                    var actions = [
                        {text: "Il a répondu"},
                        {text: "Il n'a pas répondu"},
                        {text: "J'ai laissé un message"}
                    ];
                    $ionicActionSheet.show({
                        titleText: "Vous venez d'appeler <b>" + infos.name || '' + "</b>",
                        buttons: actions,
                        destructiveText: 'Annuler',
                        cancelText: '',
                        cancel: promise.reject,
                        buttonClicked: function (index) {
                            //register history
                            var today = infos.date ? new Date(infos.date): new Date();
                            service
                                .registerHistory({_id: infos.id}, {
                                    "action": "Appel téléphonique au : " + infos.phone,
                                    "commentaire": actions[index].text,
                                    "date": today,
                                    "dateEvenement": today,
                                    "type": "Appel"
                                })
                                .then(function(data) {
                                    promise.resolve(angular.extend(data, infos));
                                },  promise.reject);
                            return true;
                        },
                        destructiveButtonClicked: function () {
                            promise.reject('Cancel');
                            return true;
                        }
                    });
                } else {
                    promise.reject();
                }
                return promise.promise;
            },
            callInitiated: function (contact, phone, changeUrl) {
                service.closePopup();
                contact.dateDernierContact = new Date();
                LocalStorageService.saveValue('savedNavigationAfterCall', {
                    state: 'nav.contact.detail',
                    id: contact._id,
                    name: service.formatContact(contact),
                    date: new Date(),
                    openPopUp: true,
                    phone: phone
                });
                if (ionic.Platform.isIOS()) {
                    window.open('tel:' + service.cleanPhone(phone));
                } else if(changeUrl === true) {
                    window.location = 'tel:'+service.cleanPhone(phone);
                }

            },

            cleanPhone: function (phone) {
                return phone?phone.replace(/[\. ,:-;A-Z]+/g, ''):phone;
            },
            getPictureForType: function (type) {
                return pictureByType[type || 'indetermine'].value;
            },
            optimizeContactToList: function (contact) {
                contact.supportTextMessage = _.any(contact.telephones, function (tel) {
                    return service.supportTextMessage(tel)
                });
                contact.listView = {img: service.getPictureForType(contact.dernierStatut)};
                return contact;
            },
            getProjectTypes: function () {
                return [
                    {
                        "filter": "vendeur",
                        "label": "Vendeurs"
                    },
                    {
                        "filter": "prospect",
                        "label": "Prospects"
                    },
                    {
                        "filter": "acquereur",
                        "label": "Acquéreurs"
                    },
                    {
                        "filter": "estimation",
                        "label": "Estimations"
                    },
                    {
                        "filter": "mandat",
                        "label": "Mandats"
                    },
                    {
                        "filter": "locataire",
                        "label": "Locataires"
                    },
                    {
                        "filter": "bailleur",
                        "label": "Bailleurs"
                    }
                ];
            },

            getLastContactValues: function () {
                return [
                    {
                        "filter": 1,
                        "label": "- de 1 mois"
                    },
                    {
                        "filter": 3,
                        "label": "entre 1 et 3 mois"
                    },
                    {
                        "filter": 6,
                        "label": "+ de 3 Mois"
                    }
                ];
            },
            getContactType: function () {
                return [
                    {"filter": "proprietaire", "label": "Propriétaire" },
                    {"filter": "locataire", "label": "Locataire" },
                    {"filter": "bailleur", "label": "Bailleur"},
                    {"filter": "indetermine", "label": "Indetermine"}
                ];
            },
            addSuivi: function (contact, suivi) {
                return service
                    .registerHistory(contact, suivi)
                    .then(function (s) {
                        Toast.show('Suivi enregistré.');
                        return s;
                    });
            },
            callPopup: undefined,
            closePopup: function () {
                $cordovaKeyboard.close();
                if (service.callPopup) {
                    service.callPopup.close();
                }
            },
            showPopup: function (popupToShow, scope, contact, options) {
                if (angular.isUndefined(scope)) {
                    scope = $rootScope.$new();
                }

                if (angular.isUndefined(scope.contact) && contact) {
                    scope.contact = contact;
                }
                var templates = {
                    sms: {
                        templateUrl: 'modules/contact/popup/sms.html',
                        title: 'Envoyer un message' + '<i class="icon ion-ios-chatbubble"></i>',
                        actionButton: {
                            text: 'Envoyer',
                            type: 'btn-send button-popup button-energized',
                            onTap: function () {
                                service.sendSMS(scope.contact, scope.popupDatas.selectedPhone.value, scope.popupDatas.message)
                            }
                        }
                    },
                    call: {
                        templateUrl: 'modules/contact/popup/call.html',
                        title: 'Téléphone' + '<i class="icon ion-ios-telephone"></i>'
                    },
                    email: {
                        templateUrl: 'modules/contact/popup/email.html',
                        title: 'Envoyer un mail' + '<i class="icon ion-ios-email"></i>'
                    },
                    suivi: {
                        templateUrl: 'modules/contact/popup/suivi.html',
                        title: '<i class="icon ion-plus-circled"></i>Note et suivi : '+service.formatContact(scope.contact) ,
                        cssClass: 'add-suivi-popup-detail bigPopup',
                        actionButton: {
                            text: 'Valider',
                            type: 'button-popup button-energized',
                            onTap: function () {
                                service.closePopup();
                                return service.addSuivi(scope.contact, scope.suivi);
                            }
                        }
                    }
                };

                scope.ContactService = service;
                var buttons = [
                    {
                        text: 'Fermer',
                        type: 'button-popup button-grey',
                        onTap: service.closePopup
                    }
                ];

                if (templates[popupToShow].actionButton) {
                    buttons.push(templates[popupToShow].actionButton);
                }
                scope.popupDatas = {};
                service.callPopup = $ionicPopup.show({
                    templateUrl: templates[popupToShow].templateUrl,
                    title: templates[popupToShow].title,
                    scope: scope,
                    buttons: buttons,
                    cssClass: templates[popupToShow].cssClass || 'bigPopup',
                });
                $analytics.eventTrack(popupToShow, {  category: $rootScope.gaCategory, label: popupToShow });
                return service.callPopup;
            },
            removeAdresse: function (contact, adresse) {
                var id = angular.isObject(adresse) ? adresse._id : adresse;
                _.remove(contact.adresseReferences, function (item) {
                    return item.adresseRef === id || (item.adresse && item.adresse._id === id);
                });
                return contact;
            },
            hasAdresse: function (contact, adresse) {
                var id = angular.isObject(adresse) ? adresse._id : adresse;
                var adr = _.find(contact.adresseReferences, function (item) {
                    return item.adresseRef === id || (item.adresse && item.adresse._id === id);
                });
                return angular.isDefined(adr);
            },
            addAdresseOnContactIfNeed: function (contact, adresse) {
                if (!service.hasAdresse(contact, adresse)) {
                    contact.adresseReferences.push(AdresseService.newAdresseLink(adresse));
                    service
                        .save(contact)
                        .then(function (contact) {
                            service.showSaveToast();
                        });
                }
            },
            /** Call when adding a new adresse on contact
             * Have to check if a bien exist on that adresse et if we add a new link on this
             **/
            addAdresseOnAdresseLink: function (contact, adresse, forceCreation, bien) {
                var deferred = $q.defer();
                //verify if relation already exist
                if (!bien && adresse.immeuble && adresse.immeuble._id) {
                    BienService
                        .all({immeubleRef: adresse.immeuble._id})
                        .then(function (biens) {
                            if (biens.length == 0) {
                                service.showCreateBienPopup(contact, adresse, null, deferred, forceCreation);
                            } else {
                                var matchedBiens = BienService.filterBiensForContact(biens, contact._id);
                                if (matchedBiens.length === 0) {
                                    service.showCreateBienPopup(contact, adresse, biens, deferred, forceCreation);
                                } else {
                                    console.log('contact already has a relation on :', matchedBiens[0]);
                                }
                            }
                        });
                } else {
                    service.showCreateBienPopup(contact, adresse, bien, deferred, forceCreation);
                }
                return deferred.promise;
            },
            linkBienAndContact: function (adresse, bien, contact, biens, defered, relation, popupTitle) {
                defered = defered || $q.defer();
                var dateDebut = new Date();
                relation = relation || {contactRef: contact._id, contact: contact, dateDebut: dateDebut, contactString: service.formatContact(contact)};

                if (angular.isUndefined(bien.relations)) {
                    bien.relations = [];
                }
                if (angular.isUndefined(bien.immeubleRef)) {
                    bien.immeubleRef = adresse.immeuble._id;
                }
                //creation ou choix
                var scope = $rootScope.$new();
                //in scope subobject to avoid scope shading
                scope.datas = {
                    canChoose: angular.isUndefined(bien._id),
                    newBien: bien,
                    currentBien: (!bien && biens && biens.length > 0) ? biens[0] : bien,
                    biens: biens,
                    relation: relation,
                    contact: contact,
                    dateDebut: dateDebut
                };

                scope.popup = $ionicPopup.show({
                    title: popupTitle || 'Ajout du bien',
                    templateUrl: 'modules/contact/popup/contact-bien-link.html',
                    scope: scope,
                    cssClass: 'bigPopup',
                    buttons: [
                        {
                            text: i18n('cancel'),
                            type: 'button-popup',
                            onTap: function () {
                                $cordovaKeyboard.close();
                                scope.popup.close();
                                defered.reject();
                            }
                        },
                        {
                            text: i18n('save'),
                            type: 'button-popup button-energized',
                            onTap: function (event) {
                                $cordovaKeyboard.close();
                                scope.datas.relation.type = scope.datas.relation.type || 'indetermine';
                                if(angular.isUndefined(scope.datas.currentBien._class)) {
                                    Toast.show('Veuillez choisir un bien', 'long');
                                    event.preventDefault();
                                    return;
                                }
                                //search for relation in bien .relation
                                if(!scope.datas.relation._id) {
                                    if(scope.datas.currentBien.relations.indexOf(scope.datas.relation)<0) {
                                        scope.datas.currentBien.relations.push(scope.datas.relation);
                                    }
                                } else {
                                    if(_.filter(scope.datas.currentBien.relations, function(item) {return item._id == scope.datas.relation._id}).length==0) {
                                        scope.datas.currentBien.relations.push(scope.datas.relation);
                                    }
                                }

                                BienService.save(scope.datas.currentBien).then(function (bien) {
                                    //inject new id in relation to  disabled input
//                                    for (var i = 0, l = bien.relations.length; i < l; i++) {
//                                        var one = bien.relations[i];
//                                        if (relation.contactRef == one.contactRef &&
//                                            relation.type == one.type) {
//                                            relation._id = one._id;
//                                            break;
//                                        }
//                                    }
                                    relation.bien = bien;
                                    defered.resolve(bien);
                                    Toast.show('Mise à jour terminée');
                                    scope.popup.close();
                                    scope.$destroy();
                                });
                            }
                        }
                    ]
                });
                return defered.promise;
            },

            showCreateBienPopup: function (contact, adresse, biens, deferred, force) {
                deferred = deferred || $q.defer();
                var showCreateBienPopup = function () {
                    if (!adresse.immeuble || !adresse.immeuble._id) {
                        AdresseService
                            .get(adresse._id, {withAround: false, withBiens: true}).then(function(adresse) {
                                if (!adresse.immeuble || !adresse.immeuble._id) {
                                    adresse.immeuble = {
                                        nbBienPotentiel: 1,
                                        nbBienProspectes: 1
                                    };
                                    //add immeuble on adress
                                    AdresseService.save(adresse).then(function (adresse) {
                                        service.linkBienAndContact(adresse, {immeubleRef: adresse.immeuble._id}, contact, biens, deferred);
                                    });
                                } else {
                                    var defaultBien = {immeubleRef: adresse.immeuble._id};
                                    //detect kind of bien existing
                                    if(adresse.immeuble.biens && adresse.immeuble.biens && adresse.immeuble.biens.length>0 &&
                                        BienService.isBienImmeuble(adresse.immeuble.biens[0])) {
                                        defaultBien._class = '.BienAppartement';
                                        defaultBien.nbEtages = adresse.immeuble.biens[0].nbEtages;
                                        defaultBien.choixPaliers = adresse.immeuble.biens[0].choixPaliers;

                                    }
                                    service.linkBienAndContact(adresse, defaultBien, contact, biens, deferred);
                                }
                            })
                    } else {
                        var defaultBien = angular.isArray(biens)?{immeubleRef:adresse.immeuble._id}:biens;
                        service.linkBienAndContact(adresse, defaultBien, contact, angular.isArray(biens)?biens:[], deferred);
                    }
                };
                if (force === true) {
                    showCreateBienPopup();
                } else {
                    //voulez créer le bien et de quel type avec quel relation
                    $ionicPopup.confirm({
                        title: i18n((biens ? 'setbien' : 'addbien') + '.confirmation.title'),
                        template: i18n((biens ? 'setbien' : 'addbien') + '.confirmation.text'),
                        buttons: [{
                            text: i18n('action.no'),
                            type: 'button-popup button-dark',
                            onTap: function (e) {
                                return false;
                            }
                        }, {
                            text: i18n('action.yes'),
                            type: 'button-popup button-energized',
                            onTap: function (e) {
                                return true;
                            }
                        }]
                    }).then(function (res) {
                        if (res) {
                            showCreateBienPopup();
                        } else {
                            deferred.reject("cancel");
                        }
                    });
                }
                return deferred.promise;
            },
            newContactForm: function (adresse, bien, options) {
                options = _.defaults(options || {}, {
                    forceBienCreation : false,
                    addAdresseWF: true,
                    lastName:'',
                    firstName:''
                });
                var deferred = $q.defer();

                var contextContacts = {adresse: adresse, bien: bien, nom: options.lastName, prenom:options.firstName};
                var scope = angular.extend($rootScope.$new(), {
                    creation: true,
                    contextContacts: contextContacts,
                    contact: service.loadContact('new', contextContacts, false),
                    saveNewContact: function () {
                        $ionicLoading.show(SavingConfig);
                        service
                            .save(scope.contact)
                            .then(function (savedContact) {
                            scope.closeModal();
                            if(options.addAdresseWF == true) {
                                service
                                    .addAdresseOnAdresseLink(savedContact, adresse, forceBienCreation, bien)
                                    .then(function (bien) {
                                        //attach created bien on prospect
                                        if (savedContact.projets && savedContact.projets.length > 0) {
                                            if(bien._class === '.BienImmeuble'){
                                                savedContact.projets[0].bienRef = bien.appartements[bien.appartements.length-1]._id;
                                            } else {
                                                savedContact.projets[0].bienRef = bien._id;
                                            }
                                            service.save(savedContact).then(deferred.resolve).finally(service.showSaveToast)
                                        } else {
                                            deferred.resolve();
                                            service.showSaveToast();
                                        }
                                    },
                                    deferred.reject);
                            } else {
                                deferred.resolve(savedContact)
                            }
                        }).finally($ionicLoading.hide);
                    },
                    closeModal: function (cancel) {
                        $cordovaKeyboard.close();
                        scope.modal.hide().then(function () {
                            scope.modal.remove();
                            scope.$destroy();
                            if (cancel === true) {
                                deferred.reject("cancel");
                            }
                        });
                    }
                });
                $ionicModal.fromTemplateUrl('modules/contact/popup/contact-new.html', {
                    scope: scope,
                    backdropClickToClose:false,
                    animation: 'slide-in-up'
                }).then(function (modal) {
                    scope.modal = modal;
                    modal.show();
                });
                return deferred.promise;
            },

            getContactPictureClass: function(type) {
                switch(type ) {
                    case 'proprietaire' :  return 'owner';
                    case 'locataire' :  return 'tenant';
                    case 'bailleur' :  return 'lessor';
                    default :  return 'undefined';
                }
            },
            getPictureClass: function(relation) {
                if(!relation) {
                    return '';
                }
                return service.getContactPictureClass(relation.type);
            },
            newGardienRelation: function ( gardienContact) {
                return {
                    dateDebut: new Date(),
                    contact: gardienContact,
                    contactString: service.formatContact(gardienContact),
                    contactRef: gardienContact._id,
                    type: 'gardien'
                };
            },
            mergeContactInfos: function (src, dst) {
                var mergeArr = function (arr, destArr, attributeToTest) {
                    angular.forEach(arr, function (srcVal) {
                        var found = false;
                        var valToTest = attributeToTest?srcVal[attributeToTest]:srcVal;
                        console.log('src', valToTest);
                        angular.forEach(destArr, function (val) {
                            if(found === false) {
                                if (attributeToTest) {
                                    val = val[attributeToTest];
                                }
                                console.log('dest', val);
                                found = (val == valToTest);
                            }
                        });
                        if(found === false && valToTest != '') {
                            destArr.push(srcVal);
                        }
                    });
                };
                mergeArr(src.telephones, dst.telephones, 'value');
                mergeArr(src.emails, dst.emails, 'value');
                mergeArr(src.adresseReferences, dst.adresseReferences, 'adresseRef');
                dst.civilite = dst.civilite || src.civilite;
                dst.nom = dst.nom || src.nom;
                dst.prenom = dst.prenom || src.prenom;
                return dst;
            }
        };
        return service;
    });
