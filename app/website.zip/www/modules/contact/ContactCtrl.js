'use strict';
angular
    .module('module.contact')
    .controller('ContactCtrl', function ($scope, $state, $stateParams, $ionicPopup, LoadingConfig, ContactService, LocalStorageService, $ionicLoading) {
        $ionicLoading.show(LoadingConfig);
        //work around to avoid using $object on contact
        console.log("ContactCtrl loading contact id=>",$stateParams.id);
        //ContactService.loadContact($stateParams.id, angular.extend($scope.contextContacts || {}, {callback:function(contact) {
        //    $scope.contact = contact;
        //    $ionicLoading.hide();
        //}}), $state.is('nav.contact.edit'));
        angular.extend($scope, {
            //https://github.com/mgonto/restangular/issues/811
            contact: ContactService.loadContact($stateParams.id, angular.extend($scope.contextContacts || {}, {callback:$ionicLoading.hide}), $state.is('nav.contact.edit')),
            ContactService: ContactService,
            $state: $state,
            message: {},
            datas:{},
            selectedPhone: {},
            suivi: {},
            selectedEmail: {},

            saveDescription: function (contact) {
                ContactService.save(Restangular.copy(contact)).then(function(savedContact) {
                    $scope.contact = savedContact;
                    $scope.datas.modifiedDescription = false;
                });
            },
            cancelDescription: function () {
                $scope.contact = ContactService.loadContact($stateParams.id, $scope.contextContacts, $state.is('nav.contact.edit'));
                $scope.datas.modifiedDescription = false;
            },
            moveCursorToEnd: function (event) {
                var el = event.currentTarget;
                if (typeof el.selectionStart == "number") {
                    el.selectionStart = el.selectionEnd = el.value.length;
                } else if (typeof el.createTextRange != "undefined") {
                    el.focus();
                    var range = el.createTextRange();
                    range.collapse(false);
                    range.select();
                }
            },
            toggle100premiers: function () {
                $scope.contact.premier100 = !$scope.contact.premier100;
                ContactService.save($scope.contact);
            }


        });
    });
