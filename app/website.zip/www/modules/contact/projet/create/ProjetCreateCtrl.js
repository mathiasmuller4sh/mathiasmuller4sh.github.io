'use strict';
angular
    .module('module.contact')
    .controller('ProjetCreateCtrl', function ($scope, $state, $stateParams, $ionicPopup, $timeout, leafletData, ContactService, BienService, AdresseService, MapService) {
        angular.extend($scope, {
        });


        var contactBiensPromise = ContactService.getBiensForContact($scope.contact._id);
        $scope.availableBiens= contactBiensPromise.$object;

        contactBiensPromise.then(function () {
            //TODO: charger les données coté serveur
            if ($scope.availableBiens) {
                $scope.availableBiens.forEach(function (bien) {
                    AdresseService.getAdresseForImmeuble(bien.immeubleRef).then(function (adresse) {
                        bien.formatedAdresse = AdresseService.getFormatedAdresse(adresse);
                    })
                });
            }
        }).finally(function () {
            if ($scope.selectedProject) {
                $scope.relatedBien = _.find($scope.availableBiens, function (obj) {
                    return obj._id === $scope.selectedProject.bienRef
                });
            }
        });
    });
