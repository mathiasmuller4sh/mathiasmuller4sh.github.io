'use strict';
angular
    .module('module.contact')
    .controller('ProjetCtrl', function ($scope, $state, $stateParams, $ionicPopup, $timeout, leafletData,
                                        Toast, ContactService, BienService, AdresseService, MapService) {
        angular.extend($scope, {
            withMap: [//prospect/estime/mandat/mandat/vendeur/acquereur/locataire
                'estime', 'estimation', 'mandat', 'vendeur', 'simple', 'confiance', 'exclusif', 'vert'
            ],
            templatesByType: {
                acquereur: 'modules/contact/projet/view/projet-acquereur-view.html',
                vendeur: 'modules/contact/projet/view/projet-with-map-view.html',
                mandat: 'modules/contact/projet/view/projet-with-map-view.html',
                simple: 'modules/contact/projet/view/projet-with-map-view.html',
                exclusif: 'modules/contact/projet/view/projet-with-map-view.html',
                confiance: 'modules/contact/projet/view/projet-with-map-view.html',
                vert: 'modules/contact/projet/view/projet-with-map-view.html',
                estime: 'modules/contact/projet/view/projet-with-map-view.html',
                estimation: 'modules/contact/projet/view/projet-with-map-view.html',
                prospect: 'modules/contact/projet/view/projet-with-map-view.html',
                locataire: 'modules/contact/projet/view/projet-locataire-view.html',
                bailleur: 'modules/contact/projet/view/projet-with-map-view.html'
            },
            leafletContact: function () {
                var conf = MapService.getMapConfiguration();
                conf.defaults.zoom = 9;
                conf.defaults.zoomControl = false;
                conf.defaults.attributionControl = false;
                conf.defaults.controls.layers.visible = false;
                conf.center.zoom = 9;
                delete conf.layers.baselayers.hybrid;
                return conf;
            }(),
            init: function (project) {
                $scope.projet = project;
                if (!project) {
                    $scope.relatedBien = null;
                } else if (project.bienRef) {
                    BienService
                        .get(project.bienRef, {complet: true})
                        .then(function (bien) {
                            $scope.projet.bien = bien;
                            $scope.relatedBien = bien;
                            if (bien && bien.adresse) {
                                $scope.leafletContact.markers = MapService.getMarkersForProjet($scope.projet);
                                var center;
                                if (bien.adresse.location) {
                                    var geojson = MapService.getGeojsonFrom(bien, function (bien) {
                                        return bien.adresse ? bien.adresse.location : null;
                                    });
                                    center = geojson.features[0];
                                } else {
                                    console.error('Adresse sans geoloc', bien);
                                    center = {coordinates: [1.87528, 46.60611]};
                                }
                                //$timeout(function() {MapService.centerOnFeature($scope.leafletContact, center, false)}, 100);
                            } else {
                                Toast.show("Adresse du projet à corriger dans CenturyNet");
                                console.error('Bien sans adresse', bien);
                            }
                        });
                } else if ($scope.contact) {
                    var geojsonFromAdresse = MapService.getGeojsonFrom($scope.contact.adresseReferences, function (link) {
                        return link.adresse.location;
                    });
                    $scope.leafletContact.markers = MapService.getMarkersFromAdresse($scope.contact);
                    if (geojsonFromAdresse.features.length === 1) {
                        $timeout(function () {
                            MapService.centerOnFeature($scope.leafletContact, geojsonFromAdresse.features[0], true)
                        }, 300);
                    } else {
                        //try to zoomout bouding box TODO : fix
                        MapService.setFeatures(geojsonFromAdresse, $scope.leafletContact);
                        $timeout(function () {
                            MapService.matchBoundsToGeoJson(leafletData, $scope.leafletContact);
                            MapService.removeFeatures($scope.leafletContact);
                        }, 800);
                    }
                }
            },
            showTitle: function (projet) {
                return projet && projet.type != 'vendeur';
            },
            toggleQualificationProjet: function (currentQualification, project) {
                switch (currentQualification) {
                    case 'A' :
                        project.qualificationProjet = 'B';
                        break;
                    case 'B' :
                        project.qualificationProjet = 'C';
                        break;
                    case 'C' :
                        project.qualificationProjet = 'A';
                        break;
                }
                ContactService.save($scope.contact);
            }
        });
        //select project on load
        $scope.$watch('selectedProject', $scope.init);
        console.log('ProjetCtrl init')
    });
