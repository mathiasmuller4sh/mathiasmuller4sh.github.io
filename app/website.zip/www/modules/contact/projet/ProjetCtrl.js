'use strict';
angular
    .module('module.contact')
    .controller('ProjetCtrl', function ($scope, $state, $stateParams, $ionicPopup, $timeout, leafletData,
                                        Toast, ContactService, BienService, AdresseService, MapService) {
        angular.extend($scope, {
            withMap:[//prospect/estime/mandat/mandat/vendeur/acquereur/locataire
                'estime', 'estimation', 'mandat', 'vendeur', 'simple', 'confiance', 'exclusif', 'vert'
            ],
            templatesByType: {
                acquereur: 'modules/contact/projet/view/projet-acquereur-view.html',
                vendeur: 'modules/contact/projet/view/projet-vendeur-view.html',
                mandat: 'modules/contact/projet/view/projet-mandat-view.html',
                simple: 'modules/contact/projet/view/projet-mandat-view.html',
                exclusif: 'modules/contact/projet/view/projet-mandat-view.html',
                confiance: 'modules/contact/projet/view/projet-mandat-view.html',
                vert: 'modules/contact/projet/view/projet-mandat-view.html',
                estime: 'modules/contact/projet/view/projet-estimation-view.html',
                estimation: 'modules/contact/projet/view/projet-estimation-view.html',
                prospect: 'modules/contact/projet/view/projet-prospect-view.html',
                locataire: 'modules/contact/projet/view/projet-locataire-view.html',
                bailleur: 'modules/contact/projet/view/projet-bailleur-view.html'
            },
            leafletContact: function() {
                var conf = MapService.getMapConfiguration();
                conf.defaults.zoom = 9;
                conf.center.zoom = 9;
                return conf;
            }(),
            init: function (project) {
                $scope.projet = project;
                if (!project) {
                    $scope.relatedBien = null;
                } else if (project.bienRef) {
                    BienService.get(project.bienRef, {complet: true}).then(function (bien) {
                        $scope.projet.bien = bien;
                        $scope.relatedBien = bien;
                        if (bien && bien.adresse) {
                            if(bien.adresse.location) {
                                var geojson = MapService.getGeojsonFrom(bien, function (bien) {
                                    return bien.adresse ? bien.adresse.location : null;
                                });
                                $scope.leafletContact.markers = MapService.getMarkersForProjet($scope.projet);
                                if (geojson.features.length > 0) {
                                    $timeout(function() {MapService.centerOnFeature($scope.leafletContact, geojson.features[0], false)}, 100);
                                }
                            } else {
                                $scope.leafletContact.markers = MapService.getMarkersForProjet($scope.projet);
                                $timeout(function() {
                                    MapService.centerOnFeature($scope.leafletContact, {coordinates:[1.87528, 46.60611 ]}, false)
                                    //$scope.leafletContact.center.zoom = 8;
                                }, 100);

                                //Toast.show("Adresse du projet à corriger dans CenturyNet");
                                console.error('Adresse sans geoloc', bien);
                            }
                        } else {
                            Toast.show("Adresse du projet à corriger dans CenturyNet");
                            console.error('Bien sans adresse', bien);
                        }
                    });
                } else if ($scope.contact) {
                    var geojsonFromAdresse = MapService.getGeojsonFrom($scope.contact.adresseReferences, function (link) {
                        return link.adresse.location;
                    });
                    $scope.leafletContact.markers = MapService.getMarkersFromAdresse($scope.contact);
                    if (geojsonFromAdresse.features.length === 1) {
                        $timeout(function() {MapService.centerOnFeature($scope.leafletContact, geojsonFromAdresse.features[0], true)}, 300);
                    } else {
                        //try to zoomout bouding box TODO : fix
                        MapService.setFeatures(geojsonFromAdresse, $scope.leafletContact);
                        $timeout(function () {
                            MapService.matchBoundsToGeoJson(leafletData, $scope.leafletContact);
                            MapService.removeFeatures($scope.leafletContact);
                        }, 800);
                    }
                }
            },
            showTitle: function (projet) {
                return projet && projet.type != 'vendeur';
            },
            //TODO remove useless
            showProjectMap: function () {
                return ($scope.selectedProject && ($scope.withMap.indexOf($scope.selectedProject.type)>-1 || $scope.selectedProject.type.indexOf('mandat') > -1))
                || ($scope.selectedProject.type === 'prospect' && $scope.contact && $scope.contact.adresseReferences && $scope.contact.adresseReferences.length > 0);
            },
            toggleQualificationProjet: function (currentQualification, project) {
                switch (currentQualification) {
                    case 'A' :
                        project.qualificationProjet = 'B';
                        break;
                    case 'B' :
                        project.qualificationProjet = 'C';
                        break;
                    case 'C' :
                        project.qualificationProjet = 'A';
                        break;
                }
                ContactService.save($scope.contact);
            }
        });
        //local configuration override
        $scope.leafletContact.markers = {};
        $scope.leafletContact.defaults.zoomControl = false;
        $scope.leafletContact.defaults.attributionControl = false;
        delete $scope.leafletContact.layers.baselayers.hybrid;
        //select project on load
        $scope.$watch('selectedProject', $scope.init);
    });
