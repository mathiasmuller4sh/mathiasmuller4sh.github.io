'use strict';
angular
    .module('module.contact')
    .controller('ContactProjectCtrl', function ($scope, $timeout, $state, $stateParams, Restangular, ConfigDictionary) {
        angular.extend($scope, {
            title:'Détail Projet',
            hasTabs:false,
            serverUrl: ConfigDictionary.serverUrl,
            item: function() {
                if($scope.contact.projects) {
                    return $scope.contact.projects[$stateParams.index].property;
                } else {
                    //todo load
                    //Restangular.one('contacts', $stateParams.id).getList('projects').$object
                }
            }()
        })
    });
