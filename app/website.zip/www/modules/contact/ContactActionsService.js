angular
    .module('module.contact')
    .factory('ContactActionsService', function ($rootScope, $q, $filter, $ionicPopup, $ionicLoading, SavingConfig, BienService, ContactService) {
        var i18n = $filter('i18n');

        var service = {
            removeAndAddNewPopUp: function (relation, bien) {
                var $scope = $rootScope.$new();
                angular.extend($scope, {
                    bien: relation.bien || bien,
                    newRelation: {
                        dateDebut: new Date(),
                        bien: relation.bien
                    }
                });

                var savedFin = relation.dateFin;
                BienService.endRelation(relation);
                var close = function () {
                    popup.close();
//                    popup.remove();
                };
                var cancelCallback = function () {
                    relation.dateFin = savedFin;
                    close();
                };
                var popup = $ionicPopup.show({
                    templateUrl: 'modules/bien/popup/add-relation.html',
                    title: i18n('add.relation'),
                    scope: $scope,
                    cssClass: 'bigPopup',
                    buttons: [{
                        text: i18n('cancel'),
                        type: 'button-popup button-dark',
                        onTap: cancelCallback
                    }]
                });
                //autoclose when add a contact since workflow handle by ContactPickerdirective
                //not optimal
                var toClear = [];
                toClear.push($rootScope.$on('contactPicker.end', close));
                toClear.push($rootScope.$on('contactPicker.createContact.start', close));
                toClear.push($rootScope.$on('contactPicker.cancel', cancelCallback));
                popup.finally(function () {
                    angular.forEach(toClear, function (fn) {
                        fn();
                    })
                    $scope.$destroy();
                })

            },
            openConfirmRemovePopUp: function (relation, bien) {
                bien = bien || relation.bien;
                if (relation._id) {
                    var name = relation.contact ? ContactService.formatContact(relation.contact) : relation.contactString;
                    var statusStr = (relation.type && relation.type != ContactService.status.indetermine) ? 'l\'actuel(le) ' + i18n(relation.type) : ' lié(e) à ce bien';
                    $ionicPopup.confirm({
                        title: 'Merci de confirmer',
                        template: '<span><img class="type-picture" style="width:32px;" src="' + ContactService.getPictureForType(relation.type) + '"><span style="vertical-align: super; display:initial;top:0"> ' + name + ' n\'est plus ' + statusStr + '?</span></span>',
                        cssClass:'confirm-popup',
                        cancelText: 'Annuler',
                        cancelType: 'button-grey button-popup',
                        okText: 'Valider',
                        okType: 'button-energized button-popup'
                    }).then(function (choice) {
                        if (choice) {
                            service.removeRelation(relation, bien);
                        }
                    });
                } else {
                    service.removeRelation(relation, bien);
                }
            },
            removeRelation: function (relation, bien) {
                bien = bien || relation.bien;
                if (relation._id) {
                    if (BienService.isBienImmeuble(bien)) {
                        bien = relation.bien;
                    }
                    //not enougth since  we copy object..
                    BienService.endRelation(relation);
                    if (bien && bien.relations) {
                        //need to iter..
                        for (var i = 0, l = bien.relations.length; i < l; i++) {
                            var one = bien.relations[i];
                            if (one._id == relation._id) {
                                BienService.endRelation(one);
                                // do not break to fix relation duplication
                                //break;
                            }
                        }
                    }
                    return BienService.save(bien).then(function (savedBien) {
                        //$scope.bien.relations = savedBien.relations;
                        if (BienService.isBienImmeuble(bien)) {
                            relation.bien = savedBien;
                        }
                        //update relations
                        for (var i = 0, l = bien.relations.length; i < l; i++) {
                            var one = bien.relations[i];
                            if (one._id == relation._id) {
                                bien.relations.splice(i, 1);
                                break;
                            }
                        }
                        ContactService
                            .save(ContactService.removeAdresse(relation.contact, bien.adresse))
                            .then(ContactService.showSaveToast)
                        //.finally($scope.closeQuickActionModal);
                    });
                } else {
                    bien.relations.splice(bien.relations.indexOf(relation), 1);
                }
            },
            addSuiviOnBien: function (bien, scope) {
                return service
                    .selectContactPopup(bien, {
                        title: 'Quel habitant avez vous vu ?',
                        popupText: '',
                        cssClass:'add-suivi-popup bigPopup'
                    })
                    .then(function (relation) {
                        return ContactService
                            .showPopup('suivi', angular.extend(scope, {suivi: {}}), relation.contact);
                    });
            },
            selectContactPopup: function (bien, options) {
                options = options || {};
                var deferred = $q.defer();
                var relations = $filter('filter')(bien.relations, function (rel) {
                    return BienService.isValidRelation(rel);
                });

                if(relations.length == 1) {
                    //auto select the only choice
                    deferred.resolve(relations[0]);
                } else {
                    var scope = angular.extend($rootScope.$new(), {
                        BienService: BienService,
                        bien: angular.copy(bien, {
                            relations: relations
                        }),
                        popupText: options.popupText || '',
                        selectContact: function (selectedRelation) {
                            popup.close();
                            deferred.resolve(selectedRelation)
                        }
                    });
                    var popup = $ionicPopup.show({
                        scope: scope,
                        title: options.title || '',
                        cssClass: options.cssClass || 'bigPopup',
                        buttons: [{
                            text: 'Annuler',
                            type: 'button-grey button-popup',
                            onTap: function (e) {
                                deferred.reject('cancel');
                                popup.close();
                            }
                        }],
                        templateUrl: 'modules/contact/popup/choose-contact-popup.html'
                    });
                    popup.finally(function () {
                        scope.$destroy();
                    });
                }
                return deferred.promise;
            },

            mergePopup: function (relation, bien) {
                var deferred = $q.defer();
                console.log('relation',relation._id);
                var scope = angular.extend($rootScope.$new(), {
                    BienService: BienService,
                    selectedRelation: undefined,
                    contactSrc: relation.contactString,
                    bien: angular.extend({}, bien, {
                        relations: $filter('filter')(bien.relations, function (rel) {
                            console.log('match',BienService.isValidRelation(rel) && rel._id != relation._id);
                            return BienService.isValidRelation(rel) && rel._id != relation._id;
                        })
                    }),
                    selectContact: function (selectedRelation) {
                        scope.selectedRelation = selectedRelation;
                        $ionicPopup.confirm({
                                title: 'Merci de confirmer',
                                template: '<span class="calm">Vous êtes sur le point de remplacer </span><br/><span class="dark">' + selectedRelation.contactString + '</span><br/><span class="calm">par:</span><br/><span class="dark">' + relation.contactString+'</span>',
                                cancelText: 'Annuler',
                                okType: 'button-energized',
                                okText: 'Remplacer'
                            }
                        ).then(function (ok) {
                                if (ok === true) {
                                    popup.close();
                                    $ionicLoading.show(SavingConfig);
                                    BienService
                                        .merge(relation.bien, relation.contactRef, selectedRelation.bien, selectedRelation.contactRef)
                                        .then(function(immeuble) {
                                            $ionicLoading.hide();
                                            ContactService.showSaveToast();
                                            deferred.resolve(immeuble);
                                        })
                                        .finally(popup.close);
                                }
                            });
                    }
                });

                var popup = $ionicPopup.show({
                    scope: scope,
                    title: 'Fusion d\'habitant',
                    cssClass: 'bigPopup',
                    buttons: [{
                        text: 'Annuler',
                        type: 'button-grey button-popup',
                        onTap: function (e) {
                            deferred.reject('cancel');
                            popup.close();
                        }
                    }],
                    templateUrl: 'modules/contact/popup/contact-fusion-list.html'
                });
                popup.finally(function () {
                    scope.$destroy();
                });
                return deferred.promise;
            }
        };
        return service;
    });
