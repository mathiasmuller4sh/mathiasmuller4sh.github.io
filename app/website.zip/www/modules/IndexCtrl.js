'use strict';
angular
    .module('menu.index', [])
    .controller('IndexCtrl', function ($rootScope, $scope, $state, ConfigDictionary, HomeService, Restangular) {


        angular.extend($rootScope, {
            serverUrl:ConfigDictionary.serverUrl,
            logoBtn: {
                type: 'button-clear',
                content: '<img class="button-clear button-icon" src="img/logo_century21.png">',
                tap: function (e) {
                }
            }
        });

        angular.extend($scope, {
            menus: HomeService.allMenus(),
            $state: $state,
            home: {
                searchEnabled: false
            }
        });
    });
