'use strict';
angular
    .module('module.photo')
    .factory('PhotoService', function (ConfigDictionary, $rootScope, $http, Toast, $timeout) {

        var service = {
            uploadServerUrl: ConfigDictionary.serverUrl + '/pictureupload',
            downloadServerUrl: ConfigDictionary.serverUrl + '/pictures',


            getUrl: function (image) {
                if (image && image.url) {
                    if (image.url.indexOf('//') !== -1) {
                        return image.url;
                    }
                    return service.downloadServerUrl +'?imageName='+ encodeURIComponent(image.url);
                }
                return null;
            },
            takePicture: function (callback, existing) {
                if (navigator.camera) {
                    navigator.camera.getPicture(function (imageURI) {
                            $timeout(function () {
                                callback(imageURI);
                            }, 100)
                        },
                        function (error) {
                            //Toast.show('Un probleme est survenu avec l\'appareil photo.('+error+')');
                            console.log(error);
                        }, {
                            quality: 75,
                            destinationType: Camera.DestinationType.FILE_URI,
                            sourceType: existing ? Camera.PictureSourceType.PHOTOLIBRARY : Camera.PictureSourceType.CAMERA,
                            encodingType: Camera.EncodingType.JPEG,
                            correctOrientation: true,
                            targetWidth: 720,
                            targetHeight: 720
                        });
                } else {
                    //Desktop
                    if(document.getElementById("desktopUpload")) {
                        document.getElementById("desktopUpload").click();
                    } else {
                        console.error("Add a input type file (id='desktopUpload') to make it works on desktop")
                    }
                }
            },

            /**
             * - callbacks objects contains listeners
             * callbacks.progress, callbacks.success, callbacks.error
             *
             *
             * progress callback will receive progressEvent (progressEvent.lengthComputable, progressEvent.loaded,  progressEvent.total)
             * */
            send: function (fileURL, optionsParams) {
                //codorva
                if (ionic.Platform.isWebView()) {

                    var options = new FileUploadOptions();
                    options.fileKey = "file";
                    options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
                    options.filename = fileURL.substr(fileURL.lastIndexOf('/') + 1);
                    options.mimeType = "image/jpeg";

                    options.params = optionsParams.serverParams || {};

                    var ft = new FileTransfer();
                    ft.onprogress = optionsParams.progress;
                    ft.upload(fileURL, encodeURI(service.uploadServerUrl), function (data) {
                        if (optionsParams.success) {
                            var resp = data.response;
                            var json = {};
                            if(resp && resp != '') {
                                try {
                                    json = angular.fromJson(data.response);
                                } catch (e) {
                                    console.log("PhotoService: Unable to read response:" + data.response+ '('+e+')');
                                }
                            }
                            optionsParams.success(json);
                        }
                    }, optionsParams.error, options);
                    return ft;
                } else {
                    //desktop
                    var formData = new FormData();
                    formData.append('file', optionsParams.file);
                    formData.append('filename', optionsParams.file.name);
                    angular.forEach(optionsParams.serverParams, function (val, key) {
                        formData.append(key, val);
                    });

//                    var request = new XMLHttpRequest();
//                    request.open("POST", service.uploadServerUrl);
//                    request.send(formData);
                    $http.post(
                        service.uploadServerUrl,
                        formData, {
                            transformRequest: angular.identity,
                            headers: {'Content-Type': undefined}
                        })
                        .success(optionsParams.success)
                        .error(optionsParams.error);
                }
            }
        };
        return service;

    });
