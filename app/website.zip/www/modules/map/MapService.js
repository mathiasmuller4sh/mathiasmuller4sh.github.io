'use strict';

angular
    .module('module.map')
    .factory('MapService', function (Restangular, $filter, $rootScope, $state, leafletHelpers,
                                     Session, ContactService, AdresseService, BienService, LocalStorageService) {
        var i18n = $filter('i18n');
        var map = Restangular.one('map');
        var base64shadow = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACkAAAApCAYAAACoYAD2AAAC5ElEQVRYw+2YW4/TMBCF45S0S1luXZCABy5CgLQgwf//S4BYBLTdJLax0fFqmB07nnQfEGqkIydpVH85M+NLjPe++dcPc4Q8Qh4hj5D/AaQJx6H/4TMwB0PeBNwU7EGQAmAtsNfAzoZkgIa0ZgLMa4Aj6CxIAsjhjOCoL5z7Glg1JAOkaicgvQBXuncwJAWjksLtBTWZe04CnYRktUGdilALppZBOgHGZcBzL6OClABvMSVIzyBjazOgrvACf1ydC5mguqAVg6RhdkSWQFj2uxfaq/BrIZOLEWgZdALIDvcMcZLD8ZbLC9de4yR1sYMi4G20S4Q/PWeJYxTOZn5zJXANZHIxAd4JWhPIloTJZhzMQduM89WQ3MUVAE/RnhAXpTycqys3NZALOBbB7kFrgLesQl2h45Fcj8L1tTSohUwuxhy8H/Qg6K7gIs+3kkaigQCOcyEXCHN07wyQazhrmIulvKMQAwMcmLNqyCVyMAI+BuxSMeTk3OPikLY2J1uE+VHQk6ANrhds+tNARqBeaGc72cK550FP4WhXmFmcMGhTwAR1ifOe3EvPqIegFmF+C8gVy0OfAaWQPMR7gF1OQKqGoBjq90HPMP01BUjPOqGFksC4emE48tWQAH0YmvOgF3DST6xieJgHAWxPAHMuNhrImIdvoNOKNWIOcE+UXE0pYAnkX6uhWsgVXDxHdTfCmrEEmMB2zMFimLVOtiiajxiGWrbU52EeCdyOwPEQD8LqyPH9Ti2kgYMf4OhSKB7qYILbBv3CuVTJ11Y80oaseiMWOONc/Y7kJYe0xL2f0BaiFTxknHO5HaMGMublKwxFGzYdWsBF174H/QDknhTHmHHN39iWFnkZx8lPyM8WHfYELmlLKtgWNmFNzQcC1b47gJ4hL19i7o65dhH0Negbca8vONZoP7doIeOC9zXm8RjuL0Gf4d4OYaU5ljo3GYiqzrWQHfJxA6ALhDpVKv9qYeZA8eM3EhfPSCmpuD0AAAAASUVORK5CYII=';

        var iconForTypes = {
            'ProjetAcquereur': 'marker-purchaser',
            'ProjetBailleur': 'marker-management',
            'ProjetEstimation': 'marker-estimate',
            'ProjetLocataire': 'marker-rent',
            'ProjetMandat': 'marker-mandate',
            'ProjetProspect': 'marker-default',
            'ProjetVendeur': 'marker-sell'
        };

        //this apply on feature collection kind of useless
        var applyModel = function (obj) {
            return angular.extend(obj, {});
        };

        Restangular.extendModel('map', applyModel);
        Restangular.extendModel('search', applyModel);
        Restangular.extendModel('near', applyModel);


        var service = {
            lastLocation: null,
            geolocation: undefined,
            getDefaultLocation: function () {
                var current = Session.current();
                if(current && current.lat != '' &&  current.lng != '') {
                    return [parseFloat(current.lng), parseFloat(current.lat)];
                } else if(service.geolocation){
                    return service.geolocation;
                }
            },
            setLastLocation: function (last) {
                service.lastLocation = last;
                LocalStorageService.saveValue('lastLocation', last);
            },
            getLastLocation: function () {
                if (service.lastLocation) {
                    return service.lastLocation;
                }
                var defaultLocation = service.getDefaultLocation();
                if(defaultLocation) {
                    return {lat: defaultLocation[1], lng: defaultLocation[0]}
                }
                return [2.352241, 48.856638];//paris as default
            },
            search: function (query) {
                var v = LocalStorageService.getValue('lastLocation');
                return map.customGET('search', {
                    q: query,
                    lat: v.lat,
                    lng: v.lng,
                    distance: 5000
                });
            },
            //leaflet L.latLngBounds
            getInBbox: function (bbox, zoom, maxZoom) {
                return map.customGET('inbbox', {
                    southWestLng:bbox.getSouthWest().lng,
                    southWestLat:bbox.getSouthWest().lat,
                    northEastLng:bbox.getNorthEast().lng,
                    northEastLat:bbox.getNorthEast().lat,
                    zoom:zoom,
                    maxZoom:maxZoom,
                    kind: 'all' //kind is now deprectated
                });
            },
            nearPoint: function (point, distance, kind) {
                return map.customGET('near', {
                    longitude: point.longitude,
                    latitude: point.latitude,
                    maxDistance: distance,
                    kind: kind
                });
            },
            nearPointMatching: function (query, point, distance) {
                point = point || service.demoLocation;
                distance = distance || 20 * 1000;
                return map.customGET('near', {
                    queryTerms: query,
                    longitude: point[0],
                    latitude: point[1],
                    maxDistance: distance,
                    maxElementsByCategories: 3
                });
            },
            colors: ['#F2B708', '#F6C95D', '#FADB99', '#FDEDCE', '#FFFFFF'],
            getMarkerColor: function (nbBienProspectes, nbBienPotentiel) {
                if (angular.isDefined(nbBienProspectes)
                    && angular.isDefined(nbBienPotentiel && nbBienProspectes > 0)) {
                    var index = service.colors.length - Math.round(nbBienProspectes * (service.colors.length - 1) / nbBienPotentiel);
                    return service.colors[index];
                }
                return 'white';
            },
            featureIsContact: function (feat) {
                return feat.properties && feat.properties._type === 'Contact';
            },
            featureIsAdresse: function (feat) {
                return feat.properties && feat.properties._type === 'Adresse';
            },
            isMappy: function (state) {
                return state.params.mappy == 'true';
            },
            disableClusteringAtZoom: function (config) {
                return config.defaults.disableClusteringAtZoom;
            },
            setFeatures: function (feats, config) {
                service.removeFeatures(config);
                //force copy for directive watch
                config.geojson = angular.extend({data: feats}, config.geojson);
            },
            removeFeatures: function (config) {
                delete config.geojson.data;
                config.geojson = angular.extend({}, config.geojson);
            },
            hasFeatures: function (config) {
                return config.geojson && config.geojson.data && config.geojson.data && config.geojson.data.features && config.geojson.data.features.length >0;
            },
            matchBoundsToGeoJson: function (leafletData/*leaftlet directive*/, config) {
                leafletData.getGeoJSON().then(function (geojsonLayer) {
                    var bounds = geojsonLayer.getBounds();
                    //translate to directive format
                    if (bounds._northEast) {
                        config.bounds = {
                            northEast: {
                                lat: bounds._northEast.lat,
                                lng: bounds._northEast.lng
                            },
                            southWest: {
                                lat: bounds._southWest.lat,
                                lng: bounds._southWest.lng
                            }
                        };
                    }
                });
            },
            centerOnFeature: function (config, feature, withZoom) {
                var lat;
                var lng;
                if (feature && feature.geometry) {
                    lat = feature.geometry.coordinates[1];
                    lng = feature.geometry.coordinates[0];
                } else if (feature && feature.coordinates) {
                    lat = feature.coordinates[1];
                    lng = feature.coordinates[0];
                } else {
                    console.error("no location infos for feature", feature);
                    return;
                }
                var latlng = L.latLng(lat, lng);
                var dist = latlng.distanceTo(L.latLng(config.center.lat, config.center.lng));
                //console.log("dist", dist);
                if (dist > 10) {
                    config.center.lng = latlng.lng;
                    config.center.lat = latlng.lat;
                }
                if (withZoom === true && config.center.zoom < config.defaults.maxZoom - 1) {
                    config.center.zoom = config.defaults.maxZoom;
                }
            },
            getMarker: function (lat, lng, text, bienId) {
                return {
                    lat: lat,
                    lng: lng,
                    message: text,
                    focus: true,
                    draggable: false,
                    icon: {
                        iconUrl: 'img/marker-default.png',
                        iconRetinaUrl: 'img/marker-default-2x.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 10],
                        shadowUrl: base64shadow
                    }
                };
            },
            getMapConfiguration: function (options) {
                options = options || {mappy: true};
                var config = {
                    defaults: {
                        inertia:true,
                        tap:true,
                        controls: {
                            layers: {
                                visible: true,
                                options: {
                                    position: 'bottomright',
                                    collapsed: true
                                }
                            }
                        },
                        zoomControl: false,//(!ionic.Platform.isIOS() && !ionic.Platform.isAndroid()),
                        attributionControl: false,
                        disableClusteringAtZoom: options.mappy ? 11 : 18,
                        crs: options.mappy ? 'ESRI:54016' : 'EPSG:3857',
                        zoom: options.mappy ? 12 : 17,
                        maxZoom: options.mappy ? 12 : 19
                    },
                    center: {
                        lat: service.getLastLocation().lat,
                        lng: service.getLastLocation().lng,
                        zoom: service.getLastLocation().zoom ? service.getLastLocation().zoom : options.mappy ? 12 : 18
                    },
                    layers: {
                        baselayers: function () {
                            if (options.mappy === true) {
                                return {
                                    standard: {
                                        name: 'Carte',
                                        url: 'http://map{s}.mappy.net/map/1.0/slab/standard/384/{z}/{x}/{y}',
                                        type: 'xyz',
                                        layerParams: {tms: true},
                                        layerOptions: {
                                            minZoom: 0,
                                            maxZoom: 12,
                                            tileSize: 384,
                                            subdomains: '1234',
                                            crs: L.CRS['ESRI:54016'],
                                            tms: true
                                        }
                                    },
                                    hybrid: {
                                        name: 'Satellite',
                                        url: 'http://map{s}.mappy.net/map/1.0/slab/hybrid/384/{z}/{x}/{y}',
                                        type: 'xyz',
                                        layerParams: {tms: true},
                                        layerOptions: {
                                            minZoom: 0,
                                            maxZoom: 12,
                                            tileSize: 384,
                                            subdomains: '1234',
                                            crs: L.CRS['ESRI:54016'],
                                            tms: true
                                        }
                                    }
                                    //,photo: {
                                    //    name: 'Satellite',
                                    //    url: 'http://map{s}.mappy.net/map/1.0/slab/photo/384/{z}/{x}/{y}',
                                    //    type: 'xyz',
                                    //    layerParams: {tms: true},
                                    //    layerOptions: {
                                    //        minZoom: 0,
                                    //        maxZoom: 12,
                                    //        tileSize: 384,
                                    //        subdomains: '1234',
                                    //        crs: L.CRS['ESRI:54016'],
                                    //        tms: true
                                    //    }
                                    //}

                                };
                            } else {
                                return {
                                    osm: {
                                        name: 'Cadastre',
                                        url: 'http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
                                        type: 'xyz'
                                    },
                                    googleHybrid: {
                                        name: 'Aérien',
                                        layerType: 'HYBRID',
                                        type: 'google'
                                    },
                                    googleRoadmap: {
                                        name: 'Rue',
                                        layerType: 'ROADMAP',
                                        type: 'google'
                                    }
                                };
                            }
                        }()
                    },
                    markers: {
                    },
                    geojson: {
                        resetStyleOnMouseout: true,
                        onEachFeature: function (feature, layer) {
                            var handler = function (e) {
                                leafletHelpers.safeApply($rootScope, function () {
                                    config.selected = feature;
                                    config.featureSelectedId = feature.properties ? feature.properties._id : undefined;
                                    $rootScope.$broadcast('leafletDirectiveMap.geojsonClick', config.selected, e);
                                });
                            };
                            if(navigator.userAgent.indexOf('IEMobile')>-1) {
                                layer.on({mousemove: handler});
                            } else {
                                layer.on({click: handler});
                            }
                        },
                        style: function (feat) {
                            if (service.featureIsAdresse(feat) || service.featureIsContact(feat)) {
                                var fillColor = 'white';
                                if (feat.properties && feat.properties.nbBienProspectes) {
                                    fillColor = service.getMarkerColor(feat.properties.nbBienProspectes, feat.properties.nbBienPotentiel);
                                }
                                var radius = 12;
                                //if(config.center.zoom == config.defaults.maxZoom) {
                                //    radius = 15;
                                //}
                                if (config.featureSelectedId) {
                                     if(config.featureSelectedId === feat.properties._id) {
                                         config.markers.selected = {
                                             icon: service.getIconConfig('marker-red'),
                                             zIndexOffset:1000,
                                             lat: feat.geometry.coordinates[1],
                                             lng: feat.geometry.coordinates[0]
                                         };
                                     }
                                } else {
                                    delete config.markers.selected;
                                }
                                return {
                                    radius: radius,
                                    weight: 1,
                                    color: 'black',
                                    opacity: 0.8,
                                    fillColor: fillColor || 'white',
                                    fillOpacity: 0.7
                                };

                            }
                        },
                        pointToLayer: function (feature, latlng) {
                            if (service.featureIsAdresse(feature) || service.featureIsContact(feature)) {
                                return L.circleMarker(latlng, {});
                            } else {
                                var iconName = 'marker-default';
                                if (feature.properties && feature.properties._type) {
                                    iconName = iconForTypes[feature.properties._type];
                                }
                                return L.marker(latlng, {
                                    icon: L.icon(service.getIconConfig(iconName))
                                });
                            }
                        }
                    }
                };
//                if (options.withMappy) {
//                    config.layers.baselayers.mappy = {
//                        name: 'Mappy',
//                        url: 'http://map{s}.mappy.net/map/1.0/slab/standard/384/{z}/{x}/{y}',
//                        type: 'xyz',
//                        layerParams: {tms: true},
//                        layerOptions: {
//                            minZoom: 0,
//                            maxZoom: 12,
//                            tileSize: 384,
//                            subdomains: '1234',
//                            crs: L.CRS['ESRI:54016'],
//                            tms: true
//                        }
//                    };
//                }
                return config;
            },
            getIconConfig: function (iconName) {
                return {
                    iconUrl: 'img/' + iconName + '.png',
                    iconRetinaUrl: 'img/' + iconName + '-2x.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                    shadowUrl: base64shadow
                }
            },
            getMarkersForProjet: function (projet) {
                var geo = {};

                var location = projet.bien.adresse ? projet.bien.adresse.location : null;
                if (location) {
                    var lng = location.coordinates[0];
                    var lat = location.coordinates[1];
                    var href = $state.href('nav.bien.detail', {
                        bienId: projet.bienRef
                    });
                    var text = '';
                    switch (projet.bien._class) {
                        case '.BienMaison' :
                            text = '<div class="project-bubble">'
                            + '<img class="project-bubble-picture" src="' + BienService.getBienImageUrl(projet.bien) + '" /> '
                            + '<div class="project-bubble-infos" >'
                            + '<div class="project-bubble-contact-info" >'
                            + (projet.bien.dernierStatut || '') + ' '
                            + (i18n(projet.type) || '') + ' '
                            + '</div>'
                            + '<div class="project-bubble-bien-info" >'
                            + i18n(projet.bien._class) + ' '
                            + (projet.bien.type || '') + ' '
                            + (projet.bien.surface ? (projet.bien.surface + ' m&sup2; ') : '')
                            + (projet.bien.nbEtages ? (projet.bien.nbEtages +(projet.bien.nbEtages > 1 ? ' étages' : ' étage')) : '')
                            + (projet.bien.nbPieces ? (projet.bien.nbPieces + (projet.bien.nbPieces > 1 ? ' pièces' : ' pièce')) : '')
                            + '</div>';
                            break;

                        case '.BienAppartement' :
                            text = '<div class="project-bubble">'
                            + '<img class="project-bubble-picture" src="' + BienService.getBienImageUrl(projet.bien) + '" /> '
                            + '<div class="project-bubble-infos" >'
                            + '<div class="project-bubble-contact-info" >'
                            + (projet.bien.dernierStatut || '') + ' '
                            + (i18n(projet.type) || '') + ' '
                            + '</div>'
                            + '<div class="project-bubble-bien-info" >'
                            + i18n(projet.bien._class) + ' '
                            + (projet.bien.surface ? (projet.bien.surface + ' m&sup2; ') : '')
                            + (projet.bien.nbPieces ? (projet.bien.nbPieces + (projet.bien.nbPieces > 1 ? ' pièces' : ' pièce')) : '')
                            + '</div>';
                            break;

                        case '.BienTerrain' :
                            text = '<div class="project-bubble">'
                            + '<img class="project-bubble-picture" src="' + BienService.getBienImageUrl(projet.bien) + '" /> '
                            + '<div class="project-bubble-infos" >'
                            + '<div class="project-bubble-contact-info" >'
                            + (projet.bien.dernierStatut || '') + ' '
                            + projet.type + ' '
                            + '</div>'
                            + '<div class="project-bubble-bien-info" >'
                            + i18n(projet.bien._class) + ' '
                            + (projet.bien.surface ? (projet.bien.surface + ' m&sup2; ') : '')
                            + '</div>';
                            break;
                        default:
                            text = ''
                    }

                    text += '<span class="project-bubble-address">' + AdresseService.getFormatedAdresse(projet.bien.adresse) + '</span>'
                            + '</div>'
                            + '</div>';
                    text += '<a class="project-bubble-link" href="' + href + '"></a>';
                    geo["a"] = (service.getMarker(lat, lng, text));
                } else {
                    text = '<div class="project-bubble">'
                        + '<span class="project-bubble-address">' + AdresseService.getFormatedAdresse(projet.bien.adresse) + '</span>'
                        + '<span class="project-bubble-address" style="color:red">' + 'Adresse du projet à corriger dans CenturyNet' + '</span>'
                        + '</div>';
                    geo["a"] = (service.getMarker(46.60611, 1.87528, text));
                }
                return geo;
            },
            getMarkersFromAdresse: function (contact) {
                var geo = {};
                angular.forEach(contact.adresseReferences, function (adresselink, index) {
                    var location = adresselink.adresse ? adresselink.adresse.location : null;
                    if (location) {
                        var lng = location.coordinates[0];
                        var lat = location.coordinates[1];
                        var href = $state.href('nav.map', {
                            longitude: lng,
                            latitude: lat,
                            title: ContactService.formatContact(contact)
                        });
                        var text = '<a href="' + href + '">' + adresselink.adresseString + '</a>'
                        geo["a" + index] = service.getMarker(lat, lng, text);
                    }
                });
                return geo;
            },
            getGeojsonFrom: function (all, convertFn) {
                var geo = {
                    "type": "FeatureCollection",
                    "features": []
                };
                if (!angular.isArray(all)) {
                    all = [all];
                }
                angular.forEach(all, function (one) {
                    geo.features.push(service.getGeojsonFeatureFrom(convertFn(one)));
                });
                return geo;
            },
            getGeojsonFeatureFrom: function (object) {
                return angular.extend({
                    type: "Feature"
                }, object);
            }
        };
        if (LocalStorageService.getValue('lastLocation')) {
            var last = LocalStorageService.getValue('lastLocation');
            if (last && last.lng) {
                //console.log('lastLocation'+last.lng);
                service.lastLocation = last;
            }

        }
        navigator.geolocation.getCurrentPosition(function (pos) {
            //console.log('getCurrentPosition'+pos.coords.longitude);
            service.geolocation=[pos.coords.longitude, pos.coords.latitude];
        });
        return service
    });
