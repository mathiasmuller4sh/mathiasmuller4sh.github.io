'use strict';
angular
    .module('module.map')
    .controller('MapCtrl', function ($scope, $rootScope, $document, leafletData, $filter, $timeout, $state, $q, $stateParams, $compile, $templateCache,
                                     $ionicModal, $ionicScrollDelegate, $ionicNavBarDelegate, $ionicPopup, $ionicBackdrop, leafletHelpers, MapService, Toast) {

        var leafletUtils = {
            getMapDistance: function (map) {
                return map.getBounds().getNorthEast().distanceTo(map.getCenter());
            },
            repaintMap: function () {
                $timeout(function () {
                leafletData.getMap('c21').then(function (map) {
                    L.Util.requestAnimFrame(function () {
                        map.invalidateSize();
                    }, map, false, map._container);
                });
                }, 200);
            },
            resetLayerStyleForFeatId: function (featId) {
                if (leafletData && featId) {
                    leafletData.getGeoJSON('c21').then(function (geo) {
                        var layer = leafletUtils.findLayerForFeatureId(geo.getLayers(), featId);
                        if (layer) {
                            geo.resetStyle(layer);
                        }
                    });
                }
            },
            findLayerForFeatureId: function (allLayers, id) {
                for (var i = 0; i < allLayers.length; i++) {
                    var layer = allLayers[i];
                    if (layer.feature && layer.feature.properties._id === id) {
                        return layer;
                    }
                }
                return null;
            }
        };



        angular.extend($rootScope, {
            selectedProjects: $rootScope.selectedProjects || {},
            isMatchingProject: function(item) {
                var type = item;
                if(!angular.isString(item)) {
                    type = item.properties._type;
                }
                return angular.isUndefined($rootScope.selectedProjects[type]) ||  $rootScope.selectedProjects[type] === true || type === 'Adresse';
            }
        });

        angular.extend($scope, {
            $state: $state,
            allFeatures: [],
            datas: {
                layer: null,
                mapTitle: 'Autour de moi',
                detailPage: 'modules/immeuble/fiche-immeuble.html',
                searchVisible: false,
                searchBoxVisible: false
            },
            leaflet: MapService.getMapConfiguration(),
            setSearchBoxVisible: _.debounce(function (bool) {
                if ($scope.datas.searchBoxVisible !== bool) {
                    $scope.datas.searchBoxVisible = bool;
                    if (bool) {
                        $scope.hideDetail();
                        $timeout(function() {
                            var els =  angular.element(document.getElementById("search-box-input"));
                            if(els && els.length > 0 && els[0].focus ) {
                                els[0].focus();
                            }
                        },500);
                    }
                    leafletUtils.repaintMap();
                }
            },100),
            setSearchVisible: function (bool) {
                $scope.setSearchBoxVisible(bool);
                if ($scope.datas.searchVisible !== bool) {
                    $scope.datas.searchVisible = bool;
                    leafletUtils.repaintMap();
                }
            },
            hasDetail: function () {
                return $state.includes('nav.map.immeuble');
            },
            hideDetail: function () {
                return $state.go('nav.map').finally(function () {
                    delete $scope.leaflet.featureSelectedId;
                    $timeout(leafletUtils.repaintMap, 200);
                });
            },
            selectFeatureWithId: function (id) {
                leafletUtils.resetLayerStyleForFeatId(id);
                //$scope.centerMapOnFeatureWithId(id);
            },
            placeOnMap: function (feature) {
                MapService.centerOnFeature($scope.leaflet, feature, true);
                $scope.displayDetail(feature);
            },
            centerMapOnFeatureWithId: function (featId) {
                if (featId) {
                    leafletData.getGeoJSON('c21').then(function (geo) {
                        var layer = leafletUtils.findLayerForFeatureId(geo.getLayers(), featId);
                        if (layer && layer.feature) {
                            MapService.centerOnFeature($scope.leaflet, layer.feature, true);
                        }
                    });
                }
            },
            loadData:  _.debounce(function () {
                var bounds;
                leafletData.getGeoJSON('c21').then(function (geojsonLayer) {
                   bounds = geojsonLayer.getBounds();
                });
                leafletData.getMap('c21').then(function (map) {
                    MapService.setLastLocation($scope.leaflet.center);
                    if (bounds && bounds.isValid() && bounds.contains(map.getBounds())) {
                        console.log("data already loaded");
                        return;
                    }
                    $scope.loading = MapService
                        .getInBbox(map.getBounds(), $scope.leaflet.center.zoom, $scope.leaflet.defaults.maxZoom)
                        .then(function (geoJson) {
                            $scope.allFeatures = geoJson.features;
                            MapService.setFeatures(filterFeature($scope.allFeatures), $scope.leaflet);
                        });
                });
            }, 500),
            //detail page display
            displayDetail: function (featureSelected) {
                $scope.feature = featureSelected;
                $scope.setSearchVisible(false);
                if (MapService.featureIsContact($scope.feature)) {
                    $state.go('nav.contact.detail', {id: $scope.feature.properties._id}, {location: true});
                } else {
                    var immeubleId = null;
                    if (MapService.featureIsAdresse($scope.feature)) {
                        if(angular.isDefined(featureSelected.properties.numero)) {
                            immeubleId = $scope.feature.properties._id
                        }
                    } else {
                        immeubleId = $scope.feature.properties.adresseRef
                    }

                    if(angular.isDefined(immeubleId)) {
                        $state.go('nav.map.immeuble', {id: immeubleId}, {location: true, notify:true}).then(leafletUtils.repaintMap);
                    } else {
                        $scope.hideDetail().then(function() {
                            MapService.centerOnFeature($scope.leaflet, featureSelected, true);
                        });
                    }
                }
            }
        });

        //watch for feature id selection from outside
        $scope.$watch('leaflet.bounds',$scope.loadData);

        //watch for feature id selection from outside
        $scope.$watch('leaflet.featureSelectedId', function (newId, oldId) {
            if (newId !== oldId) {
                leafletUtils.resetLayerStyleForFeatId(oldId);
                $scope.selectFeatureWithId(newId);
                if(angular.isUndefined(newId)) {
                    $timeout($scope.loadData,400);
                }
            }
        });


        $scope.$on("leafletDirectiveMap.geojsonClick", function (ev, featureSelected, leafletEvent) {
            $scope.displayDetail(featureSelected);
        });

        var labelValueMap = {
            'Mandants': 'ProjetMandat',
            'Estimés': 'ProjetEstimation',
            'Achetés par C21': 'ProjetVendeur',
            'Bailleur': 'ProjetBailleur',
            'Locataire': 'ProjetLocataire',
            'Acquéreurs': 'ProjetAcquereur'
        };

        var filterFeature = function(features) {
            return $filter('filter')(features, $rootScope.isMatchingProject);
        };
        // locate me control setup
        leafletData.getMap('c21').then(function (map) {
            //locate control
            var lc = L.control.locate({
                position: 'bottomleft',
                locateOptions: {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge:0
                    //watch:true
                },
                drawCircle: true,
                keepCurrentZoomLevel: true,
                follow: true,
                //remainActive : true,
                onLocationError: function (err) {
                    console.log(err.message);
                    if(cordova && cordova.plugins.diagnostic && navigator.notification && ionic.Platform.isAndroid()) {
                        navigator.notification.confirm('Votre Gps est éteint. Voulez vous ouvrir la page de configuration', function(val) {
                            console.log(val)
                            if(val === 1) {
                                cordova.plugins.diagnostic.switchToLocationSettings();
                            }
                        } , 'Localisation impossible', ['Oui','Non']);
                    } else {
                        Toast.show('Localisation impossible. Avez vous allumé le GPS?', 'long');
                    }
                },
                circleStyle: {},  // change the style of the circle around the user's location
                markerStyle: {},
                followCircleStyle: {},  // set difference for the style of the circle around the user's location while following
                followMarkerStyle: {},
                strings: {
                    title: "Ma position",
                    popup: "Position approximative. ({distance} mètres)",
                    outsideMapBoundsMsg: "Votre position n'est pas sur la carte"
                }
            }).addTo(map);
//            var markers = new L.MarkerClusterGroup();
//            map.addLayer(markers);

            //filter top right
            var overlays = {};
            angular.forEach(labelValueMap, function(key, label) {
                overlays[label] = L.layerGroup();
                if($rootScope.isMatchingProject(key)) {
                    overlays[label].addTo(map);
                }
            });

            L.control.layers(null, overlays).addTo(map);

            map
                .on('overlayadd', function (a) {
                    $rootScope.selectedProjects[labelValueMap[a.name]] = true;
                    MapService.setFeatures(filterFeature($scope.allFeatures), $scope.leaflet);
                })
                .on('overlayremove', function (a) {
                    $rootScope.selectedProjects[labelValueMap[a.name]] = false;
                    MapService.setFeatures(filterFeature($scope.allFeatures), $scope.leaflet);
                })
                .on('startfollowing', function () {
                    map.on('dragstart', lc.stopFollowing);
                })
                .on('stopfollowing', function () {
                    map.off('dragstart', lc.stopFollowing);
                });
        });

        //load detail if coming directly from url
        if ($scope.hasDetail()) {
            leafletData.getGeoJSON('c21').then(function (geo) {
                var layer = leafletUtils.findLayerForFeatureId(geo.getLayers(), $state.params.id);
                if (layer && layer.feature) {
                    $scope.placeOnMap(layer.feature);
                }
            });
        }
        //init from url
        //center using state params
        if ($state.params.latitude && $state.params.longitude) {
            $scope.leaflet.center.lat = parseFloat($state.params.latitude);
            $scope.leaflet.center.lng = parseFloat($state.params.longitude);
        }

        //search wiring
        $rootScope.$on("search.visibility", function (evts, visible) {
            if ($state.includes("nav.map.**")) {
                $scope.setSearchVisible(visible);
            }
        });
        $rootScope.$on("search.complete", function (evts, results) {
//            MapService.setFeatures(results.features, $scope.leaflet);
//            $timeout(function () {
//                MapService.matchBoundsToGeoJson(leafletData, $scope.leaflet);
//            }, 800);
        });
        $rootScope.$on("search.result.click", function (evt, geojsonFeature) {
            evt.stopPropagation();
            evt.preventDefault();
            $scope.displayDetail(geojsonFeature);
        });


        $scope.$on('$destroy', $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
            //console.log('$locationChangeSuccess' , event, toState, toParams, fromState, fromParams)
            $timeout(leafletUtils.repaintMap, 200);
        }));
    });
