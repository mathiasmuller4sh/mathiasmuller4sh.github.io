'use strict';
//register mappy crs to leaflet

(function () {
    var projection = {
        EARTH_RADIUS: 6378137,
        DEGREE_TO_RADIAN: 0.017453292519943295,
        RADIAN_TO_DEGREE: 57.29577951308232,

        project: function (latlng) {
            var x = projection.EARTH_RADIUS * latlng.lng * 0.70710678118654752440 * projection.DEGREE_TO_RADIAN;
            var y = projection.EARTH_RADIUS * Math.tan(0.5 * latlng.lat * projection.DEGREE_TO_RADIAN) * 1.70710678118654752440;

            return new L.Point(x, y);
        },

        unproject: function (point) { // (Point, Boolean) -> LatLng
            var lng = (1.41421356237309504880 * point.x / projection.EARTH_RADIUS) * projection.RADIAN_TO_DEGREE;
            var lat = (2 * Math.atan(0.58578643762690495119 * point.y / projection.EARTH_RADIUS)) * projection.RADIAN_TO_DEGREE;

            return new L.LatLng(lat, lng);
        }
    };
    var crs = L.extend({}, L.CRS, {
        code: 'ESRI:54016',

        projection: projection,
        transformation: new L.Transformation(1, 14168658.027268294, -1, 17449155.130499773),

        scale: function (zoom) {
            var scales = [
                73795.09389202237,
                24598.364630674125,
                8199.454876891376,
                2733.1516256304585,
                911.0505418768195,
                303.68351395893984,
                101.22783798631328,
                33.74261266210443,
                11.247537554034809,
                3.7491791846782694,
                1.2497263948927564,
                0.41657546496425213,
                0.13885848832141737
            ];

            return 1 / scales[zoom];
        },

        getSize: function (zoom) {
            var size = 384 * Math.pow(3, zoom);
            return new L.Point(size, size);
        }
    });

    L.CRS[crs.code] = crs;
}.call());
