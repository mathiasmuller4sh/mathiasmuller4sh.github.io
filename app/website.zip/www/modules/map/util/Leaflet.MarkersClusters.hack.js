'use strict';

angular
    .module('module.map')
    .run(function (MapService) {

///// leaftlet directive hack to allow Marker cluster
        L.GeoJSON = L.GeoJSON.extend({
            addTo: function (map) {
                var self = this;
                map.addLayer(this.markers);
                var parentRemove = L.GeoJSON.prototype.onRemove;
                L.GeoJSON.prototype.onRemove = function (map) {
                    self.markers.removeLayer(self);
                    delete self.markers;
                    parentRemove(map);
                };
                return this;
            }
        });
        L.geoJson = function (geojson, options) {
            var compute = function (cluster, nbBien) {
                if (cluster._childClusters) {
                    for (var i = 0; i < cluster._childClusters.length; i++) {
                        compute(cluster._childClusters[i], nbBien);
                    }
                }
                for (var i = 0; i < cluster._markers.length; i++) {
                    var mark = cluster._markers[i];
                    if (mark.feature.properties) {
                        nbBien.prospectes += mark.feature.properties.nbBienProspectes;
                        nbBien.potentiel += mark.feature.properties.nbBienPotentiel;
                    }
                }
            };
            var geoJSON = new L.GeoJSON(geojson, options);
            var markers = new L.MarkerClusterGroup({
                spiderfyOnMaxZoom: false,
                showCoverageOnHover: true,
                zoomToBoundsOnClick: true,
                disableClusteringAtZoom: disableClusteringAtZoom||18,
                iconCreateFunction: function (cluster) {
                    var nbBien = {
                        prospectes: 0,
                        potentiel: 0
                    };
                    compute(cluster, nbBien);
                    var color = MapService.getMarkerColor(nbBien.prospectes, nbBien.potentiel) || '#f1f1f1';

                    return new L.DivIcon(
                        {
                            html: '<div style="background-color:' + color + '"><span>' + cluster.getChildCount() + '</span></div>',
                            className: 'marker-cluster',
                            iconSize: new L.Point(40, 40)
                        });
                }
            });
            markers.setGeoJSON = function (data, id) {
                geoJSON.setGeoJSON(data, id);
            };
            markers.getGeoJSON = function (id) {
                return geoJSON.getGeoJSON(id);
            };
            markers.getLayers = function () {
                return geoJSON.getLayers();
            };
            markers.resetStyle = function (data) {
                geoJSON.resetStyle(data);
            };
            markers.getBounds = function () {
                return geoJSON.getBounds();
            };

            markers.addLayer(geoJSON);
            geoJSON.markers = markers;
            return markers;
        };
    });
