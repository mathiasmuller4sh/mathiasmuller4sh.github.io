'use strict';
angular
    .module('C21mobile')
    .value('LoadingConfig', {
        noBackdrop: true,
        delay: 300,
        templateUrl: 'modules/utils/loading-template.html'
    })
    .value('SavingConfig', {
        noBackdrop: true,
        delay: 100,
        templateUrl: 'modules/utils/saving-template.html'
    })
    .config(function ($compileProvider) {
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(tel|https?|ftp|mailto|file|ghttps?|ms-appx|x-wmapp0):/);
        $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|file|ms-appx|x-wmapp0):|img|data:image\//);
    })
    .config(function ($ionicConfigProvider) {
        if (ionic.Platform.isWindowsPhone()) {
            $ionicConfigProvider.views.transition('none');
            window.console = {
                log: function (str) { window.external.Notify(str); }
            };
            window.onerror = window.console
        } else {
            $ionicConfigProvider.views.transition('none');
        }
        //ionic.Platform.ready(function(){
        //    if(ionic.Platform.isIOS() && window.cordova) {
        //        //disable overflow scroll for ios avoid to put content outside view
        //        window.cordova.plugins.Keyboard.disableScroll(true);
        //    }
        //});
        $ionicConfigProvider.scrolling.jsScrolling(true);
        $ionicConfigProvider.views.maxCache(0);
        $ionicConfigProvider.views.swipeBackEnabled(false);
        $ionicConfigProvider.backButton.text('').icon('button button-icon icon button-dark button-clear ion-ios-arrow-left');
        $ionicConfigProvider.navBar.alignTitle('center');
    })
    .run(function ($rootScope, $ionicHistory) {
        console.log('platform():', ionic.Platform.platform());

        $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
            //console.log("stateChangeSuccess", toState.name, fromState.name, toParams, fromParams);
            //console.log("$ionicHistory",$ionicHistory.viewHistory());
        })
    })
    .config(function ($provide) {
        $provide.decorator('$ionicScrollDelegate', ['$delegate', '$location', function ($delegate, $location) {
            $delegate.scrollElementToTop = function (elmId, ionicScrollHandle) {
                var scroller = ionicScrollHandle?$delegate.$getByHandle(ionicScrollHandle):$delegate;
                window.setTimeout(function () {
                    $location.hash(elmId);
                    scroller.anchorScroll(true);
                }, 300);
            };
            return $delegate;
        }]);
    })
;
