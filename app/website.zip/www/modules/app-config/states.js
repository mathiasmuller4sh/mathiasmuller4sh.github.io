'use strict';
angular
    .module('C21mobile')
    .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider) {
        //config state
        $stateProvider
            .state('login', {
                url: '/login',
                templateUrl: 'modules/login/login.html',
                data: {
                    pageTitle: 'Authentification - C21'
                }
            })
            .state('autologin', {
                url: '/autologin',
                templateUrl: 'modules/login/autologin.html',
                controller: 'AutoLoginCtrl',
                data: {
                    pageTitle: 'Authentification en cours - C21'
                }
            })
            .state('home', {
                url: "/home",
                abstract: true,
                templateUrl: 'modules/home/nav-layout.html',
                controller: 'NavCtrl'
            })
            .state('home.index', {
                url: '/index?search',
                reloadOnSearch: false,
                views: {
                    'nav-content': {
                        templateUrl: 'modules/home/home-layout.html',
                        controller: 'IndexCtrl'
                    },
                    'home-content': {
                        templateUrl: 'modules/home/home-content.html',
                        controller: 'IndexCtrl'
                    }
                },
                data: {
                    pageTitle: 'Accueil - C21'
                }
            })
            .state('nav', {
                url: '/app',
                abstract: true,
//                template: '<ion-nav-view name="nav-content"></ion-nav-view>'
                templateUrl: 'modules/home/nav-layout.html',
                controller: 'NavCtrl'
            })
            .state('nav.contacts', {
                url: '/contacts?searchText&occupation&projet&dernierContact&console',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/contact/contact-list.html',
                        controller: 'ContactListCtrl'
                    }
                },
                reloadOnSearch: false,
                data: {
                    pageTitle: 'Liste des contacts - C21'
                }
            })
            .state('nav.contacts.bien', {
                url: '/:bienRef',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/contact/contact-list.html',
                        controller: 'ContactListCtrl'
                    }
                },
                data: {
                    pageTitle: 'Liste des contacts de l\'adresse - C21'
                }
            })
            .state('nav.contact', {
                url: '/contact/:id',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/contact/contact-detail.html',
                        controller: 'ContactCtrl'
                    }
                },
                data: {
                    pageTitle: 'Contact détail - C21'
                }
            })
            .state('nav.contact.detail', {
                url: '/detail',
                views: {
                    'contact-content': {
                        templateUrl: 'modules/contact/contact-id-container.html',
                        controller: 'ContactDetailCtrl'
                    }
                }
            })
            .state('nav.contact.hist', {
                url: '/hist',
                views: {
                    'contact-content': {
                        templateUrl: 'modules/contact/contact-hist.html'
                    }
                },
                data: {
                    pageTitle: 'Contact Notes - C21'
                }
            })
            .state('nav.contact.create', {
                url: '/create',
                views: {
                    'contact-content': {
                        templateUrl: 'modules/contact/contact-edit.html',
                        controller: 'ContactDetailCtrl'
                    }
                },
                data: {
                    pageTitle: 'Contact création - C21'
                }
            })
            .state('nav.contact.edit', {
                url: '/edit',
                views: {
                    'contact-content': {
                        templateUrl: 'modules/contact/contact-edit.html',
                        controller: 'ContactDetailCtrl'
                    }
                },
                data: {
                    pageTitle: 'Contact Edition - C21'
                }
            })
            .state('nav.map', {
                url: '/map?longitude&latitude',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/map/map.html',
                        controller: 'MapCtrl'
                    }
                },
                data: {
                    pageTitle: 'Autour de moi - C21'
                }
            })
            .state('nav.map.immeuble', {
                url: '/immeuble/:id',
                views: {
                    'map-detail': {
                        templateUrl: 'modules/immeuble/fiche-immeuble.html'
                    }
                },
                data: {
                    pageTitle: 'Fiche Immeuble - C21'
                }
            })
            .state('nav.biens', {
                url: '/biens?ids',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/bien/bien-list.html',
                        controller: 'BienListCtrl'
                    }
                },
                data: {
                    pageTitle: 'Liste des biens - C21'
                }
            })
            .state('nav.bien', {
                url: '/bien/:bienId',
                views: {
                    'nav-content': {
                        templateUrl: 'modules/bien/bien-detail.html',
                        controller: 'BienCtrl'
                    }
                },
                data: {
                    pageTitle: 'Bien détail - C21'
                }
            })
            .state('nav.bien.detail', {
                url: '/detail',
                views: {
                    'bien-content': {
                        templateUrl: 'modules/bien/bien-id.html',
                        controller: 'BienDetailCtrl'
                    }
                }
            })
            .state('nav.bien.hist', {
                url: '/hist',
                views: {
                    'bien-content': {
                        templateUrl: 'modules/bien/bien-hist.html'
                    }
                },
                data: {
                    pageTitle: 'Bien Notes - C21'
                }
            });
        $urlRouterProvider.otherwise('/autologin');
    });
