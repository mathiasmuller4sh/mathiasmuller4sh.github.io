'use strict';
angular
    .module('C21mobile')
    .config(function ($httpProvider, RestangularProvider, ConfigDictionary) {
        var baseUrl = ConfigDictionary.serverUrl;
        var protocol = window.location.protocol;
        if (!(protocol === 'file:' || protocol.indexOf('x-wmapp0') == 0) && baseUrl.indexOf('://')>-1) {
            //http mode insure server has same protocol than webserver
            baseUrl = protocol+baseUrl.substring(baseUrl.indexOf('://')+1);
        }
        RestangularProvider.setBaseUrl(baseUrl);
        RestangularProvider.setDefaultHttpFields({withCredentials: true});
        RestangularProvider.setRestangularFields({id: "_id"});
    });