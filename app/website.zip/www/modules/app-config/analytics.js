'use strict';
angular
    .module('C21mobile')
    .run(function ($rootScope, Session, ConfigDictionary) {
        ionic.Platform.ready(function(){
            //Move that in login to enable GA user_id
            ga('create', ConfigDictionary.googleAnalyticsCode || 'UA-55063178-2',  {
                'storage': 'none',
                'clientId': (window.device &&  window.device.uuid) ? window.device.uuid : 'browser_'+new Date().toLocaleString().replace(/\/|:| /g,'_')
            });
            ga('set', 'checkProtocolTask', null);

            $rootScope.$on('user.login', function(event) {
                if(Session.current()) {
                    $rootScope.gaCategory = Session.current().codeAgence +'_'+ Session.current().login;
                    ga('set', 'userId', Session.current().login);
                }
            });
        });
    })
    .run(function ($rootScope, Session, ConfigDictionary) {
        $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
            //console.log("stateChangeSuccess", toState.name, toParams);
            if(window.ga && Session.current()) {
                ga('send', 'event', Session.current().codeAgence || 'noagenceset', Session.current().login, toState.name);
            }
        });
    })
;
