'use strict';
angular
    .module('module.bien')
    .factory('BienService', function (Restangular, PhotoService, $filter, $state, Toast) {
        var i18n = $filter('i18n');

        var mapClassKind = {
            '.BienImmeuble': {kind: 'Immeuble'},
            '.BienMaison': {kind: 'Maison'},
            '.BienAppartement': {kind: 'Appartement'},
            '.BienTerrain': {kind: 'Terrain'},
            '.BienParking': {kind: 'Parking'},
            '.BienIndefini': {kind: 'Non défini'},
            '.BienNonQualifie': {kind: 'Non défini'},
            '.BienDivers': {kind: 'Non défini'}
        };

        Restangular.extendModel('biens', function (obj) {
            if(angular.isDefined(obj) && obj !== "null"){
                return angular.extend(obj, {
                    lastProject: function () {
                        return obj.dernierProjet;
                    }
                });
            }
        });

        var service = {
            cache: null,
            getBienClazz: function(withImmeuble) {
                var clazzs = [
                    {clazz: '.BienMaison', label: i18n('kind.house')},
                    {clazz: '.BienAppartement', label: i18n('kind.apartment')},
                    {clazz: '.BienTerrain', label: i18n('kind.terrain')},
                    {clazz: '.BienParking', label: i18n('kind.parking')},
                ];
                if (withImmeuble === true) {
                    clazzs.push({clazz: '.BienImmeuble', label: 'kind.immeuble'});
                }
                return clazzs;
            },
            copy: function (bien) {
                if (angular.isUndefined(bien.save)) {
                    return angular.extend({}, bien);
                } else {
                    return Restangular.copy(bien)
                }
            },
            display: function (bienId) {
                return $state.go('nav.bien.detail', {bienId: bienId});
            },
            save: function (bien) {
                if (angular.isUndefined(bien.save)) {
                    bien = Restangular.restangularizeElement(null, bien, 'biens');
                }
                service.cleanupRelation(bien);


                if (bien._id) {
                    var self = this;
                    var putPromise = Restangular.one('biens', bien._id).customPUT(bien);

                    putPromise.then(function(b) {
                        if (self.cache && self.cache.$object) {
                            var oldOne = _.first($filter('filter')(self.cache.$object, {'_id': b._id}));
                            //update in place old cache value
                            if (angular.isDefined(oldOne)) {
                                angular.extend(oldOne, b);
                            } else {
                                self.cache.$object.push(b);
                            }
                        }
                    });
                    return putPromise;
                } else {
                    return bien.post();
                }
            },
            merge:function(bienSrc, contactSrcId, bienDst, contactDstId) {
                //biens/{idBienA}/fusion?idBienB={idBienB}&idContactA={idContactA}&idContactB={idContactB}
                return Restangular.one('biens', bienSrc._id).customGET('fusion',{idBienB:bienDst._id, idContactB: contactDstId, idContactA:contactSrcId});
            },
            cleanupRelation:function(bien) {
                if(bien) {
                    if (angular.isArray(bien)) {
                        angular.forEach(bien, service.cleanupRelation);
                    } else {
                        //cleanup to avoid circular
                        angular.forEach(bien.relations, function (relation) {
                            delete relation.bien;
                        });
                        if (bien.appartements) {
                            angular.forEach(bien.appartements, service.cleanupRelation);
                        }
                    }
                }
                return bien;
            },
            showSaveOngoingToast: function (add) {
                Toast.show('Enregistrement en cours...');
            },
            showSaveToast: function (add) {
                Toast.show('Fiche  ' + (add == true ? 'ajoutée' : 'mise à jour'));
            },
            cleanCache: function () {
                service.cache = null;
            },
            all: function (filtre) {
                if (angular.isDefined(filtre)) {
                    //not caching sub list
                    return Restangular.all('biens').customGET('search',filtre)
                }
                if (!this.cache) {
                    service.cache = Restangular.all('biens').customGET('search',filtre);
                }
                return service.cache;
                //return Restangular.all('biens').getList(filtre);
            },
            retrieveKindByClass: function (bien) {
                var classKind = mapClassKind[bien._class];
                if(!classKind) {
                    console.log("no kind def for bien", bien);
                    return;
                }
                return classKind.kind;
            },
            get: function (key, options) {
                return Restangular.one('biens', key).get(options);
            },
            addImage: function (bien, imageURI) {
                var imagePlaceholder = {"description": 'Photo prise le :' + new Date(), "url": imageURI};
                var params = {
                    serverParams: {type: bien._class, id: bien._id},
                    success: function (image) {
                        if(image && image.url) {
                            imagePlaceholder.url = image.url;
                            service.save(bien);
                        }
                    }
                };

                if ((angular.isArray(imageURI) || angular.isObject(imageURI)) && imageURI.length > 0) {
                    //hack for desktop browser only
                    var file = imageURI[0];
                    imagePlaceholder.url = window.URL.createObjectURL(file);
                    params.file = file;
                }
                if (angular.isUndefined(bien.images)) {
                    bien.images = [];
                }
                bien.images.push(imagePlaceholder);
                PhotoService.send(imageURI, params);
            },
            defaultImage: function (bien, optionnalAdresse) {
                if (angular.isUndefined(optionnalAdresse) && ( angular.isUndefined(bien) || angular.isUndefined(bien.images) || angular.isUndefined(bien.adresse))) {
                    return 'img/default_picture_empty.png';
                }
                if (angular.isDefined(optionnalAdresse) ||
                    (angular.isDefined(bien.adresse) && angular.isDefined(bien.adresse.location))) {
                    var lngLat = (angular.isDefined(optionnalAdresse) && angular.isDefined(optionnalAdresse.location)) ? optionnalAdresse.location.coordinates : bien.adresse.location.coordinates;
                    return 'http://maps.googleapis.com/maps/api/streetview?size=600x400&location=' + lngLat[1] + ',' + lngLat[0];
                }
                if (bien.images.length == 0 && bien._class == '.BienMaison') {
                    return 'img/default_picture_house.png';
                } else if (bien.images.length == 0 && bien._class == '.BienImmeuble') {
                    return 'img/default_picture_building.png';
                } else {
                    return null;
                }
            },
            getBatimentsChoices: function(bien) {
                var b = [];
                for (var i = 1, l = bien.nbBatiments; i <= l; i++) {
                    b.push({val: i, name: "" + i});
                }
                return b;
            },
            getEtagesChoices: function(bien) {
                var val = [];
                if(bien && bien.nbEtages>0) {
                    for(var i= 0, l=bien.nbEtages; i<l; i++) {
                        val.push({val:i, label:service.getEtageLabel(i)});
                    }
                }
                return val;
            },
            getNbPieceLabel: function (bien) {
                return bien.nbPieces!= 0 ? bien.nbPieces+(bien.nbPieces==1? ' piece':' pieces'):'';
            },
            getPorteLabel: function (bien) {
                if(angular.isUndefined(bien.nbAppartements) || angular.isUndefined(bien.choixPaliers) || bien.choixPaliers.length==0) {
                    return '';
                }
                var palier = $filter('filter')(bien.choixPaliers, function (palier) {
                    return palier.idDefault;
                });
                return palier.length>0 ? palier[0].description: '';
            },
            getEtageLabel: function (bien) {
                var etage = bien._class? bien.numeroEtage : bien;
                if (angular.isUndefined(etage) || etage === '' || (angular.isObject(bien) && !service.isBienAppartement(bien))) {
                    return '';
                }
                return etage == 0 ? 'RDC' : etage + (etage == 1 ? 'er' : 'ème') + ' étage';
            },
            getBatimentLabel: function (bien) {
                if(angular.isUndefined(bien.numeroBatiment) || bien.numeroBatiment == '' || bien.numeroBatiment == '0') {
                    return '';
                }
               return 'Bat. '+bien.numeroBatiment;
            },
            getBienLabel: function (bien) {
                if(bien._class === ".BienAppartement"){
                    return  service.getBatimentLabel(bien)  +' '+ service.getEtageLabel(bien) + ' ' + service.getPorteLabel(bien) + ' ';
                }
                return i18n(bien._class) + (bien.type ? " (" + bien.type + ")" : "");
            },
            hasPicture: function (bien, adresse) {
                return (bien && bien.images && bien.images.length > 0) || (adresse && adresse.location);
            },
            getBienImageUrl: function (bien, optionnalAdresse) {
                if (!bien || !bien.images || bien.images.length == 0) {
                    return service.defaultImage(bien, optionnalAdresse);
                }
                var url = PhotoService.getUrl(bien.images[bien.images.length - 1]);
                if (angular.isUndefined(url)) {
                    url = service.defaultImage(bien);
                }
                return url;
            },
            filterBiensForContact: function (biens, contactId) {
                var contactInRelation = function (relation) {
                    return relation.contactRef == contactId && angular.isUndefined(relation.dateFin);
                };
                return _.filter(biens, function (bien) {
                    return bien.relations && _.filter(bien.relations, contactInRelation).length > 0;
                });
            },
            isBienImmeuble: function (bien) {
                return bien && bien._class === '.BienImmeuble';
            },
            isBienMaison: function (bien) {
                return bien && bien._class === '.BienMaison';
            },
            isBienAppartement: function (bien) {
                return bien && bien._class === '.BienAppartement';
            },
            isBienIndefini: function (bien) {
                return bien && bien._class === '.BienIndefini';
            },
            getProjectForBien: function (bienRef) {
                return Restangular.one('biens', bienRef).getList('projets');
            },
            getProjectStatsForBien: function (bienRef) {
                return Restangular.one('biens', bienRef).customGET('projetStats');
            },
            endRelation: function (relation) {
                if(relation) {
                    relation.dateFin = new Date()
                }
                return relation;
            },
            isValidRelation: function (relation) {
                return relation &&  angular.isDefined(relation._id) &&
                    relation.dateFin == null && relation.type != 'gardien';
            },
            findGardienInRelations: function (immeuble) {
                if (immeuble && immeuble.relations) {
                    for (var i = 0; i < immeuble.relations.length; i++) {
                        var relation = immeuble.relations[i];
                        if ("gardien" === relation.type && angular.isUndefined(relation.dateFin)) {
                            return relation;
                        }
                    }
                }
                return null;
            }
        };
        return service;

    });
