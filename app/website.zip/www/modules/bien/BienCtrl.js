'use strict';
angular
    .module('module.bien')
    .controller('BienCtrl', function ($scope, $stateParams, $state, LoadingConfig, BienService, AdresseService, Restangular, $ionicLoading) {
        $scope.$state = $state;

        angular.extend($scope, {
            setBien: function (bien) {
                $scope.bien = bien;
                $scope.bien.kind = BienService.retrieveKindByClass(bien);
                $scope.selectedProject = bien.dernierProjet;
                if ($scope.bien.immeubleRef) {
                    AdresseService
                        .getAdresseForImmeuble($scope.bien.immeubleRef)
                        .then(function (adresse) {
                            $scope.bien.adresse = adresse;
                            $scope.bien.formatedAdresse = AdresseService.getFormatedAdresse(adresse);
                        })
                } else {
                    console.log('Bien sans immeuble ref :', $scope.bien);
                }
            },
            loadBien : function(id){
                $ionicLoading.show(LoadingConfig);
                BienService
                    .get(id)
                    .then($scope.setBien)
                    .finally($ionicLoading.hide);
            }
        });

        $scope.loadBien($state.params.bienId);
    });
