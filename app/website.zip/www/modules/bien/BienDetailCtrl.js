'use strict';
angular
    .module('module.bien')
    .controller('BienDetailCtrl', function ($scope, $rootScope, $state, $timeout, $ionicSlideBoxDelegate, $ionicModal, $ionicPopup, $ionicScrollDelegate, $filter, Toast,
                                            BienService, PhotoService, ContactService, ContactActionsService, Restangular, $cordovaKeyboard, AdresseService, $ionicLoading, SavingConfig) {

        var i18n = $filter('i18n');
        $cordovaKeyboard.close();
        angular.extend($scope, {
            detailByKind: {
                'Maison': 'modules/bien/vignettes/vignette-maison.html',
                'Appartement': 'modules/bien/vignettes/vignette-appartement.html',
                'Terrain': 'modules/bien/vignettes/vignette-terrain.html',
                'Parking': 'modules/bien/vignettes/vignette-parking.html',
                'Indefini': 'modules/bien/vignettes/vignette-indefini.html'
            },
            datas: {
                hideProposal: true,
                modifiedDescription: false
            },
            BienService: BienService,
            PhotoService: PhotoService,
            ContactService: ContactService,
            contactTypes: ContactService.getContactType(),
            addSuivi: function (bien) {
                ContactActionsService.addSuiviOnBien(bien, $scope).then(function (suivi) {
                    $scope.histories.splice(0, 0, suivi);
                });
            },
            addRelation: function (bien) {
                if (angular.isUndefined($scope.newRelation)) {
                    $scope.newRelation = {'dateDebut': new Date(), type: 'indetermine'};
                    $ionicScrollDelegate.scrollElementToTop("list-relation-new-contact", "bien-id-content");
                } else {
                    $scope.clearNewRelation();
                }
            },
            clearNewRelation: function () {
                $scope.newRelation = undefined;
            },
            bienHasDetail: function (bien) {
                if(bien.selectedSector && bien.selectedSector.Key !== 0) {
                    return true;
                }
                switch (bien._class) {
                    case '.BienAppartement' :
                        return (angular.isDefined(bien.surface) && bien.surface > 0) || (angular.isDefined(bien.nbPieces) && bien.nbPieces > 0) || (angular.isDefined(bien.numeroEtage) && bien.numeroEtage > 0) || (angular.isDefined(bien.numeroAppartementDesc));
                    case '.BienMaison' :
                        return (angular.isDefined(bien.surface) && bien.surface > 0) || angular.isDefined(bien.nbPieces) || angular.isDefined(bien.nbEtages);
                    default :
                        return (angular.isDefined(bien.surface) && bien.surface > 0);
                }
            },
            openEditDetailPopup: function () {
                $scope.bienEdit = BienService.copy($scope.bien);

                var page = $scope.bien._class.substring('.Bien'.length).toLowerCase();
                $ionicPopup.show({
                    templateUrl: 'modules/bien/popup/edit-detail-' + page + '.html',
                    title: i18n('bien.detail') + ('<i data-icon class="ion-edit"></i>'),
                    scope: $scope,
                    cssClass: 'bigPopup',
                    buttons: [
                        {
                            text: i18n('cancel'),
                            type: 'button-popup button-grey',
                            onTap: function () {
                            }
                        },
                        {
                            text: i18n('save'),
                            type: 'button-popup button-energized',
                            onTap: function () {
                                $ionicLoading.show(SavingConfig);
                                BienService
                                    .save($scope.bienEdit)
                                    .then(function (savedBien) {
                                        if (savedBien._id != $scope.bienEdit._id) {
                                            //Changement d'id car fusion d'ap
                                            $state.go('nav.bien.detail', {bienId: savedBien._id});
                                        } else {
                                            $scope.setBien(savedBien);
                                        }
                                    })
                                    .finally(function () {
                                        delete $scope.bienEdit;
                                        $ionicLoading.hide();
                                    });
                            }
                        }
                    ]
                });
            },
            refreshSlideBox: function () {
                $ionicSlideBoxDelegate.$getByHandle('pictureSlidebox').update();
            },
            showProjectDetail: function () {
                return true;
            },
            addImage: function (file) {
                BienService.addImage($scope.bien, file);
            },
            takePicture: function () {
                PhotoService.takePicture(function (imageUri) {
                    BienService.addImage($scope.bien, imageUri);
                });
            },
            openFullScreen: function () {
                if($scope.bien && $scope.bien._id) {
                    $ionicModal.fromTemplateUrl('modules/bien/popup/image-plein-ecran.html', {
                        scope: $scope,
                        animation: 'slide-in-up'
                    }).then(function (modal) {
                        $scope.modal = modal;
                        modal.show();
                    });
                }
            },
            closeModal: function () {
                $scope.modal.remove();
            },
            loadHistories: function (options) {
                if (angular.isDefined($scope.bien)) {
                    if (angular.isUndefined(options)) {
                        //no option first load
                        $scope.histories = [];
                    }
                    options = options || {limiteMois: 6};
                    Restangular.one('biens', $scope.bien._id)
                        .getList('history', options)
                        .then(function (result) {
                            $scope.histories = result;
                            $timeout(function () {
                                $ionicScrollDelegate.resize()
                            }, 80);
                        });
                }
            },
            saveDescription: function () {
                BienService.save($scope.bien).then(function (savedBien) {
                    $scope.bien = savedBien;
                    $scope.datas.modifiedDescription = false;
                });
            },
            cancelDescription: function () {
                $scope.loadBien($scope.bien._id);
                $scope.datas.modifiedDescription = false;
            }
        });

        $timeout(function () {
            $ionicScrollDelegate.$getByHandle('bien-id-content').scrollTop();
        }, 10);

        $scope.$on('$destroy', function () {
            if ($scope.modal) {
                $scope.modal.remove();
            }
            if ($scope.quickModal) {
                $scope.quickModal.remove();
            }
        });

        $scope.$on('$destroy', $rootScope.$on('contactPicker.end', $scope.clearNewRelation));
        $scope.$on('$destroy', $rootScope.$on('contactPicker.cancel', $scope.clearNewRelation));

        $scope.$on('$destroy', $scope.$watch('bien.images.length', function (newV, oldV) {
            if (angular.isDefined(newV) && newV !== oldV) {
                console.log('refreshSlideBox', newV, oldV);
                $scope.refreshSlideBox();
            }
        }));
    });
