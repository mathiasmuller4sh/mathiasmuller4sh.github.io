'use strict';
angular
    .module('module.bien')
    .controller('ProjetBienCtrl', function ($scope, $state, $stateParams, $ionicPopup, $timeout, leafletData, ContactService, BienService, AdresseService, MapService, Restangular) {
        angular.extend($scope, {
            histories: [],
            typesProfilTypes: BienService.typesProfilTypes,
            templatesByType: {
                acquereur: 'modules/bien/projet/view/projet-acquereur-view.html',
                vendeur: 'modules/bien/projet/view/projet-vendeur-view.html',
                mandat: 'modules/bien/projet/view/projet-mandat-view.html',
                mandat_de_vente: 'modules/bien/projet/view/projet-mandat-view.html',
                estime: 'modules/bien/projet/view/projet-estimation-view.html',
                estimation: 'modules/bien/projet/view/projet-estimation-view.html',
                prospect: 'modules/bien/projet/view/projet-prospect-view.html',
                locataire: 'modules/bien/projet/view/projet-locataire-view.html',
                bailleur: 'modules/bien/projet/view/projet-bailleur-view.html'
            },
            leafletContact: MapService.getMapConfiguration(),

            init: function (project) {
                $scope.projet = project;
                $scope.loadHistories();
            },
            openExternalLink: function (link) {
                window.open(link, "_system", "location=yes");
            },
            isArchived: function (projet) {
                return BienService.isArchived(projet);
            },
            toggleQualificationProjet: function (currentQualification, project) {
                if($scope.contact) {
                    switch (currentQualification) {
                        case 'A' :
                            project.qualificationProjet = 'B';
                            break;
                        case 'B' :
                            project.qualificationProjet = 'C';
                            break;
                        case 'C' :
                            project.qualificationProjet = 'A';
                            break;
                    }
                    ContactService.save($scope.contact);
                }
            },
            isLessSixMonth : function(projectDate) {
                var delta = (new Date()- new Date(projectDate))/86400000;
                if (delta < 180) {
                    return true;
                } else {
                    return false;
                }
            },
            containsData : function(projet){
                return (angular.isDefined(projet.price) && projet.price != null) ||
                    (angular.isDefined(projet.projetDate) && projet.projetDate != null) ||
                    (angular.isDefined(projet.qualificationProjet) &&  projet.qualificationProjet != null);
            }
        });

        //select project on load
        $scope.$watch('selectedProject', $scope.init);
    });
