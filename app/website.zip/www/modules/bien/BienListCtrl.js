'use strict';
angular
    .module('module.bien')
    .controller('BienListCtrl', function ($scope, $rootScope, $timeout, $filter, $state, $ionicScrollDelegate, $ionicPopup,
                                          Restangular, LoadingConfig, BienService, $ionicLoading, AdresseService ) {
        if(angular.isUndefined($rootScope.bienFiltres)) {
            $rootScope.bienFiltres = {};
        } else {
            console.log('filtre in rootscope',$rootScope.bienFiltres);
        }

        angular.extend($scope, {
            BienService: BienService,
            count:'...',
            noMoreItemsAvailable : false,
            loading: false,
            biens:[],
            filtres: angular.extend({}, {
                avancementFilter: "",
                searchText: null,
                conseillerFilter:'mesbiens',
                debut : 0,
                bienRef : $state.params.bienRef | undefined,
                nombre : 25,
                budget : null,
                nbPieces : null,
                type : null,
                surface : null
            }, $rootScope.bienFiltres),
            getItemHeight: function () {
                return 100;
            },

            bienAvancementFilters: function () {
                //JIRA AMC-134
//                Estimation
//                Mandat de vente
//                Mandat de location
//                Mandat de gestion
//                Mandat AMEPI
//                A été acheté
//                A été loué
                return [
                    {
                        "filter": "",
                        "label": "Projets"
                    }, {
                        "filter": "estimation",
                        "label": "Estimation"
                    }, {
                        "filter": "mandat",
                        "label": "Mandat de vente"
                    }, {
                        "filter": "bailleur",
                        "label": "Mandat de location"
                    },
//                    {
//                        "filter": "mandat_gestion",
//                        "label": "Mandat de gestion"
//                    },
//                    {
//                        "filter": "mandat_amepi",
//                        "label": "Mandat AMEPI"
//                    },
                    {
                        "filter": "Vendu",
                        "label": "A été acheté"
                    }, {
                        "filter": "locataire",
                        "label": "A été loué"
                    }, {
                        "filter": "prospect",
                        "label": "Prospect"
                    }

                ];
            }(),
            getTypeBiens: function () {
                return ["Maison", "Appartement", "Terrain", "Parking", "Non défini"];
            },

            openCriteriaPopUp: function () {
                var scope = angular.extend($rootScope.$new(), {
                    filtres: angular.extend({}, $scope.filtres),
                    getTypeBiens : $scope.getTypeBiens
                });

                $ionicPopup.show({
                    templateUrl: 'modules/bien/popup/searchCriteriaPopup.html',
                    title: "Critères" + "<i class='icon ion-android-options'></i>",
                    scope: scope,
                    cssClass: 'bigPopup',
                    buttons: [
                        {
                            text: 'Effacer',
                            type: 'button-popup button-grey',
                            onTap: function (e) {
                                $scope.clearFilterPopup();
                            }
                        },{
                            text: 'Valider',
                            type: 'button-popup button-energized',
                            onTap: function (e) {
                                angular.extend($scope.filtres, scope.filtres);
                            }
                        }
                    ]
                }).then(function() {
                    scope.$destroy()
                });
            },
            loadMore : function(forcedStart) {
                $scope.loading = true;
                $ionicLoading.show(LoadingConfig);
                if(forcedStart === 0) {
                    $scope.filtres.debut = forcedStart;
                    $scope.noMoreItemsAvailable = false;
                    $scope.biens.splice(0, $scope.biens.length);
                }
                console.log("load bien start:"+$scope.filtres.debut)
                BienService
                    .all(angular.extend({}, $scope.filtres))
                    .then(function (result) {
                        $scope.loading = false;
                        if ($state.params.ids) {
                            $scope.allBiens = [];
                            angular.forEach(result.biens, function (bien) {
                                if (BienService.isBienImmeuble(bien)) {
                                    if (bien.appartements) {
                                        bien.appartements.forEach(function (app) {
                                            app.adresse = bien.adresse;
                                        });
                                        $scope.allBiens = $scope.allBiens.concat($scope.allBiens, bien.appartements);
                                    }
                                } else {
                                    $scope.allBiens.push(bien);
                                }
                            });
                        } else {
                            $scope.allBiens = result.biens;
                        }
                        $scope.allBiens.forEach(function (bien) {
                            if (!bien.formatedAdresse) {
                                bien.kind = BienService.retrieveKindByClass(bien);
                                bien.formatedAdresse = AdresseService.getFormatedAdresse(bien.adresse);
                                $scope.biens.push(bien) ;
                            }
                        });
                        //console.log(result.biens.length, result.count , $scope.filtres.debut)
                        if (result.biens.length == 0 || result.biens.length == result.count + $scope.filtres.debut) {
                            $scope.noMoreItemsAvailable = true;
                            //console.log("no more datas")
                        } else {
                            $scope.filtres.debut = $scope.filtres.debut + $scope.filtres.nombre;
                        }
                        $scope.count = result.count;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    })
                    .finally($ionicLoading.hide);
            },
            scrollTop: function () {
                $ionicScrollDelegate.scrollTop(true);
            },
            searchBoxChanged: function () {
                if(angular.isUndefined($scope.filtres.searchText) || $scope.filtres.searchText === '') {
                    //empty search
                    $scope.filtres.conseillerFilter = $scope.previousConseillerFilter || 'mesbiens';
                    delete $scope.previousConseillerFilter;
                } else {
                    if(angular.isUndefined($scope.previousConseillerFilter)) {
                        $scope.previousConseillerFilter = $scope.filtres.conseillerFilter;
                        $scope.filtres.conseillerFilter = 'touslesbiens';
                    }
                }
                $scope.scrollTop();
            },
            doRefresh: function () {
                $scope.clearFilter();
                BienService.cleanCache();
                $scope.loadMore(0);
            },

            clearSearchBox: function () {
                $scope.filtres.searchText = undefined;
                $scope.searchBoxChanged();
            },
            clearFilterPopup: function () {
                $scope.filtres.type = undefined;
                $scope.filtres.nbPieces = undefined;
                $scope.filtres.surface = undefined;
                $scope.filtres.budget = undefined;
            },
            clearFilter: function () {
                $scope.filtres.console = undefined;
                $scope.filtres.avancementFilter = "";
                $scope.filtres.debut = 0;
                $scope.clearSearchBox()
                $scope.clearFilterPopup();
            }

        });

        $scope.$watch('filtres', _.debounce(function (newValue, oldValue) {
            if(newValue.searchText !== oldValue.searchText ||
                newValue.avancementFilter !== oldValue.avancementFilter ||
                newValue.conseillerFilter !== oldValue.conseillerFilter ||
                newValue.nbPieces !== oldValue.nbPieces ||
                newValue.surface !== oldValue.surface ||
                newValue.budget !== oldValue.budget ||
                newValue.type !== oldValue.type ) {
                //clean console when changing filter
                $scope.filtres.console = null;
                $scope.loadMore(0);
                $rootScope.bienFiltres = angular.extend($rootScope.bienFiltres, newValue);
            }
        }, 500), true);
    });
