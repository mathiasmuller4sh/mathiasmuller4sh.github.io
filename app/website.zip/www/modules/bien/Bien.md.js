'use strict';
angular.module('module.bien',[]);
