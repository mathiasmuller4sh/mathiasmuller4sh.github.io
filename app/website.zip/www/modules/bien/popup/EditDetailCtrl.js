angular.module('module.bien').controller('EditDetailCtrl', function ($scope, BienService) {
    angular.extend($scope, {
        etages: BienService.getEtagesChoices($scope.bien),
        bats: function() {
            var b = [];
            for(var i= 1, l= $scope.bien.nbBatiments;i<=l;i++) {
                b.push(""+i);
            }
            return b;
        }()
    });
});
