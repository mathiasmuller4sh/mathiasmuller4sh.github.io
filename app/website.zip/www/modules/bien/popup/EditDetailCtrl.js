angular.module('module.bien').controller('EditDetailCtrl', function ($scope, BienService) {
    angular.extend($scope, {
        etages: BienService.getEtagesChoices($scope.bien),
        bats: BienService.getBatimentsChoices($scope.bien)
    });
});
