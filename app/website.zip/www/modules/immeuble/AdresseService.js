'use strict';
angular
    .module('module.immeuble')
    .factory('AdresseService', function (Restangular) {
        function buildParametersForGet(options) {
            var params = {};
            options = options || {};
            params.withNextPrevious = options.withAround === true;
            params.withBiens = options.withBiens === true;
            return params;
        }

        Restangular.extendModel('adresses', function (obj) {
            return angular.extend(obj, {
            });
        });

        var service = {
            find: function (params) {
                return Restangular.all('adresses').getList(params);
            },
            all: function () {
                return Restangular.all('adresses').getList();
            },
            save: function (adresse) {
                if(angular.isUndefined(adresse.put)) {
                    adresse = Restangular.restangularizeElement(null, adresse, 'adresses');
                }
                return adresse.put();
            },
            getObject: function (id, options) {
                return service.get(id, options).$object;
            },
            getOtherSide: function (source, options) {
                return Restangular.one('adresses', source._id).customGET("otherside", buildParametersForGet(options));
            },
            get: function (id, options) {
                return Restangular.one('adresses', id).get(buildParametersForGet(options));
            },
            getFormatedAdresse: function (adresse) {
                if(angular.isUndefined(adresse)) {
                    return '-';
                }
                if(angular.isDefined(adresse.ac)) {
                    return adresse.ac;
                }
                if (angular.isDefined(adresse) && angular.isDefined(adresse.numero) && angular.isDefined(adresse.rue) && angular.isDefined(adresse.codePostal) && angular.isDefined(adresse.ville)) {
                    return (adresse.numero && adresse.numero>0?adresse.numero + " ":"") + adresse.rue + " " + adresse.codePostal + " " + adresse.ville + " ";
                }
                return "";
            },
            newAdresseLink: function (adresse) {
                return {
                    adresse: adresse ,
                    adresseString: adresse?service.getFormatedAdresse(adresse):'',
                    adresseRef: adresse?adresse._id:undefined
                };
            },
            getAdresseForImmeuble : function(immeubleRef){
                return Restangular.one('biens',  immeubleRef).customGET('adresse');
            }
        };
        return  service;
    });
