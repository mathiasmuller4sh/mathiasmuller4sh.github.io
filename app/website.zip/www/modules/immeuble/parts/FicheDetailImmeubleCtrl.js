'use strict';

angular
    .module('module.immeuble')
    .controller('FicheDetailImmeubleCtrl', function ($scope) {
        angular.extend($scope, {
            hasDetail: function(bien, gardienRelation) {
                return bien &&   (bien.typeCopropriete ||  bien.code || (gardienRelation &&  gardienRelation.contact.nom) || bien.nbAppartements>0);
            }
        });

    });