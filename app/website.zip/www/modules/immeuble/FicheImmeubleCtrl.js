'use strict';

angular
    .module('module.immeuble')
    .controller('FicheImmeubleCtrl', function ($rootScope, $scope, $state, $stateParams, $filter, $ionicPopup, $timeout, $analytics,
                                               $ionicModal, $ionicLoading, $ionicScrollDelegate, $ionicGesture, $ionicSideMenuDelegate,
                                               LoadingConfig, Restangular, ContactService, AdresseService, BienService, MapService, PhotoService, ContactActionsService) {
        var i18n = $filter('i18n');

        function countRelationKind(apparts, kind) {
            var count = 0;
            var cache = {};
            for (var i = 0, l = apparts.length; i < l; i++) {
                var a = apparts[i];
                for (var j = 0, k = a.relations.length; j < k; j++) {
                    var r = a.relations[j];
                    if (r.type == kind && angular.isUndefined(cache[r.contactRef]) && BienService.isValidRelation(r)) {
                        count++;
                        cache[r.contactRef] = 1;
                    }
                }
            }
            return count;
        }

        function showLoading() {
            $ionicLoading.show(LoadingConfig);
        }

        function saveBienImmeuble(bienImmeuble) {
            BienService.showSaveOngoingToast();
            BienService.save(bienImmeuble).then(function (bienImmeuble) {
                BienService.showSaveToast();
                //update in memory
                $scope.adresse.immeuble.biens = [bienImmeuble];
                $scope.display($scope.adresse);
            });
        }

        function saveImmeubleInfos(immeubleEdit, bienImmeuble) {
            bienImmeuble.code = immeubleEdit.bienImmeuble.code;
            bienImmeuble.typeCopropriete = immeubleEdit.bienImmeuble.typeCopropriete;
            bienImmeuble.nbAppartements = immeubleEdit.bienImmeuble.nbAppartements;
            bienImmeuble.relations = immeubleEdit.bienImmeuble.relations;

            if ((angular.isDefined(immeubleEdit.gardienRelation) && ContactService.formatContact(immeubleEdit.gardienRelation.contact) != immeubleEdit.gardienNom) ||
                (angular.isUndefined(immeubleEdit.gardienRelation) && angular.isDefined(immeubleEdit.gardienNom) && immeubleEdit.gardienNom.trim() !== '')) {
                if(immeubleEdit.gardienNom.trim() === '') {
                    //suppression du lien gardien
                    BienService.endRelation(BienService.findGardienInRelations(bienImmeuble));
                    saveBienImmeuble(bienImmeuble);
                } else {
                    //creation gardien
                    $ionicPopup.confirm({
                        title: "Création d'un gardien",
                        template: 'Confirmez vous la création du gardien ' + immeubleEdit.gardienNom.trim() + ' ?',
                        cssClass:'confirm-popup',
                        cancelType: 'button-grey button-popup',
                        okType: 'button-energized button-popup',
                        cancelText: 'Non',
                        okText: 'Oui'
                    }).then(function (res) {
                        if (res) {
                            //saisie a la volée d'un nom de gardien sans completion
                            BienService.cleanupRelation($scope.adresse.immeuble.biens);
                            var newContact = ContactService.newContact({
                                nom: immeubleEdit.gardienNom.trim(),
                                adresse: angular.extend({}, $scope.adresse),
                                keywords: ['Gardien']
                            });
                            ContactService.save(newContact).then(function (contactGardien) {
                                var gardienRelation = ContactService.newGardienRelation(contactGardien);
                                BienService.endRelation(BienService.findGardienInRelations(bienImmeuble));
                                bienImmeuble.relations ? bienImmeuble.relations.push(gardienRelation) : bienImmeuble.relations = [gardienRelation];
                                saveBienImmeuble(bienImmeuble)
                            });
                        } else {
                            immeubleEdit.gardienNom = '';
                            saveBienImmeuble(bienImmeuble);
                        }
                    });
                }
            } else {
                saveBienImmeuble(bienImmeuble);
            }
        }

        angular.extend($scope, {
            PhotoService: PhotoService,
            BienService: BienService,
            ContactService: ContactService,
            bienLimit: 10,
            selectedTab: 'contact',
            typeCopros: ['bailleurUnique', 'copropriete', 'institutionnel'],
            immeubleRelations: {},
            histories: [],
            synthesisByType: {
                '.BienIndefini': 'modules/immeuble/parts/immeuble-syntesis.html',
                '.BienImmeuble': 'modules/immeuble/parts/immeuble-syntesis.html',
                '.BienParking': 'modules/immeuble/parts/parking-syntesis.html',
                '.BienMaison': 'modules/immeuble/parts/maison-syntesis.html',
                '.BienTerrain': 'modules/immeuble/parts/terrain-syntesis.html',
            },
            detailByType: {
                '.BienImmeuble': 'modules/immeuble/parts/immeuble-detail.html',
                '.BienParking': 'modules/immeuble/parts/parking-detail.html',
                '.BienMaison': 'modules/immeuble/parts/maison-detail.html',
                '.BienTerrain': 'modules/immeuble/parts/terrain-detail.html',
                '.Bien': 'modules/immeuble/parts/bien-detail.html'
            },
            increaseLimit: function () {
                $scope.bienLimit += 20;
            },
            updateOddEven: function () {
                $scope.even = $scope.adresse && $scope.adresse.numero ? parseInt($scope.adresse.numero.replace(/[^\d.]/g, "")) % 2 === 0 : null;
                $scope.odd = $scope.adresse && $scope.adresse.numero ? parseInt($scope.adresse.numero.replace(/[^\d.]/g, "")) % 2 != 0 : null;
            },
            selectContactProposal: function (proposalContact) {
                $scope.contactToEdit = proposalContact;
                $scope.proposalContacts = null;
            },
            contactCompletion: _.debounce(function (input, relation, isGardien) {
                $scope.$apply(function () {
                    if (angular.isUndefined(input) || input.length < 3) {
                        return;
                    }
                    $scope.datas.hideProposal = false;
                    $scope.loadingGardien = true;
                    var p = ContactService.findByQuery(input, isGardien === true ? {keyword: 'gardien'} : null);
                    p.finally(function() {
                        $scope.loadingGardien = false;
                    });
                    $scope.proposalContacts = p.$object;
                    $scope.proposalContacts.query = input;
                })
            }, 500),
            selectGardienProposal: function (proposalContact) {
                var immeuble = $scope.immeubleEdit.bienImmeuble;
                var gardienRelation = $scope.immeubleEdit.gardienRelation;
                if (gardienRelation && gardienRelation._id) {
                    if (gardienRelation.contact && gardienRelation.contact._id != proposalContact._id) {
                        //end existing relation
                        BienService.endRelation(gardienRelation);
                        gardienRelation = null;
                    } else {
                        //update phase
                        gardienRelation.contact = proposalContact;
                    }
                }
                if (!gardienRelation) {
                    gardienRelation = ContactService.newGardienRelation(proposalContact);
                    immeuble.relations ? immeuble.relations.push(gardienRelation) : immeuble.relations = [gardienRelation];
                    $scope.immeubleEdit.gardienRelation = gardienRelation;
                }
                $scope.immeubleEdit.gardienNom = ContactService.formatContact(proposalContact);
                $scope.proposalContacts = null;
            },
            openImmeubleDetailPopup: function () {
                $scope.immeubleEdit = {
                    bienImmeuble: angular.extend({}, $scope.datas.bien),
                    gardienNom: $scope.gardienRelation ? ContactService.formatContact($scope.gardienRelation.contact) : undefined,
                    gardienRelation: $scope.gardienRelation
                };

                //TODO remove once ionic14
                $ionicPopup.show({
                    templateUrl: 'modules/immeuble/edition-gardien.html',
                    title: i18n('synthesis.building'),
                    scope: $scope,
                    cssClass: 'bigPopup',
                    buttons: [
                        {
                            text: i18n('cancel'),
                            type: 'button-popup button-grey',
                            onTap: function () {
                            }
                        },
                        {
                            text: i18n('save'),
                            type: 'button-popup button-energized',
                            onTap: function () {
                                saveImmeubleInfos($scope.immeubleEdit, $scope.datas.bien);
                            }
                        }
                    ]
                });
            },
            validRelation: function (val) {
                return BienService.isValidRelation(val);
            },
            filterProprietaireAndGardien: function (val) {
                return val.type != 'proprietaire' && val.type != 'gardien' && angular.isUndefined(val.dateFin);
            },
            getNbProprietaires: function (apparts) {
                return countRelationKind(apparts, "proprietaire");
            },
            getNbLocataires: function (apparts) {
                return countRelationKind(apparts, "locataire");
            },
            getNbBailleurs: function (apparts) {
                return countRelationKind(apparts, "bailleur");
            },
            getNbIndefinis: function (apparts) {
                return countRelationKind(apparts, "indetermine");
            },
            getNbRelation: function (bien) {
                var nb = 0;
                if (bien && bien._class !== '.Bien') {
                    if (bien._class === '.BienImmeuble') {
                        for (var i = 0, l = bien.appartements.length; i < l; i++) {
                            var a = bien.appartements[i];
                            for (var j = 0, k = a.relations.length; j < k; j++) {
                                if (BienService.isValidRelation(a.relations[j])) {
                                    nb++;
                                }
                            }
                        }
                    } else {
                        for (var j = 0, k = bien.relations.length; j < k; j++) {
                            if (BienService.isValidRelation(bien.relations[j])) {
                                nb++;
                            }
                        }
                    }
                }
                return nb;
            },
            getNbBiens: function (bien) {
                var nb = 0;
                if (bien && bien._class !== '.Bien') {
                    nb = 1;
                    if (bien._class === '.BienImmeuble') {
                        nb = bien.appartements.length;
                    }
                }
                return nb;
            },
            getNbProjet: function (bien, typeProjet) {
                var nb = 0;
                if (bien && bien._class !== '.Bien') {
                    if (bien._class !== '.BienImmeuble' && bien.dernierProjetType && bien.dernierProjetType.indexOf(typeProjet) > -1) {
                        nb++;
                    }

                    if (bien._class === '.BienImmeuble') {
                        for (var i = 0, l = bien.appartements.length; i < l; i++) {
                            if (bien.appartements[i].dernierProjetType && bien.appartements[i].dernierProjetType.indexOf(typeProjet) > -1) {
                                nb++;
                            }
                        }
                    }
                }
                return nb;
            },
            filterByDateFin: function (relation) {
                return (relation.dateFin == null);
            },
            gotoEvenSide: function () {
                $scope.gotoSide('even');
            },
            gotoOddSide: function () {
                $scope.gotoSide('odd');
            },
            gotoSide: function (side) {
                $scope.even = side === 'even';
                $scope.odd = side === 'odd';
                showLoading();
                AdresseService
                    .getOtherSide($scope.adresse)
                    .then(function (other) {
                        $state.go('nav.map.immeuble', {id: other._id});
                    })
                    .finally($ionicLoading.hide);
            },
            previousInStreet: _.debounce(function () {
                var precedent = $scope.adresse.precedent;
                if (precedent) {
                    $scope.leaflet.featureSelectedId = precedent._id;
                    $state.go('nav.map.immeuble', {id: precedent._id}, {location: true, notify: true});
                }
            }, 200, {leading: true}),
            nextInStreet: _.debounce(function () {
                var suivant = $scope.adresse.suivant;
                if (suivant) {
                    $scope.leaflet.featureSelectedId = suivant._id;
                    $state.go('nav.map.immeuble', {id: suivant._id}, {location: true, notify: true});
                }
            }, 200, {leading: true}),
            load: function (id) {
                showLoading();
                AdresseService
                    .get(id, {withAround: true, withBiens: true})
                    .then($scope.display)
                    .finally($ionicLoading.hide);
            },
            insurePrevNextOrder: function (adresse) {
                if (adresse && adresse.location && adresse.location.coordinates.length > 1) {
                    if (adresse.precedent && adresse.precedent.location && adresse.precedent.location.coordinates && adresse.precedent.location.coordinates.length > 1) {

                        var latP = adresse.precedent.location.coordinates[1];
                        var latO = adresse.location.coordinates[1];
                        //if (Math.abs(latP - latO) < 0.009) {
                        //if to much diff in lat do not try to correct left/right
                        //console.log("lat diff" + Math.abs(latP - latO));
                        var lngP = adresse.precedent.location.coordinates[0];
                        var lngO = adresse.location.coordinates[0];
                        if (lngO - lngP < 0) {
                            //console.log("Precedent diff orig - precent" + (lngO - lngP));
                            var tmp = adresse.suivant;
                            adresse.suivant = adresse.precedent;
                            adresse.precedent = tmp;
                        }
                        //} else {
                        //console.log("up down let std order" + (Math.abs(latP) - Math.abs(latO)));
                        //}
                    }
                    else if (adresse.suivant && adresse.suivant.location && adresse.suivant.location.coordinates && adresse.suivant.location.coordinates.length > 1) {
                        var lngP = adresse.suivant.location.coordinates[0];
                        var lngO = adresse.location.coordinates[0];
                        if (lngO - lngP > 0) {
                            //console.log("Suivant diff orig - precent" + (lngO - lngP));
                            var tmp = adresse.precedent;
                            adresse.precedent = adresse.suivant;
                            adresse.suivant = tmp;
                        }
                    }
                    //console.log("lat diff", adresse.precedent.location.coordinates[1] - adresse.suivant.location.coordinates[1])
                }
            },
            loadHistories: function (options) {
                if (angular.isUndefined(options)) {
                    //no option first load
                    $scope.histories = [];
                }
                options = options || {limiteMois: 6};
                Restangular.one('adresses', $scope.adresse._id)
                    .getList('history', options)
                    .then(function (result) {
                        $scope.histories = result;
                        $timeout(function() {$ionicScrollDelegate.resize()}, 80);
                    });
            },
            display: function (adresse) {
                if (angular.isObject(adresse)) {
                    //$scope.insurePrevNextOrder(adresse);
                    adresse.immeuble = adresse.immeuble || {};
                    $scope.histories = [];
                    adresse.immeuble.biens = adresse.immeuble.biens || [];
                    $scope.adresse = adresse;
                    var immeuble = adresse.immeuble;
                    $scope.biens = immeuble.biens;

                    if(immeuble.biens.length > 0) {
                        var appartements = immeuble.biens[0].appartements;
                        if(appartements && appartements.length > 0 &&
                            !BienService.isBienAppartement(appartements[0]) &&
                            !BienService.isBienIndefini(appartements[0])) {
                            //hack since server sometime send maison in appartement
                            $scope.datas.bien = $scope.immeubleRelations = appartements[0];
                        } else {
                            $scope.datas.bien = immeuble.biens[0];
                            //fake immeuble for relation
                            $scope.immeubleRelations = angular.extend($scope.immeubleRelations, {
                                _class: $scope.datas.bien._class,
                                adresse: $scope.datas.bien.adresse,
                                immeubleRef: $scope.datas.bien.immeubleRef,
                                appartements: $scope.datas.bien.appartements,
                                relations: $scope.collectRelations($scope.datas.bien)
                            });
                        }
                    } else {
                        $scope.datas.bien = $scope.immeubleRelations = {
                            _class: ".Bien",
                            images: [],
                            adresse: adresse
                        };
                    }
                    $scope.gardienRelation = BienService.findGardienInRelations($scope.datas.bien);

                    $scope.loadHistories();
                    $scope.updateOddEven();
                    $scope.leaflet.featureSelectedId = $scope.adresse._id;
                    MapService.centerOnFeature($scope.leaflet, $scope.adresse.location, true)
                } else {
                    $scope.load(adresse);
                }
            },
            collectRelations: function (bien) {
                var relations = [];

                function collect(bienObj) {
                    angular.forEach(bienObj.relations, function (rel) {
                        //copy avoid circular ref copy relation
                        //rel = angular.extend({}, rel);
                        //keep a link to bien
                        rel.bien = angular.extend({}, bienObj);
                        //copy.bien = bienObj;
                        if (angular.isDefined(rel.contact) && angular.isDefined(rel.contactRef) && rel.dateFin == null) {
                            relations.push(rel);
                        }
                    });
                }

                //get immeuble relation
                collect(bien);
                //get appartements relation
                angular.forEach(bien.appartements, collect);

                return $filter('orderBy')(relations, function (relation) {
                    return relation.contactString;
                });
            },
            openFullScreen: function () {
                $scope.bien = $scope.datas.bien;
                $scope.bien.adresse = $scope.adresse;
                $ionicModal.fromTemplateUrl('modules/bien/popup/image-plein-ecran.html', {
                    scope: $scope,
                    animation: 'slide-in-up'
                }).then(function (modal) {
                    $scope.modal = modal;
                    modal.show();
                });
            },
            closeModal: function () {
                $scope.modal.remove();
            },
            addImage: function (file) {
                BienService.addImage($scope.datas.bien, file);
            },
            takePicture: function () {
                PhotoService.takePicture(function (imageUri) {
                    BienService.addImage($scope.datas.bien, imageUri);
                });
            },
            //deprecated use service directly
            formatContact: function (contact) {
                return ContactService.formatContact(contact);
            },

            closeQuickActionModal: function () {
                $rootScope.actionPopup = undefined;
                $scope.quickModal.hide();
            },
            getBienText: function (bien) {
                var text = i18n(bien.type || bien._class);
                if (bien._class === '.BienAppartement' || bien._class === '.BienMaison') {
                    if (angular.isDefined(bien.numeroEtage) && bien.numeroEtage != 0) {
                        text += ' ' + bien.numeroEtage + (bien.numeroEtage == 1 ? 'er' : 'ème');
                    }
                    if (angular.isDefined(bien.nbPieces)) {
                        text += ' ' + (bien.nbPieces != 0 ? bien.nbPieces + ' piece(s)' : '');
                    }
                }
                return text;
            },
            addSuivi: function (bien) {
                var removeFn = $rootScope.$on("history.added", function(event, hist) {
                    $scope.relationChange(hist, 'suivi');
                    removeFn();
                });
                ContactActionsService.addSuiviOnBien(bien, $scope);
            },
            relationChange: function (newItem, type) {
                if(type == 'suivi' && newItem) {
                    $scope.histories.splice(0,0,newItem);
                }
            },
            addRelation: function (bien) {
                if(angular.isUndefined($scope.newRelation)) {
                    $scope.newRelation = {'dateDebut': new Date(), type: 'indetermine'};
                    $ionicScrollDelegate.scrollElementToTop('list-relation-new-contact', 'global-scroll');
                    $analytics.eventTrack('new_habitant', {  category: $rootScope.gaCategory, label: 'Nouvel habitant' });
                } else {
                    $scope.clearNewRelation();
                }
            },
            clearNewRelation: function () {
                $scope.newRelation = undefined;
            },
            filterProject: function (bien) {
                return bien.dernierProjetType && $scope.selectedTab && bien.dernierProjetType.indexOf($scope.selectedTab) > -1;
            }
        });

        $scope.$on('$destroy', $scope.$watch("$state.params.id", function (newV, oldV) {
            if (newV) {
                $scope.datas.bien = null;
                $scope.display(newV);
            }
        }));

        function refresh() {
            if ($state.params.id && $state.includes('nav.map.**')) {
                console.log('refresh immeuble', $state.params.id)
                $scope.load($state.params.id);
            }
        }

        $scope.$on('$destroy', $rootScope.$on('merge.end', refresh));
        $scope.$on('$destroy', $scope.$on('closeModal', function (id) {
            if ($scope.quickModal) {
                $scope.quickModal.hide();
            }
        }));

        $scope.$on('$destroy', $rootScope.$on('contactPicker.end', refresh));
        $scope.$on('$destroy', $rootScope.$on('contactPicker.end', $scope.clearNewRelation));
        $rootScope.$on('contactPicker.cancel', $scope.clearNewRelation);
        var unreg = $scope.$watch('newRelation', function (n, o) {
            if (n && angular.isDefined(n.contactRef)) {
                unreg();
                $scope.clearNewRelation();
            }
        });

        if (!ionic.Platform.isWindowsPhone()) {
            $timeout(function() {
                var target = angular.element(document.getElementById('fiche-immeuble'));
                var lf = function () {
                    console.log("$ionicSideMenuDelegate.getOpenRatio()",$ionicSideMenuDelegate.getOpenRatio())
                    if ($ionicSideMenuDelegate.getOpenRatio() == 0) {
                        $scope.nextInStreet();
                    }
                };
                var rf = function () {
                    console.log("$ionicSideMenuDelegate.getOpenRatio()",$ionicSideMenuDelegate.getOpenRatio())
                    if ($ionicSideMenuDelegate.getOpenRatio() == 0) {
                        $scope.previousInStreet();
                    }
                };
                var l = $ionicGesture.on("swipeleft", lf, target);
                var r = $ionicGesture.on("swiperight", rf, target);

                $scope.$on('$destroy', function() {
                    $ionicGesture.off(l, "swipeleft", lf);
                    $ionicGesture.off(r, "swiperight", rf);
                });
            },100);
        }
    });
