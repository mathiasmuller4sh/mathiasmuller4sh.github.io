'use strict';
angular.module('4sh.utils',[]);


//override angular isDefined to handle null as undefined
var angularIsDefined = angular.isDefined;
angular.isDefined = function(o) {
    if(o == null) {
        return false;
    }
    return angularIsDefined(o);
};

var angularisUndefined = angular.isUndefined;
angular.isUndefined = function(o) {
    if(o == null) {
        return true;
    }
    return angularisUndefined(o);
};