'use strict';
angular
    .module('4sh.utils')
    .directive('contactPicker', function ($rootScope, ContactService, $ionicModal, $ionicPopup, $ionicScrollDelegate, $cordovaKeyboard, BienService, $timeout, $filter, $q, AdresseService) {
        return {
            restrict: 'EA',
            scope: {relation:'=', bien: '=', adresse: '='},
            templateUrl: 'modules/utils/contact-picker.html',
            controller: function($scope) {
                var sendContactPickerEndMessage = function () {
                    $rootScope.$emit('contactPicker.end');
                };
                var sendContactPickerCancelMessage = function () {
                    $rootScope.$emit('contactPicker.cancel');
                };
                angular.extend($scope, {
                    ContactService:ContactService,
                    datas: {
                        hideProposal: true
                    },
                    cancelContactPick: function() {
                        $cordovaKeyboard.close();
                        var bien = $scope.bien;
                        if($scope.relation.bien) {
                            $scope.relation.bien = bien;
                        }
                        var index = _.findIndex(bien.relations, $scope.relation);
                        if(index > -1) {
                            bien.relations.splice(index, 1);
                        }
                        sendContactPickerCancelMessage();
                    },
                    contactCompletion: _.debounce(function (input, relation) {
                        $scope.$apply(function () {
                            if (angular.isUndefined(input) || input.length < 3) {
                                return;
                            }
                            $scope.datas.hideProposal = false;
                            $scope.proposalMessage = 'Recherche en cours';
                            var serverCall = ContactService.findByQuery(input);
                            serverCall.then(function(result) {
                                if(result.length == 0) {
                                    $scope.proposalMessage = 'Pas de contact avec ce nom';
                                } else {
                                    $scope.proposalMessage = null;
                                }
                            });
                            $scope.proposalContacts = serverCall.$object;
                            $scope.proposalContacts.relation = relation;
                            $scope.proposalContacts.query = input;
                        })
                    }, 500),
                    hideProposal: function () {
                        $scope.proposalContacts = null;
                        $scope.proposalMessage = null;
                        $scope.datas.hideProposal = true;
                    },
                    hideProposalWithDelay: function () {
                        $timeout($scope.hideProposal, 1500);
                    },
                    createContact: function (optionnalName, relation) {
                        var bien = $scope.bien;
                        if (BienService.isBienImmeuble(bien)) {
                            bien = {immeubleRef: bien.immeubleRef};
                        }
                        var lastName = (optionnalName || '').trim();
                        var firstName = '';
                        var spaceIndex = lastName.trim().indexOf(' ');
                        if(spaceIndex > 0) {
                            firstName = lastName.substring(spaceIndex+1);
                            lastName = lastName.substring(0,spaceIndex);
                        }
                        $scope.$emit('contactPicker.createContact.start');
                        ContactService
                            .newContactForm($scope.bien.adresse, bien, {
                                lastName: lastName,
                                firstName: firstName,
                                addAdresseWF: false
                            })
                            .then(function (contactAdded) {
                                $scope
                                    .linkContactandBien(contactAdded, relation)
                                    .then(sendContactPickerEndMessage, sendContactPickerCancelMessage);
                            }, $scope.cancelContactPick)
                            .finally($scope.hideProposal)
                            ;
                    },
                    acceptContactProposal: function (contact) {
                        $scope.$emit('contactPicker.chooseContact.start');
                        $scope
                            .linkContactandBien(contact, $scope.proposalContacts.relation)
                            .then(sendContactPickerEndMessage, sendContactPickerCancelMessage)
                            .finally($scope.hideProposal)
                        ;
                    },
                    linkContactandBien: function (contact, relation) {
                        relation.contact = contact;//ContactService.get(contact._id);
                        relation.type = "indetermine";
                        relation.contactRef = contact._id;
                        relation.contactString = ContactService.formatContact(contact);
                        var targetAdresse = $scope.adresse;
                        if(angular.isUndefined(targetAdresse) && angular.isDefined($scope.bien.adresse)) {
                            targetAdresse = $scope.bien.adresse;
                        }
                        if (!targetAdresse.immeuble || !targetAdresse.immeuble._id) {
                            targetAdresse.immeuble = {
                                nbBienPotentiel: 1,
                                nbBienProspectes: 1
                            };
                            //add immeuble on adresse
                            var deferred = $q.defer();
                             AdresseService.save(targetAdresse).then(function (adresse) {
                                $scope.adresse = adresse;
                                $scope.bien.adresse = adresse;
                                $scope.linkContactandBien(contact, relation).then(deferred.resolve);
                            }, sendContactPickerCancelMessage);
                            return deferred.promise;
                        }
                        if (BienService.isBienImmeuble($scope.bien)) {
                            var existingBien = relation.bien || {immeubleRef: $scope.bien.adresse.immeuble._id, _class:'.BienAppartement'};
                            if(targetAdresse.immeuble && targetAdresse.immeuble.biens && targetAdresse.immeuble.biens.length>0) {
                                //add info for etage and palier
                                existingBien = angular.extend(existingBien, {'choixPaliers':targetAdresse.immeuble.biens[0].choixPaliers, nbEtages:targetAdresse.immeuble.biens[0].nbEtages});
                            }
                            return ContactService
                                .linkBienAndContact($scope.bien.adresse, existingBien, contact, $scope.bien.appartements, null, relation)
                                .then(function (bien) {
                                    relation.bien = bien;
                                    ContactService.addAdresseOnContactIfNeed(relation.contact, bien.adresse);
                                    //$scope.bien.relations.splice($scope.bien.relations.indexOf(relation), 1);
                                }, $scope.cancelContactPick);
                        } else {
                            return ContactService
                                .linkBienAndContact($scope.bien.adresse, $scope.bien, contact, null, null, relation)
                                .then(function (bien) {
                                    $scope.bien.relations = bien.relations;
                                    $scope.bien._id = bien._id;
                                    //Update contact adresse if not al ready present
                                    ContactService.addAdresseOnContactIfNeed(relation.contact, $scope.bien.adresse);
                                }, $scope.cancelContactPick);
                        }
                    }
                });
            }
        }
    });
