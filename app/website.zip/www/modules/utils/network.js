angular
    .module('4sh.utils')
    .config(function ($httpProvider) {
        $httpProvider.interceptors.push(['$q', '$injector', function ($q, $injector) {
            return {
                request: function (config) {
                    if (config.url.indexOf('.html') > -1 || config.url.indexOf('.svg') > -1 ) {
                        return config;
                    }
                    var canceler = $q.defer();
                    config.timeout = canceler.promise;
                    var status = navigator.connection ? navigator.connection.type : null;
                    if (status === 'none' || status === 'unknown') {
                        console.log('status', status, config.url);
                        var Toast = $injector.get('Toast');
                        Toast.show('Votre connexion internet est insuffisante', 'long');
                        if (config.method == 'PUT' || config.method == 'POST') {
                            canceler.resolve();
                        }
                    }
                    return config || $q.when(config);
                },
                responseError: function (rejection) {
                    if (!rejection.config || (rejection.config.url.indexOf('.html') == -1)) {
                        var status = navigator.connection ? navigator.connection.type : null;
                        var Toast = $injector.get('Toast');
                        console.log('responseError', rejection, status);
                        if (rejection.status === 0) {
                            if(angular.isDefined(status)) {
                                Toast.show('Le serveur est inaccessible.');
                            } else {
                                Toast.show('L\'adresse du serveur est incorrecte.');
                            }
                        } else if (rejection.status >= 500) {
                            Toast.show('Une erreur s\'est produite.');
                        } else if (rejection.status >= 400) {
                            if (rejection.status === 401) {
                                $injector.get('Session').setCurrent(null);
                                $injector.get('$state').go('autologin')
                            } else if (rejection.status === 404) {
                                Toast.show('Element non trouvé.');
                            }
                        } else {
                            Toast.show('Une erreur est survenue.('+rejection+')');
                        }
                    }
                    return $q.reject(rejection);
                }
            };
        }]);
    })
    //.run(function ($rootScope, $interval) {
    //    var applyRefreshNetworkStatus = function () {
    //        $rootScope.networkStatus = navigator.connection ? navigator.connection.type : 'unknown';
    //    };
    //
    //
    //    document.addEventListener('deviceready', function () {
    //        $rootScope.$on("offline", applyRefreshNetworkStatus);
    //        $rootScope.$on("online", applyRefreshNetworkStatus);
    //        document.addEventListener("offline", applyRefreshNetworkStatus, false);
    //        document.addEventListener("online", applyRefreshNetworkStatus, false);
    //
    //        // Updating network status every 5s
    //        $interval(applyRefreshNetworkStatus, 5000, 0);
    //        applyRefreshNetworkStatus();
    //    }, false);
    //})
;
