'use strict';
angular.module('4sh.utils')


    .directive('headerShrink', function ($document) {


        return {
            restrict: 'A',
            link: function ($scope, $element, $attr) {
                var y = 0;
                var prevY = 0;
                var scrollDelay = 0.4;
                var fadeAmt;

                //var header = $document[0].body.querySelector('div[nav-bar="active"] .bar-header');
                //var navHeader = $document[0].body.querySelector('.nav-bar-container');
                var header = $document[0].body.querySelector('div[nav-bar="active"] .map-nav-bar');
                var adjust = function (element) {
                    element.style[ionic.CSS.TRANSFORM] = 'translate3d(0, ' + -y + 'px, 0)';
                    for (var i = 0, j = element.children.length; i < j; i++) {
                        var child = element.children[i];
                        child.style[ionic.CSS.TRANSFORM] = 'translate3d(0, ' + -y + 'px, 0)';
                        child.style.opacity = fadeAmt;
                    }
                };

                function onScroll(e) {
                    var headerHeight = header.offsetHeight  || 44;
                    var scrollTop = e.detail ? e.detail.scrollTop : e.currentTarget.scrollTop;

                    if (scrollTop >= 0) {
                        y = Math.min(headerHeight / scrollDelay, Math.max(0, y + scrollTop - prevY));
                    } else {
                        y = 0;
                    }

                    ionic.requestAnimationFrame(function () {
                        fadeAmt = 1 - (y / headerHeight);
                        adjust(header);
                    });

                    prevY = scrollTop;
                }

                $element.bind('scroll', onScroll);
            }
        }
    });

