'use strict';

angular
    .module('4sh.utils')
    .directive('select', function () {
        return {
            restrict: 'E',
            replace: false,
            link: function (scope, element) {
                if (ionic.Platform && ionic.Platform.isWindowsPhone()) {
                    element.attr('data-tap-disabled', 'true');
                }
            }
        };
    });
