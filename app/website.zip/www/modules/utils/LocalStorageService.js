'use strict';
angular.module('4sh.utils').service('LocalStorageService', function () {

    return {
        saveValue: function (key, data) {
            //console.log('LocalStorageService save:' + key + ' val:' + data);
            try {
                window.localStorage.setItem(key, JSON.stringify(data));
            } catch (err) {
                console.log('LocalStorageService save error:' + err);;
            }
        },
        getValue: function (key) {
            try {
                return JSON.parse(window.localStorage.getItem(key));
            } catch (err) {
                return window.localStorage.getItem(key);
            }
        },
        removeValue: function (key) {
            window.localStorage.removeItem(key);
        }
    }

});
