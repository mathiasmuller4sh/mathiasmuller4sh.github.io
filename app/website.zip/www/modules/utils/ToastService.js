'use strict';
angular.module('4sh.utils').service('Toast', function ($ionicLoading, $timeout) {
    var toastLib = {
        show: function (message, duration, position, successCallback, errorCallback) {
            var wait = duration === 'long' ? 5000 : 2000;
            $ionicLoading.show({template: message, noBackdrop: true, duration: wait});
            if (successCallback) {
                $timeout(successCallback, wait);
            }
        }
    };
    document.addEventListener('deviceready', function () {
        if (window.plugins && window.plugins.toast) {
            toastLib = window.plugins.toast;
        }
    });
    return {
        show: function (message, duration, position, successCallback, errorCallback) {
            toastLib.show(message, duration || 'short', position || 'bottom', successCallback, errorCallback);
        }
    }
});
