'use strict';
/*
 */
angular.module('4sh.utils').
    factory('localize', function () {
        return {
            // array to hold the localized resource string entries
            missingKeys: {},

            getLocalizedString:function (value, LocalDictionary, ignoreMissing) {
                // default the result to an empty string
                var result = '';

                if (_.isEmpty(value)) {
                    return result;
                }

                // make sure the dictionary has valid data
                if (LocalDictionary !== {}) {
                    result = LocalDictionary[value];
                    if (angular.isUndefined(result)) {
                        result = value + (angular.isDefined(ignoreMissing) && ignoreMissing == true?'':'#');
                        if(angular.isUndefined(this.missingKeys[value])) {
                            console.log('missing key:'+ value);
                            this.missingKeys[value]="";
                        }
                    }
                }

                // return the value to the call
                return result;
            }
        };
    }).
    filter('i18n',  function (localize, LocalDictionary) {
        return function (input, ignoreMissing) {
            return localize.getLocalizedString(input, LocalDictionary, ignoreMissing);
        };
    });
