'use strict';
// from https://raw.githubusercontent.com/driftyco/ng-cordova/master/src/plugins/keyboard.js
// install   :      cordova plugin add https://github.com/driftyco/ionic-plugins-keyboard.git
// link      :      https://github.com/driftyco/ionic-plugins-keyboard
angular
    .module('4sh.utils')
    .factory('$cordovaKeyboard', [function () {
        var hasKeyBoardPlugin = window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard;

        return {
            hideAccessoryBar: function (bool) {
                return hasKeyBoardPlugin ? window.cordova.plugins.Keyboard.hideKeyboardAccessoryBar(bool) : angular.noop();
            },
            show: function () {
                return hasKeyBoardPlugin ? window.cordova.plugins.Keyboard.show() : angular.noop();
            },
            close: function () {
                return hasKeyBoardPlugin ? window.cordova.plugins.Keyboard.close() : angular.noop();
            },
            disableScroll: function (bool) {
                return hasKeyBoardPlugin ? window.cordova.plugins.Keyboard.disableScroll(bool) : angular.noop();
            },
            isVisible: function () {
                return hasKeyBoardPlugin ? window.cordova.plugins.Keyboard.isVisible : false;
            }
        }
    }]);
