'use strict';
/*
 */
angular.module('4sh.utils').
    filter('frenchphone',  function () {
        return function (tel) {
            if (!tel) { return ''; }
            var value = tel.toString().trim().replace(/^\+/, '');

            if (value.match(/[^0-9]/)) {
                return tel;
            }
            return tel.replace(/.{1,2}/g, "$& ");
        };
    });
