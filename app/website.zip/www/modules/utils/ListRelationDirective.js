'use strict';
angular
    .module('4sh.utils')
    .directive('listRelations', function ($rootScope, $ionicModal, $state, $ionicPopup, $ionicActionSheet, $ionicScrollDelegate,
                                          BienService, $timeout, $filter, ContactService, ContactActionsService) {
        return {
            restrict: 'EA',
            scope: {
                bien: '=', canCreate: '@', 'filter':'=', canNavigate: '@', adresse: '=', openPopupOnRelation: '@', newRelation:'=', rowClickHandler:'=', updateCallback:"="
            },
            templateUrl: 'modules/directives/list-relations.html',
            controller: function ($scope) {
                var i18n = $filter('i18n');

                angular.extend($scope, {
                    ContactService: ContactService,
                    BienService: BienService,
                    currentLimit: 5,
                    datas:{},
                    canNavigate: $scope.canNavigate || true,
                    searchTextFilter:'',
                    scrollTo: function (id) {
                        $ionicScrollDelegate.scrollElementToTop(id, 'global-scroll');
                    },
                    getMinHeight:  function () {
                        return {'min-height':window.innerHeight*0.5 + 'px'};
                    },
                    rowClicked: function (relation) {
                        if(angular.isDefined($scope.rowClickHandler)) {
                            return $scope.rowClickHandler(relation);
                        } else if($scope.canNavigate === true) {
                            $state.go('nav.contact.detail',{ id: relation.contact._id });
                        }
                    },
                    increaseLimit: function () {
                        $scope.currentLimit = Math.min($scope.currentLimit + 20, $scope.bien.relations.length);
                        $timeout(function() {$ionicScrollDelegate.resize()}, 80);
                    },
                    filterRelationBySearch: function () {
                        return function(relation) {
                            var searchfilter = $scope.datas.searchTextFilter;
                            return (angular.isUndefined(searchfilter)
                                || (relation.contact.nom && relation.contact.nom.toLowerCase().indexOf(searchfilter.toLowerCase())==0)
                                || (relation.contact.prenom && relation.contact.prenom.toLowerCase().indexOf(searchfilter.toLowerCase())==0)
                            )
                        }
                    },
                    relationMatchType: function (relation) {
                        return relation.bien && relation.bien.dernierProjetType && angular.isDefined($scope.filter)
                            && relation.bien.dernierProjetType.indexOf($scope.filter) > -1;
                    },
                    onlyDisplayableRelation: function () {
                        return function (relation) {
                            return BienService.isValidRelation(relation) &&
                                ((angular.isUndefined($scope.filter) || $scope.filter == '' || $scope.filter == 'contact' ||  $scope.relationMatchType(relation)));
                        };
                    },
//                    addRelation: function () {
//                        $scope.newRelation = {'dateDebut': new Date(), type: 'indetermine'};
////                        $scope.bien.relations.splice(0, 0, $scope.newRelation);
//                        $scope.bien.relations.splice(0,0,$scope.newRelation);
//                    },
                    openQuickActionSheet: function (relation, contactLink, anim) {
                        var buttons = [];
                        var bien = relation && relation.bien ? relation.bien : $scope.bien;
                        if (!$state.is('nav.bien.detail', {bienId: bien._id})) {
                            buttons.push({
                                text: '<i class="icon-c21-properties"></i><span>Accéder au bien</span>',
                                click: function () {
                                    BienService.display(bien._id).finally(hideSheet);
                                }
                            });
                        }
                        buttons = buttons.concat([
                            {
                                text: '<i class="ion-plus-circled"></i><span>Ajouter un suivi et une note</span>',
                                click: function () {
                                    angular.extend($scope, {
                                        suivi:{bienId: bien ? bien._id : ''}
                                    });
                                    ContactService.showPopup('suivi', $scope, relation.contact).then(function(suivi) {
                                        if(suivi && $scope.updateCallback) {
                                            $scope.updateCallback(suivi, 'suivi');
                                        }
                                    });
                                }
                            },
                            {
                                text: '<i class="ion-document-text"></i><span>Visualiser les notes</span>',
                                click: function () {
                                    $state.go('nav.bien.hist', {bienId: bien._id});
                                }
                            },
                            {
                                text: '<i class="icon-c21-status-habitant adapt-icon"></i><span>Modifier le statut d\'occupation</span>',
                                click: function () {
                                    //immeuble set bien in relation temporary to allow modification
                                    ContactService.linkBienAndContact(null, bien, relation.contact, null, null, relation,  'Modifier le statut d\'occupation');
                                }
                            },
                            {
                                text: '<i class="icon-c21-unknow-new-resident"></i><span>N\'habite plus à cette adresse</span>',
                                click: function () {
                                    ContactActionsService.openConfirmRemovePopUp(relation, bien);
                                }
                            },
                            {
                                text: '<i class="icon-c21-new-resident"></i><span>Remplacer par le nouvel habitant</span>',
                                click: function () {
                                    ContactActionsService.removeAndAddNewPopUp(relation, bien);
                                }
                            }]);
                        if($scope.filteredResult && $scope.filteredResult.length > 1) {
                            buttons.push({
                                text: '<i class="ion-pull-request"></i><span>Fusionner cette fiche avec...</span>',
                                click: function () {
                                    ContactActionsService
                                        .mergePopup(relation, $scope.bien || relation.bien)
                                        .then(function(merged) {
                                            $rootScope.$emit('merge.end', merged);
                                        });
                            }});
                        }

                        var hideSheet = $ionicActionSheet.show({
                            buttons: buttons,
                            titleText: '' + relation.contactString,
                            cancelText: '<i class="ion-close icon-left"></i><span>Fermer</span>',
                            cancel: function () {
                                // add cancel code..
                            },
                            buttonClicked: function (index) {
                                hideSheet();
                                buttons[index].click();
                            }
                        });
                    },

                    openQuickActionModal: function (relation, contactLink, anim) {
                        if (angular.isDefined(relation) && angular.isDefined(relation._id)) {
                            $ionicModal.fromTemplateUrl('modules/bien/popup/quick-contact.html', {
                                scope: angular.extend($scope, {
                                    relation: relation,
                                    contactLink: angular.isDefined(contactLink)
                                }),
                                animation: (anim === false ? 'none' : 'slide-left-right')
                            }).then(function (modal) {
                                $scope.relation.contact = ContactService.get($scope.relation.contactRef);
                                $scope.quickModal = modal;
                                $scope.quickModal.show();
                            });
                        }
                    },
                    updateRelationsArray: function () {
                        $scope.datas.searchTextFilter = '';
                        if(angular.isUndefined($scope.bien) || angular.isUndefined($scope.bien.relations)) {
                            $scope.relations = [];
                        } else {
                            var relationType = $filter('filter')($scope.bien.relations, $scope.onlyDisplayableRelation());
                            $scope.relations = $filter('orderBy')(relationType, ['-bien.numeroBatiment', 'bien.numeroBatimentOrder', '-bien.numeroEtage', 'bien.numeroAppartement', 'contactString']);
                        }
                    },
                    canCreateContact: function () {
                        if ($scope.relations
                            && angular.isUndefined($scope.newRelation)
//                            && ($scope.relations.length == 0 || $scope.relations[$scope.relations.length - 1]._id)
                        ) {
                            return $scope.canCreate === 'true';
                        }
                        //editing a new contact
                        return false;
                    }
                });

                $scope.$watchCollection('bien._class', function () {
                    $scope.buttonTitle = $scope.bien && $scope.bien._class ? 'addContactToThis' + $scope.bien._class : 'addContactToThisAdress';
                });
                $scope.$watchCollection('bien.relations', $scope.updateRelationsArray);
                $scope.$watchCollection('filter', $scope.updateRelationsArray);

                $scope.$on('closeModal', function () {
                    if ($scope.quickModal) {
                        $scope.quickModal.hide();
                    }
                });
            }
        };
    });
