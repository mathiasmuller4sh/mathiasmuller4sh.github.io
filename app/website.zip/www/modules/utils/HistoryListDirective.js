'use strict';
angular
    .module('4sh.utils')
    .directive('c21HistoryList', function ($timeout, $ionicScrollDelegate) {
        return {
            restrict: 'EA',
            templateUrl: 'modules/utils/history-directive.html',
            scope: {
                histories: '=',
                refreshCallback:'=',
                showContact:'@'
            },
            controller: function ($scope) {
                angular.extend($scope, {
                    currentLimit:10,
                    showContact: angular.isDefined($scope.showContact)? $scope.showContact: true,
                    increaseLimit: function () {
                        console.log('c21HistoryList=>increaseLimit');
                        $scope.currentLimit = Math.min($scope.currentLimit+20, $scope.histories.length );
                        $timeout(function() {$ionicScrollDelegate.resize()}, 200);
                    },
                    loadMore: function(all) {
                        $scope.all = all;
                        if($scope.refreshCallback) {
                            $scope.refreshCallback(all === true ?{limiteMois:0}:undefined);
                        } else {
                            console.log("no refresh callback set ");
                        }
                    }
                });
                //$scope.$watchCollection('histories', function() {
                //    console.log(arguments)
                //})
            }
        }
    });


