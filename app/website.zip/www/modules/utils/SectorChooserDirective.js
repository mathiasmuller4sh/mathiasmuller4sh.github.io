'use strict';

angular
    .module('4sh.utils')
    .directive('sectorChooser', function () {
        return {
            restrict: 'E',
            replace: false,
            scope:{
                bien:"="
            },
            templateUrl: 'modules/utils/sector-chooser.html',
            link: function (scope) {
                scope.selectedSector = null;
                scope.updateModel = function() {
                    //console.log('updateModel',{Key:scope.selectedSector, Value:scope.bien.sectors[scope.selectedSector]})
                    scope.bien.selectedSector = {Key:parseInt(scope.selectedSector), Value:scope.bien.sectors[scope.selectedSector]}
                }
                scope.$on('$destroy', scope.$watch('bien', function(bien) {
                    if(bien) {
                        //console.log('setScope',bien.selectedSector.Key)
                        scope.selectedSector = ""+bien.selectedSector.Key;
                    }
                }));
            }
        };
    });
