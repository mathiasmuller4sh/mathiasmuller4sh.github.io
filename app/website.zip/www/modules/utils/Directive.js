'use strict';
angular
    .module('4sh.utils')
    .directive('focusIt', function ($timeout, $cordovaKeyboard) {
        return {
            link: function (scope, element, attrs) {
                attrs.$observe("focusIt", function (newValue) {
                    if (newValue == "true")
                        $timeout(function () {
                            //console.log('focusIt', element)
                            element[0].focus();
                            $cordovaKeyboard.show();
                        }, 200);
                });
            }
        };
    })
    .directive('updateTitle', function ($rootScope, $timeout) {
        return {
            link: function (scope, element) {
                $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                    var title = "";
                    if (toState.data && toState.data.pageTitle) {
                        title = toState.data.pageTitle;
                    }
                    element.text(title);
                    //// Set asynchronously so page changes before title does
                    //$timeout(function () {
                    //});
                });
            }
        }
    })
    .directive('contactActions', function (ContactService, LocalStorageService, $window, $rootScope, $analytics) {
        return {
            restrict: 'AE',
            scope: {contact: '=', bien: '='},
            templateUrl: 'modules/directives/contacts-action.html',
            controller: function ($scope) {
                angular.extend($scope, {
                    suivi: {bienId: $scope.bien ? $scope.bien._id : ''},
                    ContactService: ContactService,
                    showPopup: function (popupToShow) {
                        angular.extend($scope, {quickTel: undefined, quickEmail: undefined});
                        ContactService.showPopup(popupToShow, $scope);
                    },

                    openCalendar: function () {
                        $analytics.eventTrack('Calendrier', {  category: $rootScope.gaCategory, label: 'Calendrier' });

                        ContactService.registerAgenda($scope.contact);
                        if (ionic.Platform.isAndroid()) {
                            cordova.exec(null,
                                null,
                                "Calendar",
                                "calshow", []);
                        } else {
                            $window.location = "calshow://";
                        }
                    }
                });
            }
        };
    })
;
