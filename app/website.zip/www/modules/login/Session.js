'use strict';

angular
    .module('module.login')
    .factory('Session', function ($state, $q, $rootScope, Restangular, $ionicPopup, Toast, $timeout,
                                  BienService, ContactService, LocalStorageService) {
        var current = undefined;
        var service = {
            getLastLogin: function () {
                var lastLogin = LocalStorageService.getValue('lastLogin');
                if(lastLogin && lastLogin != 'undefined') {
                    return lastLogin;
                }
                return '';
            },
            logout: function () {
                current = null;
                BienService.cleanCache();
                ContactService.cleanCache();
                LocalStorageService.removeValue('login');
                return Restangular.all('sessions').one('current').remove().finally(function () {
                    $state.go('login');
                });
            },
            autologin: function (forced) {
                var deferred = $q.defer();
                if(forced === true || angular.isUndefined(service.current())) {
                    var retryOrReject = function() {
                        var last = LocalStorageService.getValue('login');
                        if(angular.isDefined(last)) {
                            //Toast.show('Reconnexion...')
                            service.login(last).then(deferred.resolve, deferred.reject);
                        } else {
                            deferred.reject();
                        }
                    };
                    Restangular.all('sessions').customGET('current')
                        .then(function (ok) {
                            if (angular.isDefined(ok) && ok != 'null') {
                                deferred.resolve(service.setCurrent(ok));
                            } else {
                                retryOrReject();
                            }
                        }, retryOrReject
                    );
                } else {
                    deferred.resolve(service.current());
                }
                return deferred.promise;
            },
            login: function (infos) {
                LocalStorageService.saveValue('lastLogin', infos.name);
                return Restangular.all('sessions').customPOST({"login": infos.name, "mdp": infos.passwordHash, rememberMe: infos.rememberMe}).then(
                    function (principal) {
                        if(infos.rememberMe){
                            LocalStorageService.saveValue('login', infos);
                        } else {
                            LocalStorageService.removeValue('login');
                        }
                        return service.setCurrent(principal);
                    },
                    function (error) {
                        console.log(error);
                        //<i class="icon-infos ion-close-round"></i>
                        $timeout(function(){Toast.show('Identification incorrecte.','long')});
                        //return error;
                    });
            },
            setCurrent: function (utilisateur) {
                current = utilisateur;
                if(angular.isDefined(utilisateur) ) {
                    $rootScope.$broadcast('user.login');
                } else {
                    $rootScope.$broadcast('user.logout');
                }
                return current;
            },
            current: function () {
                return current;
            }
        };
        return service;
    });
