'use strict';
angular
    .module('module.login', [])
    .controller('LoginCtrl',
    function ($rootScope, $scope, $state, $timeout, $interval, $ionicLoading, $ionicHistory, Session, LoadingConfig) {
        angular.extend($scope, {
            pulseMobile: false,
            showSell: false,
            $state: $state,
            login: {
                name:Session.getLastLogin(),
                rememberMe :true
            },
            canPlayVideo: function () {
                //console.log(ionic.Platform.version()+" "+JSON.stringify(ionic.Platform.platforms))
                return ionic.Platform.isIOS();
            },
            standardVideo: function () {
                return !ionic.Platform.isAndroid();
            },
            authentifier: function () {
                $ionicLoading.show(LoadingConfig);
                function doit() {
                    $ionicHistory.nextViewOptions({
                        disableAnimate: true,
                        disableBack: true,
                        historyRoot: true
                    });
                    //let wp8 breath
                    Session
                        .login($scope.login)
                        .then(function (ok) {
                            if (ok) {
                                $state.go('home.index');
                            }
                        })
                        .finally($ionicLoading.hide);
                }
                if (ionic.Platform.isWindowsPhone()) {
                    $timeout(doit, 400);
                } else {
                    doit();
                }
            }
        });
        $scope.animateMobile = function () {
            $scope.pulseMobile = !$scope.pulseMobile;
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 1000);
            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 3000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 5000);

            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 7000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 8000);
            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 10000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 12500);

            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 14500);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 15500);
            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 17500);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 20500);

            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 26000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 27000);
            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 28000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 31000);

            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 34500);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 35500);
            $timeout(function () {
                $scope.pulseMobile = !$scope.pulseMobile;
            }, 37000);
            $timeout(function () {
                $scope.showSell = !$scope.showSell;
            }, 39000);
        };

        if (ionic.Platform.isAndroid()) {
            if (ionic.Platform.version() < 4.4 && window.plugins && window.plugins.html5Video) {
                console.log('launching video for android');
                window.plugins.html5Video.initialize({
                    "android_video": "c21loginmovie.mp4"
                });
                window.plugins.html5Video.play("android_video")
            }
            //else {
            //    $scope.animateMobile();
            //    $interval(function () {
            //        $scope.animateMobile();
            //    }, 45000);
            //}
        }

    });
