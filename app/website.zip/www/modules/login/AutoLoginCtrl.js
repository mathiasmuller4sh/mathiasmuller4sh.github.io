'use strict';
angular
    .module('module.login')
    .controller('AutoLoginCtrl',
    function ($state, $scope, Session, $ionicHistory, $ionicPlatform) {
        Session.setCurrent(null);
        $ionicHistory.clearHistory();
        $ionicHistory.nextViewOptions({
            disableAnimate: true,
            disableBack: true,
            historyRoot: true
        });
        $ionicPlatform.ready(function () {
            Session.autologin(true).then(function (ok) {
                if (angular.isUndefined(ok)) {
                    $state.go('login');
                } else {
                    $state.go('home.index');
                }
            }, function (ko) {
                $state.go('login');
            })
        });
    });
