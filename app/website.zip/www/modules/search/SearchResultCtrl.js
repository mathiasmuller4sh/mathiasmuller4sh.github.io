'use strict';
angular
    .module('module.search')
    .controller('SearchResultCtrl', function ($rootScope, $scope, $state, $filter, SearchService) {
        angular.extend($scope, {
            datas:{},
            setSearchVisible: function (bool) {
                $scope.datas.searchVisible = bool;
                $rootScope.$emit('search.visibility', bool);
            },
            resultClick: function (result) {
                $rootScope.$emit('search.result.click', result);
            },
            doSearch: function (evt, query) {
                $scope.setSearchVisible(true);
                $scope.resultsContact = $scope.resultsAdresse = [];
                if (query) {
                    if (query.length >= SearchService.SEARCH_MIN_CHAR_NB) {
                        $scope.resultsMessage = [
                            {label: "Recherche en cours ..."}
                        ];
                        SearchService.search(query).then(function (result) {
                            $rootScope.$emit('search.complete', result);
                            if (result.features && result.features.length > 0) {
                                $scope.resultsMessage = [];
                                $scope.resultsContact = $filter('filter')(result.features, function (feat) {
                                    return feat.properties._type === "Contact" && feat.properties.nom;
                                });
                                var adrs = $filter('filter')(result.features, function (feat) {
                                    return feat.properties._type === "Adresse";
                                });
                                //do not sort server do it
                                //$scope.resultsAdresse = $filter('orderBy')(adrs, ['properties.ville', 'properties.rue', 'properties.numero']);
                                $scope.resultsAdresse = adrs;
                            } else {
                                $scope.resultsMessage = [
                                    {label: "Pas de résultat"}
                                ];
                            }
                        }, function (error) {
                            console.log(error);
                            $scope.resultsMessage = [
                                {label: "Une erreur est survenue:(" + error.data.substring(0, 30) + ")"}
                            ];
                        });
                    } else {
                        var diff = SearchService.SEARCH_MIN_CHAR_NB - query.length;
                        $scope.resultsMessage = [
                            {label: "Veuillez saisir encore  " + diff + (diff > 1 ? " lettres" : " lettre")}
                        ];
                    }
                } else {
                    $scope.resultsMessage = [];
                    $scope.setSearchVisible(false);
                }
            }
        });
        //wait for text box event
        $scope.$on('$destroy', $rootScope.$on('search.do', $scope.doSearch));
        //allow search box to hide result
        $scope.$on('$destroy', $rootScope.$on('search.visibility', function(evt, visible) {
            $scope.datas.searchVisible = visible
        }));
    });
