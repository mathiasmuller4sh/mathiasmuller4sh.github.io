'use strict';

angular
    .module('module.search')
    .factory('SearchService', function (Restangular, MapService) {
        var map = Restangular.one('map');

        //this apply on feature collection kind of useless
        var applyModel = function (obj) {
            return angular.extend(obj, {
            });
        };

        Restangular.extendModel('search', applyModel);

        var service = {
            SEARCH_MIN_CHAR_NB:3,
            isContact: function (geojsonFeature) {
                return geojsonFeature.properties._type === "Contact";
            },
            isAdresse: function (geojsonFeature) {
                return geojsonFeature.properties._type === "Adresse";
            },
            search: function (query) {
                return map.customGET('search', {
                    q: query,
                    lat: MapService.getLastLocation().lat,
                    lng: MapService.getLastLocation().lng,
                    distance: 5000
                });
            }
        };
        return service
    })
;
