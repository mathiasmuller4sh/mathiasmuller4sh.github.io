'use strict';
angular
    .module('module.search')
    .controller('SearchCtrl', function ($rootScope, $scope) {
        angular.extend($scope, {
            setSearchVisible: function (bool) {
                $scope.datas.searchVisible = bool;
                $rootScope.$emit('search.visibility', bool);
            },
            doSearch: function (newV) {
                if(newV) {
                    //document.getElementById('search-box-input').blur();
                    $scope.setSearchVisible(true);
                    $rootScope.$emit('search.do', newV);
                }
            },
            clearText: function () {
                $scope.datas.searchText = '';
                $scope.setSearchVisible(false);
            },
            clearSearch: function () {
                $scope.setSearchVisible(false);
            },
            selectInputSearch : function(){
                if(angular.isDefined($scope.setHomeVisible)){
                    $scope.setHomeVisible(false);
                }
            },
            releaseInputSearch : function(){
                if(angular.isDefined($scope.setHomeVisible)){
                    $scope.setHomeVisible(true);
                }
            }
        });
        //debounce search text and search binding
        $scope.$watch('datas.searchText', _.debounce(function (newV, oldV) {
            $scope.$apply(function () {
                if(newV && newV != oldV) {
                    $rootScope.searchText = newV;
                    $scope.doSearch(newV);
                } else
                if(newV != oldV && angular.isUndefined(newV) ) {
                    $rootScope.searchText = '';
                    $scope.clearSearch();
                }
            });
        }, 500));

        var unreg = $rootScope.$on('user.logout', function() {
            $rootScope.searchText = '';
            unreg();
        });
    });
