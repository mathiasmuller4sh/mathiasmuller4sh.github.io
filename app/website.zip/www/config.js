angular.module('4sh.utils').constant('ConfigDictionary', {
    "appVersion" : "1.1.20",
    "serverUrl" : "https://centurynet.naxos.fr/CenturyNet/WebApiAmc/amc",
    "appVersionService" : "https://centurynet.naxos.fr/CenturyNet/AppliMobileDuConseiller/version.json",
    "googleAnalyticsCode" : "UA-55063178-2"
});
