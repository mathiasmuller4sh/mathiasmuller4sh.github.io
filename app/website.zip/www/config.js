angular.module('4sh.utils').constant('ConfigDictionary', {
    "appVersion" : "1.2.6",
    "serverUrl" : "https://centurynetrecette.naxos.fr/CenturyNet/WebApiAmc/amc",
    "appVersionService" : "https://centurynetrecette.naxos.fr/CnetMobile/version.json",
    "googleAnalyticsCode" : "UA-55063178-3",
    "errorsDbUrl" : "https://crackling-fire-1926.firebaseio.com/recette"
});
