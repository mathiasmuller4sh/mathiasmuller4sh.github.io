(function (module) {

    var KEY = 'c21m.env';
    var KEY_URL_CUSTOM = 'c21m.env.customUrl';

    function getCurrentEnvironment() {

        var val = localStorage.getItem(KEY);
        if (angular.isUndefined(val)) {
            if (window.BuildInfo && window.BuildInfo.packageName === 'fr.naxos.c21mobile.recette') {
                console.log('use recette due to packageName:' + window.BuildInfo.packageName);
                val = 'recette';
            } else {
                val = 'production';
            }
        }
        return val;
    }

    module
        .constant('AppVersion', '1.3.31')
        .constant('Environment', (function () {
            return getCurrentEnvironment();
        })())
        .constant('ConfigDictionary', {
            production: {
                'envName': 'Production',
                'serverUrl': 'https://centurynet.naxos.fr/CenturyNet/WebApiAmc/amc',
                'appVersionService': 'https://centurynet.naxos.fr/CenturyNet/AppliMobileDuConseiller/version.json',
                'googleAnalyticsCode': 'UA-55063178-2',
                'errorsDbUrl': 'https://crackling-fire-1926.firebaseio.com/prod'
            },
            preprod: {
                'envName': 'Pré-production',
                'serverUrl': 'http://centurynetrecette.naxos.fr/CenturyNetPreProd/WebApiAmc/amc',
                'appVersionService': 'http://centurynetrecette.naxos.fr/CnetMobile/version.json',
                'googleAnalyticsCode': 'UA-55063178-3',
                'errorsDbUrl': 'https://crackling-fire-1926.firebaseio.com/recette'
            },
            recette: {
                'envName': 'Recette',
                'serverUrl': 'http://centurynetrecette.naxos.fr/CenturyNet/WebApiAmc/amc',
                'appVersionService': 'http://centurynetrecette.naxos.fr/CnetMobile/version.json',
                'googleAnalyticsCode': 'UA-55063178-3',
                'errorsDbUrl': 'https://crackling-fire-1926.firebaseio.com/recette'
            },
            dev: {
                'envName': 'Développement',
                'serverUrl': '/CenturyNet/WebApiAmc/Amc',
                'appVersionService': 'store/version.json',
                'googleAnalyticsCode': 'UA-55063178-3',
                'errorsDbUrl': 'https://crackling-fire-1926.firebaseio.com/dev'
            },
            custom: {
                'envName': 'Autre',
                'serverUrl': (function() {
                    return localStorage.getItem(KEY_URL_CUSTOM);
                })(),
                'appVersionService': 'store/version.json',
                'googleAnalyticsCode': '',
                'errorsDbUrl': 'https://crackling-fire-1926.firebaseio.com/dev'
            }
        })
        .factory('EnvironmentService', function (ConfigDictionary, Environment, $ionicPopup, $rootScope, $interval) {
            var hookcount = 0;
            $interval(function () {
                hookcount = 0;
            }, 3000);
            var service = {
                getEnvConfig: function () {
                    return ConfigDictionary[getCurrentEnvironment()];
                },
                getEnv: getCurrentEnvironment,
                setEnv: function (value) {
                    if (angular.isDefined(ConfigDictionary[value])) {
                        localStorage.setItem(KEY, value);
                    } else {
                        console.log('Not a valid environement:' + value);
                    }
                },
                hookclick: function () {
                    hookcount += 1;
                    if (hookcount > 5) {
                        service.showEnvironment();
                    }
                },
                showEnvironment: function () {
                    var $scope = $rootScope.$new();
                    $scope.data = {env: Environment};
                    $ionicPopup.show({
                        template: '<select ' +
                        'style="width:100%;padding:10px" ' +
                        'ng-model="data.env" ' +
                        'ng-options="name as env.envName for (name, env) in ConfigDictionary"' +
                        '/>',
                        title: 'Option de connexion',
                        subTitle: 'Merci de choisir un environement',
                        scope: $scope,
                        buttons: [
                            {text: 'Annuler'},
                            {
                                text: '<b>Ok</b>',
                                type: 'button-energized',
                                onTap: function (e) {
                                    if (!$scope.data.env) {
                                        e.preventDefault();
                                    } else {
                                        service.setEnv($scope.data.env);
                                        if ($scope.data.env === 'custom') {
                                            $scope.data.url = ConfigDictionary.custom.serverUrl;
                                            $ionicPopup.show({
                                                template: '<input type="text" ng-model="data.url">',
                                                title: 'Url du serveur ',
                                                scope: $scope,
                                                buttons: [
                                                    {text: 'Annuler'},
                                                    {
                                                        text: '<b>Save</b>',
                                                        type: 'button-positive',
                                                        onTap: function (e) {
                                                            if (!$scope.data.url) {
                                                                e.preventDefault();
                                                            } else {
                                                                localStorage.setItem(KEY_URL_CUSTOM, $scope.data.url);
                                                                ConfigDictionary.custom.serverUrl = $scope.data.url;
                                                                window.location.reload();
                                                            }
                                                        }
                                                    }
                                                ]
                                            });
                                        } else {
                                            window.location.reload();
                                        }
                                    }
                                }
                            }
                        ]
                    });
                }
            };
            return service;
        })

        .run(function ($rootScope, ConfigDictionary, Environment, EnvironmentService, AppVersion) {
            $rootScope.ConfigDictionary = ConfigDictionary;
            $rootScope.EnvironmentService = EnvironmentService;
            $rootScope.CurrentEnvironment = ConfigDictionary[Environment];
            $rootScope.AppVersion = AppVersion;
        });
})(angular.module('4sh.utils'));
